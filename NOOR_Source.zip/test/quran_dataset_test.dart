import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('bundled Quran dataset contains all surahs and ayahs in order', () async {
    final raw = await rootBundle.loadString(
      'assets/content/legacy/quran_surahs.json',
    );
    final data = jsonDecode(raw) as Map<String, dynamic>;
    final surahs = data['surahs'] as List<dynamic>;
    expect(surahs, hasLength(114));

    var ayahCount = 0;
    for (var index = 0; index < surahs.length; index++) {
      final surah = Map<String, dynamic>.from(surahs[index] as Map);
      expect(surah['surahNumber'], index + 1);
      final ayahs = surah['ayahs'] as List<dynamic>;
      expect(ayahs, hasLength(surah['ayahCount'] as int));
      for (var ayahIndex = 0; ayahIndex < ayahs.length; ayahIndex++) {
        final ayah = Map<String, dynamic>.from(ayahs[ayahIndex] as Map);
        expect(ayah['number'], ayahIndex + 1);
      }
      ayahCount += ayahs.length;
    }
    expect(ayahCount, 6236);
  });
}
