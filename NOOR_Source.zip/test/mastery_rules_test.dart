import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/repositories/mastery_rules.dart';

void main() {
  group('NOOR sequential mastery rules', () {
    test('80 percent is the mastery threshold', () {
      expect(MasteryRules.isMastered(79), isFalse);
      expect(MasteryRules.isMastered(80), isTrue);
      expect(MasteryRules.isMastered(100), isTrue);
    });

    test('first lesson is available without a previous result', () {
      expect(MasteryRules.isUnlocked(0, previousMastered: false), isTrue);
    });

    test('later lesson requires mastery of the immediate predecessor', () {
      expect(MasteryRules.isUnlocked(1, previousMastered: false), isFalse);
      expect(MasteryRules.isUnlocked(1, previousMastered: true), isTrue);
      expect(MasteryRules.isUnlocked(7, previousMastered: false), isFalse);
    });
  });
}
