import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import '../lib/core/widgets/noor_arabic_keyboard.dart';

void main() {
  testWidgets('Arabic 101 keyboard exposes the full requested layout', (tester) async {
    final controller = TextEditingController();
    tester.view.physicalSize = const Size(900, 1600);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(body: NoorArabicKeyboard(controller: controller)),
    ));

    for (final key in [
      'ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج', 'د',
      'ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط',
      'ئ', 'ء', 'ؤ', 'ر', 'لا', 'ى', 'ة', 'و', 'ز', 'ظ', 'ذ', 'أ', 'إ', 'آ',
    ]) {
      expect(find.text(key), findsOneWidget, reason: 'Missing Arabic key: $key');
    }

    expect(find.text('١'), findsOneWidget);
    await tester.tap(find.text('١'));
    await tester.pump();
    expect(controller.text, '١');
    controller.clear();

    await tester.tap(find.text('لا'));
    await tester.pump();
    expect(controller.text, 'لا');
    await tester.tap(find.text('حذف'));
    await tester.pump();
    expect(controller.text, isEmpty, reason: 'Delete must remove the complete lam-alif key');

    await tester.tap(find.text('ج'));
    await tester.pump();
    expect(controller.text, 'ج');

    controller.dispose();
  });
}
