import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/repositories/avatar_drawing_repository.dart';

void main() {
  test('drawing strokes preserve normalized points and style', () {
    const stroke = NoorDrawingStroke(
      points: [[0.1, 0.2], [0.7, 0.9]],
      color: 0xFF126F75,
      width: 5,
    );
    final restored = NoorDrawingStroke.fromJson(stroke.toJson());
    expect(restored.points, [[0.1, 0.2], [0.7, 0.9]]);
    expect(restored.color, 0xFF126F75);
    expect(restored.width, 5);
  });
}
