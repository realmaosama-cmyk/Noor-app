import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/content/catalog.dart';
import 'package:noor/data/content/learning_domains.dart';

void main() {
  test('both domains group every existing section exactly once', () {
    final ids =
        noorLearningDomains.expand((domain) => domain.sectionIds).toList();
    expect(noorLearningDomains.map((domain) => domain.id).toSet(),
        {'sharia', 'science'});
    expect(ids.length, noorSections.length);
    expect(ids.toSet().length, ids.length);
    expect(ids.toSet(), noorSections.map((section) => section.id).toSet());
  });
}
