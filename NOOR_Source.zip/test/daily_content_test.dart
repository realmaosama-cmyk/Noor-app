import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/content/catalog.dart';
import 'package:noor/data/content/daily_content.dart';

void main() {
  test('the nine core Islamic sections contain actual lessons and quizzes', () {
    for (final id in [
      'quran',
      'prayer',
      'adhkar',
      'akhlaq',
      'seerah',
      'figures',
      'prophets',
      'learn',
      'challenges'
    ]) {
      final section = sectionById(id);
      expect(section, isNotNull);
      expect(section!.lessons, isNotEmpty);
      expect(section.lessons.every((lesson) => lesson.questions.isNotEmpty),
          isTrue);
    }
  });
  test('daily wisdom items include source references', () {
    expect(dailyWisdom, isNotEmpty);
    for (final item in dailyWisdom) {
      expect(item.ayahRef, isNotEmpty);
      expect(item.hadithRef, isNotEmpty);
    }
    expect(wisdomForToday(DateTime(2026, 1, 1)).ayah,
        wisdomForToday(DateTime(2026, 1, 1)).ayah);
  });
}
