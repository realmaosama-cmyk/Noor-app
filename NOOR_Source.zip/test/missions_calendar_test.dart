import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/repositories/missions_repository.dart';

void main() {
  group('Noor mission calendar', () {
    test('daily key changes at local midnight', () {
      expect(NoorMissionsRepository.dayKeyFor(DateTime(2026, 11, 28, 23, 59)),
          '2026-11-28');
      expect(NoorMissionsRepository.dayKeyFor(DateTime(2026, 11, 29)),
          '2026-11-29');
    });

    test('mission selection is stable and has the configured number of tasks', () {
      final day = DateTime(2026, 11, 28);
      expect(NoorMissionsRepository.dailyMissionIdsFor(7, day),
          NoorMissionsRepository.dailyMissionIdsFor(7, day));
      expect(NoorMissionsRepository.dailyMissionIdsFor(7, day).length, 3);
      expect(NoorMissionsRepository.weeklyMissionIdsFor(7, day).length, 4);
    });

    test('weekly key follows ISO week-year across New Year', () {
      expect(NoorMissionsRepository.weekKeyFor(DateTime(2026, 12, 31)),
          '2026-W53');
      expect(NoorMissionsRepository.weekKeyFor(DateTime(2027, 1, 1)),
          '2026-W53');
      expect(NoorMissionsRepository.weekKeyFor(DateTime(2027, 1, 4)),
          '2027-W01');
    });
  });
}
