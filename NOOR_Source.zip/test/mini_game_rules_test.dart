import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/repositories/mini_game_rules.dart';

void main() {
  group('NOOR mini-game rules', () {
    test('maze movement is limited to adjacent orthogonal cells', () {
      expect(NoorMiniGameRules.isAdjacentCell(0, 1), isTrue);
      expect(NoorMiniGameRules.isAdjacentCell(0, 5), isTrue);
      expect(NoorMiniGameRules.isAdjacentCell(0, 6), isFalse);
      expect(NoorMiniGameRules.isAdjacentCell(4, 5), isFalse);
    });

    test('all three maze levels have a valid route to the treasure', () {
      const openLevels = [
        {0, 1, 2, 3, 4, 6, 9, 11, 12, 13, 14, 16, 19, 20, 21, 22, 23, 24},
        {0, 2, 3, 4, 5, 7, 9, 10, 11, 12, 14, 15, 19, 20, 24},
        {0, 1, 3, 6, 8, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 24},
      ];
      const routes = [
        [0, 1, 2, 3, 4, 9, 14, 13, 12, 11, 16, 21, 22, 23, 24],
        [0, 5, 10, 11, 12, 7, 2, 3, 4, 9, 14, 19, 24],
        [0, 1, 6, 11, 16, 15, 20, 21, 22, 17, 12, 13, 14, 19, 24],
      ];
      for (var i = 0; i < routes.length; i++) {
        expect(NoorMiniGameRules.isReachableMazePath(routes[i], openLevels[i]), isTrue);
        expect(routes[i].first, 0);
        expect(routes[i].last, 24);
      }
    });

    test('difference challenge completes only after every difference is found', () {
      const differences = {1, 3, 5};
      expect(NoorMiniGameRules.hasFoundAllDifferences({1, 3}, differences), isFalse);
      expect(NoorMiniGameRules.hasFoundAllDifferences({1, 3, 5}, differences), isTrue);
    });

    test('story sequence must match the exact order for three- and four-step stories', () {
      expect(NoorMiniGameRules.isCorrectStoryOrder([0, 1, 2], [0, 1, 2]), isTrue);
      expect(NoorMiniGameRules.isCorrectStoryOrder([0, 2, 1], [0, 1, 2]), isFalse);
      expect(NoorMiniGameRules.isCorrectStoryOrder([0, 1], [0, 1, 2]), isFalse);
      expect(NoorMiniGameRules.isCorrectStoryOrder([0, 1, 2, 3], [0, 1, 2, 3]), isTrue);
      expect(NoorMiniGameRules.isCorrectStoryOrder([0, 2, 1, 3], [0, 1, 2, 3]), isFalse);
    });
  });
}
