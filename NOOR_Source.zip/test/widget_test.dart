import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:noor/app.dart';

void main() {
  test('NOOR app root is a Material widget', () {
    expect(const NoorApp(), isA<Widget>());
  });
}
