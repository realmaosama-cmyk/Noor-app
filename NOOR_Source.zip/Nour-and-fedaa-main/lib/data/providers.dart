import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'models/child.dart';
import 'repositories/child_repository.dart';
import 'repositories/settings_repository.dart';

final childRepositoryProvider=Provider<ChildRepository>((_)=>ChildRepository());
final settingsRepositoryProvider=Provider<SettingsRepository>((_)=>SettingsRepository());
final childrenProvider=FutureProvider<List<Child>>((ref)=>ref.watch(childRepositoryProvider).all());
final selectedChildIdProvider=StateProvider<int?>((_)=>null);
final selectedChildProvider=FutureProvider<Child?>((ref) async {
  final id=ref.watch(selectedChildIdProvider);
  if(id==null)return null;
  return ref.watch(childRepositoryProvider).byId(id);
});
final sectionStatesProvider=FutureProvider<Map<String,bool>>((ref)=>ref.watch(settingsRepositoryProvider).sectionStates());
final darkModeProvider=FutureProvider<bool>((ref)=>ref.watch(settingsRepositoryProvider).darkMode());
