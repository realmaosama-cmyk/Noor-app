import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, 'nourfadaa.db'),
      version: 3,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE children(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, age INTEGER NOT NULL,
      gender TEXT NOT NULL DEFAULT 'unspecified',
      avatar TEXT NOT NULL DEFAULT '🌟',
      stars INTEGER NOT NULL DEFAULT 0, points INTEGER NOT NULL DEFAULT 0,
      interests TEXT NOT NULL DEFAULT '')''');
    await _createSupportingTables(db);
  }

  Future<void> _createSupportingTables(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS progress(
      child_id INTEGER NOT NULL, lesson_id TEXT NOT NULL,
      status TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0,
      completed_at TEXT, PRIMARY KEY(child_id, lesson_id))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS badges(
      child_id INTEGER NOT NULL, badge_id TEXT NOT NULL,
      earned_at TEXT NOT NULL, PRIMARY KEY(child_id, badge_id))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS settings(
      key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
    await db.execute('''CREATE TABLE IF NOT EXISTS usage_log(
      child_id INTEGER NOT NULL, day TEXT NOT NULL,
      seconds INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(child_id, day))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS bookmarks(
      child_id INTEGER NOT NULL, item_id TEXT NOT NULL,
      created_at TEXT NOT NULL, PRIMARY KEY(child_id, item_id))''');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute(
          "ALTER TABLE children ADD COLUMN gender TEXT NOT NULL DEFAULT 'unspecified'");
      await db.execute(
          "ALTER TABLE children ADD COLUMN avatar TEXT NOT NULL DEFAULT '🌟'");
      // Preserve existing profiles and learning history during the upgrade.
      // The new columns receive safe defaults for records created by v1.
      await _createSupportingTables(db);
    }
    if (oldVersion < 3) {
      await db.execute(
          "ALTER TABLE children ADD COLUMN interests TEXT NOT NULL DEFAULT ''");
    }
  }
}
