class Child {
  const Child({
    required this.id,
    required this.name,
    required this.age,
    this.gender = 'unspecified',
    this.avatar = '🌟',
    this.stars = 0,
    this.points = 0,
  });

  final int id;
  final String name;
  final int age;
  final String gender;
  final String avatar;
  final int stars;
  final int points;

  int get level => (points ~/ 100) + 1;
  AgeGroup get ageGroup {
    if (age <= 5) return AgeGroup.discovery;
    if (age <= 9) return AgeGroup.adventure;
    if (age <= 13) return AgeGroup.challenge;
    if (age <= 17) return AgeGroup.independence;
    return AgeGroup.adult;
  }

  String get ageLabel => switch (ageGroup) {
    AgeGroup.discovery => 'الاكتشاف',
    AgeGroup.adventure => 'المغامرة',
    AgeGroup.challenge => 'التحدي',
    AgeGroup.independence => 'الاستقلال',
    AgeGroup.adult => 'المعرفة',
  };

  factory Child.fromMap(Map<String, Object?> m) => Child(
    id: m['id']! as int,
    name: m['name']! as String,
    age: m['age']! as int,
    gender: (m['gender'] as String?) ?? 'unspecified',
    avatar: (m['avatar'] as String?) ?? '🌟',
    stars: (m['stars'] as int?) ?? 0,
    points: (m['points'] as int?) ?? 0,
  );
}

enum AgeGroup { discovery, adventure, challenge, independence, adult }
