import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:sqflite/sqflite.dart';
import '../db/app_database.dart';

class SectionIds {
  static const quran='quran', prayer='prayer', adhkar='adhkar', akhlaq='akhlaq',
    seerah='seerah', figures='figures', prophets='prophets', learn='learn',
    achievements='achievements', curriculum='curriculum', challenges='challenges';
  static const all=[quran,prayer,adhkar,akhlaq,seerah,figures,prophets,learn,achievements,curriculum,challenges];
}
class SettingsRepository {
  Future<String?> _get(String key) async {
    final db=await AppDatabase.instance.database;
    final rows=await db.query('settings',where:'key = ?',whereArgs:[key]);
    return rows.isEmpty?null:rows.first['value'] as String;
  }
  Future<void> _set(String key,String value) async {
    final db=await AppDatabase.instance.database;
    await db.insert('settings',{'key':key,'value':value},conflictAlgorithm:ConflictAlgorithm.replace);
  }
  Future<bool> hasPin() async => (await _get('pin_hash'))!=null;
  Future<void> setPin(String pin) async {
    final salt=base64Url.encode(List<int>.generate(16,(_)=>Random.secure().nextInt(256)));
    await _set('pin_salt',salt); await _set('pin_hash',_hash(pin,salt));
  }
  Future<bool> verifyPin(String pin) async {
    final salt=await _get('pin_salt'); final hash=await _get('pin_hash');
    return salt!=null && hash!=null && _hash(pin,salt)==hash;
  }
  String _hash(String pin,String salt)=>sha256.convert(utf8.encode('$salt:$pin')).toString();
  Future<bool> isSectionEnabled(String id) async => (await _get('section_off_$id'))!='1';
  Future<void> setSectionEnabled(String id,bool enabled)=>_set('section_off_$id',enabled?'0':'1');
  Future<Map<String,bool>> sectionStates() async {
    final result=<String,bool>{}; for(final id in SectionIds.all){result[id]=await isSectionEnabled(id);} return result;
  }
  Future<bool> darkMode() async => (await _get('dark_mode'))=='1';
  Future<void> setDarkMode(bool value)=>_set('dark_mode',value?'1':'0');
  Future<int> dailyLimit() async => int.tryParse(await _get('daily_limit')??'0')??0;
  Future<void> setDailyLimit(int minutes)=>_set('daily_limit','$minutes');
}
