import 'package:sqflite/sqflite.dart';
import '../db/app_database.dart';
import '../models/child.dart';

class ChildRepository {
  Future<List<Child>> all() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('children', orderBy: 'id DESC');
    return rows.map(Child.fromMap).toList();
  }

  Future<Child?> byId(int id) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('children', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : Child.fromMap(rows.first);
  }

  Future<int> create(
      {required String name,
      required int age,
      required String gender,
      required String avatar}) async {
    final db = await AppDatabase.instance.database;
    return db.insert('children',
        {'name': name, 'age': age, 'gender': gender, 'avatar': avatar});
  }

  Future<void> update(Child child) async {
    final db = await AppDatabase.instance.database;
    await db.update(
        'children',
        {
          'name': child.name,
          'age': child.age,
          'gender': child.gender,
          'avatar': child.avatar,
          'stars': child.stars,
          'points': child.points,
        },
        where: 'id = ?',
        whereArgs: [child.id]);
  }

  Future<bool> purchaseAvatar(int childId, String avatar, int cost) async {
    final db = await AppDatabase.instance.database;
    if (cost < 0) return false;
    final changed = await db.rawUpdate(
      'UPDATE children SET points = points - ?, avatar = ? WHERE id = ? AND points >= ?',
      [cost, avatar, childId, cost],
    );
    return changed == 1;
  }

  Future<void> delete(int id) async {
    final db = await AppDatabase.instance.database;
    await db.transaction((txn) async {
      for (final table in ['progress', 'badges', 'usage_log', 'bookmarks']) {
        await txn.delete(table, where: 'child_id = ?', whereArgs: [id]);
      }
      await txn.delete('children', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<void> addReward(int childId,
      {required int points, required int stars}) async {
    final db = await AppDatabase.instance.database;
    await db.rawUpdate(
        'UPDATE children SET points = points + ?, stars = stars + ? WHERE id = ?',
        [points, stars, childId]);
  }

  Future<int> completedLessons(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
        "SELECT COUNT(*) AS c FROM progress WHERE child_id = ? AND status = 'done'",
        [childId]);
    return (rows.first['c'] as int?) ?? 0;
  }

  Future<int> totalSecondsUsed(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(seconds), 0) AS s FROM usage_log WHERE child_id = ?',
      [childId],
    );
    return (rows.first['s'] as int?) ?? 0;
  }

  Future<int> todaySecondsUsed(int childId) async {
    final db = await AppDatabase.instance.database;
    final day = DateTime.now().toIso8601String().substring(0, 10);
    final rows = await db.query(
      'usage_log',
      columns: ['seconds'],
      where: 'child_id = ? AND day = ?',
      whereArgs: [childId, day],
    );
    return rows.isEmpty ? 0 : ((rows.first['seconds'] as int?) ?? 0);
  }

  Future<Map<String, int>> progressSummary(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('progress',
        columns: ['score'],
        where: "child_id = ? AND status = 'done'",
        whereArgs: [childId]);
    final scores = rows.map((e) => e['score'] as int).toList();
    return {
      'completed': scores.length,
      'average':
          scores.isEmpty ? 0 : scores.reduce((a, b) => a + b) ~/ scores.length
    };
  }

  Future<bool> isCompleted(int childId, String lessonId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('progress',
        columns: ['lesson_id'],
        where: 'child_id = ? AND lesson_id = ?',
        whereArgs: [childId, lessonId]);
    return rows.isNotEmpty;
  }

  Future<void> awardBadge(int childId, String badgeId) async {
    final db = await AppDatabase.instance.database;
    await db.insert(
        'badges',
        {
          'child_id': childId,
          'badge_id': badgeId,
          'earned_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<int> badgeCount(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
        'SELECT COUNT(*) AS c FROM badges WHERE child_id = ?', [childId]);
    return (rows.first['c'] as int?) ?? 0;
  }

  Future<void> completeLesson(int childId, String lessonId, int score) async {
    final db = await AppDatabase.instance.database;
    await db.insert(
        'progress',
        {
          'child_id': childId,
          'lesson_id': lessonId,
          'status': 'done',
          'score': score,
          'completed_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> addUsage(int childId, int seconds) async {
    final db = await AppDatabase.instance.database;
    final day = DateTime.now().toIso8601String().substring(0, 10);
    await db.rawInsert(
        'INSERT INTO usage_log(child_id, day, seconds) VALUES(?,?,?) ON CONFLICT(child_id,day) DO UPDATE SET seconds = seconds + excluded.seconds',
        [childId, day, seconds]);
  }

  Future<void> toggleBookmark(int childId, String itemId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('bookmarks',
        where: 'child_id = ? AND item_id = ?', whereArgs: [childId, itemId]);
    if (rows.isEmpty) {
      await db.insert('bookmarks', {
        'child_id': childId,
        'item_id': itemId,
        'created_at': DateTime.now().toIso8601String()
      });
    } else {
      await db.delete('bookmarks',
          where: 'child_id = ? AND item_id = ?', whereArgs: [childId, itemId]);
    }
  }

  Future<List<String>> bookmarks(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      'bookmarks',
      columns: ['item_id'],
      where: 'child_id = ?',
      whereArgs: [childId],
      orderBy: 'created_at DESC',
    );
    return rows.map((e) => e['item_id'] as String).toList();
  }

  Future<bool> isBookmarked(int childId, String itemId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      'bookmarks',
      columns: ['item_id'],
      where: 'child_id = ? AND item_id = ?',
      whereArgs: [childId, itemId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }
}
