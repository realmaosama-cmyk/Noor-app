import 'dart:async';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'data/providers.dart';
class NoorApp extends ConsumerWidget {
 const NoorApp({super.key});
 @override Widget build(BuildContext context,WidgetRef ref){
  final dark=ref.watch(darkModeProvider).valueOrNull??false;
  return MaterialApp.router(title:'نور | NOOR',debugShowCheckedModeBanner:false,
   theme:AppTheme.light(),darkTheme:AppTheme.dark(),themeMode:dark?ThemeMode.dark:ThemeMode.light,
   locale:const Locale('ar','EG'),supportedLocales:const [Locale('ar','EG')],
   localizationsDelegates: GlobalMaterialLocalizations.delegates,
   routerConfig:ref.watch(routerProvider));
 }
}


/// يسجل وقت بقاء التطبيق في الواجهة الأمامية لكل ملف مستخدم.
/// القياس تقريبي ويُحفظ على دفعات قصيرة لتقليل فقد البيانات.
class UsageTrackingScope extends ConsumerStatefulWidget {
 const UsageTrackingScope({super.key, required this.child});
 final Widget child;

 @override
 ConsumerState<UsageTrackingScope> createState() => _UsageTrackingScopeState();
}

class _UsageTrackingScopeState extends ConsumerState<UsageTrackingScope>
    with WidgetsBindingObserver {
 Timer? _timer;
 DateTime _lastTick = DateTime.now();
 bool _active = true;

 @override
 void initState() {
  super.initState();
  WidgetsBinding.instance.addObserver(this);
  _timer = Timer.periodic(const Duration(seconds: 15), (_) {
   if (_active) _flushFor(ref.read(selectedChildIdProvider));
  });
 }

 @override
 void didChangeAppLifecycleState(AppLifecycleState state) {
  if (state == AppLifecycleState.resumed) {
   _lastTick = DateTime.now();
   _active = true;
  } else if (_active) {
   _flushFor(ref.read(selectedChildIdProvider));
   _active = false;
  }
 }

 void _flushFor(int? childId) {
  if (!_active) return;
  final now = DateTime.now();
  final seconds = now.difference(_lastTick).inSeconds;
  _lastTick = now;
  if (childId != null && seconds > 0) {
   unawaited(ref.read(childRepositoryProvider).addUsage(childId, seconds));
  }
 }

 @override
 Widget build(BuildContext context) {
  ref.listen<int?>(selectedChildIdProvider, (previous, next) {
   if (previous != next) _flushFor(previous);
  });
  return widget.child;
 }

 @override
 void dispose() {
  _timer?.cancel();
  WidgetsBinding.instance.removeObserver(this);
  super.dispose();
 }
}
