import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/providers.dart';
import '../../data/models/child.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    final dark = ref.watch(darkModeProvider).valueOrNull ?? false;
    return Scaffold(
        appBar: AppBar(title: const Text('ملفي الشخصي')),
        body: child.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) => const SizedBox(),
            data: (c) {
              if (c == null) return const SizedBox();
              return ListView(padding: const EdgeInsets.all(18), children: [
                Card(
                    child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(children: [
                          Text(c.avatar, style: const TextStyle(fontSize: 58)),
                          Text(c.name,
                              style: Theme.of(context).textTheme.titleLarge),
                          Text(
                              '${c.age} سنة • ${c.ageLabel} • ${c.gender == 'male' ? 'ذكر' : c.gender == 'female' ? 'أنثى' : 'غير محدد'}')
                        ]))),
                Card(
                    child: ListTile(
                        leading: const Icon(Icons.edit),
                        title: const Text('تعديل الملف الشخصي'),
                        onTap: () => _edit(context, ref, c))),
                Card(
                    child: SwitchListTile(
                        value: dark,
                        title: const Text('الوضع الليلي'),
                        secondary: const Icon(Icons.dark_mode),
                        onChanged: (v) async {
                          await ref
                              .read(settingsRepositoryProvider)
                              .setDarkMode(v);
                          ref.invalidate(darkModeProvider);
                        })),
                Card(
                    child: ListTile(
                        leading: const Icon(Icons.swap_horiz),
                        title: const Text('تغيير المستخدم'),
                        onTap: () =>
                            Navigator.of(context).popUntil((r) => r.isFirst))),
              ]);
            }));
  }

  Future<void> _edit(BuildContext context, WidgetRef ref, Child c) async {
    final name = TextEditingController(text: c.name);
    final age = ValueNotifier<int>(c.age);
    final avatar = ValueNotifier<String>(c.avatar);
    final gender = ValueNotifier<String>(c.gender);
    final save = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
                title: const Text('تعديل الملف'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: name,
                      decoration: const InputDecoration(labelText: 'الاسم')),
                  ValueListenableBuilder<int>(
                      valueListenable: age,
                      builder: (_, v, __) => Column(children: [
                            Text('العمر: $v'),
                            Slider(
                                min: 3,
                                max: 80,
                                divisions: 77,
                                value: v.toDouble(),
                                onChanged: (x) => age.value = x.round())
                          ])),
                  ValueListenableBuilder<String>(
                      valueListenable: gender,
                      builder: (_, v, __) => DropdownButtonFormField<String>(
                          initialValue: v,
                          items: const [
                            DropdownMenuItem<String>(
                                value: 'unspecified', child: Text('غير محدد')),
                            DropdownMenuItem<String>(
                                value: 'male', child: Text('ذكر')),
                            DropdownMenuItem<String>(
                                value: 'female', child: Text('أنثى'))
                          ],
                          onChanged: (x) => gender.value = x ?? v)),
                  ValueListenableBuilder<String>(
                      valueListenable: avatar,
                      builder: (_, v, __) => Wrap(
                              children: [
                            '🌟',
                            '🧑',
                            '👧',
                            '👦',
                            '🦁',
                            '🐼',
                            '🦊',
                            '🌙',
                            '🐯',
                            '🐧',
                            '🦄',
                            '🚀',
                            '🐸'
                          ]
                                  .map((a) => TextButton(
                                      onPressed: () => avatar.value = a,
                                      child: Text(a,
                                          style: TextStyle(
                                              fontSize: 24,
                                              decoration: a == v
                                                  ? TextDecoration.underline
                                                  : null))))
                                  .toList()))
                ])),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('إلغاء')),
                  FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('حفظ'))
                ]));
    if (save == true && name.text.trim().isNotEmpty) {
      await ref.read(childRepositoryProvider).update(Child(
          id: c.id,
          name: name.text.trim(),
          age: age.value,
          gender: gender.value,
          avatar: avatar.value,
          stars: c.stars,
          points: c.points));
      ref.invalidate(selectedChildProvider);
      ref.invalidate(childrenProvider);
    }
    name.dispose();
    age.dispose();
    avatar.dispose();
    gender.dispose();
  }
}
