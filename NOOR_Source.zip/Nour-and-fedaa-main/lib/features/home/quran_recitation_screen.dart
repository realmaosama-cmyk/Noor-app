import 'dart:async';
import 'package:material_ui/material_ui.dart';
import 'package:just_audio/just_audio.dart';
import '../../core/widgets/noor_brand.dart';

class QuranRecitationScreen extends StatefulWidget {
  const QuranRecitationScreen({super.key});
  @override
  State<QuranRecitationScreen> createState() => _QuranRecitationScreenState();
}

class _QuranRecitationScreenState extends State<QuranRecitationScreen> {
  final AudioPlayer player = AudioPlayer();
  StreamSubscription<PlayerState>? subscription;
  static const surahs = [
    (1, 'الفاتحة', 7),
    (103, 'العصر', 3),
    (108, 'الكوثر', 3),
    (110, 'النصر', 3),
    (112, 'الإخلاص', 4),
    (113, 'الفلق', 5),
    (114, 'الناس', 6)
  ];
  int surah = 1, ayah = 1;
  bool loading = false;
  String? error;
  bool autoAdvance = true;
  int get count => surahs.firstWhere((item) => item.$1 == surah).$3;
  String get surahName =>
      'سورة ${surahs.firstWhere((item) => item.$1 == surah).$2}';
  String get audioUrl =>
      'https://everyayah.com/data/Alafasy_128kbps/${surah.toString().padLeft(3, '0')}${ayah.toString().padLeft(3, '0')}.mp3';
  @override
  void initState() {
    super.initState();
    subscription = player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed && autoAdvance)
        _next(autoplay: true);
    });
  }

  Future<void> _play() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await player.setUrl(audioUrl);
      unawaited(player.play());
    } catch (_) {
      if (mounted)
        setState(() => error =
            'تعذر تحميل التلاوة. تحقق من اتصال الإنترنت ثم حاول مجددًا.');
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _next({bool autoplay = false}) async {
    if (ayah < count) {
      setState(() => ayah++);
    } else {
      final index = surahs.indexWhere((item) => item.$1 == surah);
      if (index < surahs.length - 1) {
        setState(() {
          surah = surahs[index + 1].$1;
          ayah = 1;
        });
      } else {
        await player.pause();
        return;
      }
    }
    if (autoplay) await _play();
  }

  Future<void> _previous() async {
    if (ayah > 1) {
      setState(() => ayah--);
    } else {
      final index = surahs.indexWhere((item) => item.$1 == surah);
      if (index > 0) {
        setState(() {
          surah = surahs[index - 1].$1;
          ayah = surahs[index - 1].$3;
        });
      } else
        return;
    }
    await _play();
  }

  @override
  void dispose() {
    subscription?.cancel();
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('تلاوة القرآن الكريم')),
      body: NoorPageBackground(
          asset: 'assets/branding/noor-bg-space.webp',
          motif: '۞',
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: const LinearGradient(
                        colors: [Color(0xFF103C58), Color(0xFF0B8C83)])),
                child: Column(children: [
                  const Icon(Icons.auto_awesome_rounded,
                      color: Color(0xFFFFD36C), size: 42),
                  const SizedBox(height: 12),
                  Text(surahName,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w900)),
                  Text('الآية $ayah من $count',
                      style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 18),
                  LinearProgressIndicator(
                      value: ayah / count,
                      color: const Color(0xFFFFD36C),
                      backgroundColor: Colors.white24),
                  const SizedBox(height: 18),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    IconButton(
                        onPressed: _previous,
                        icon: const Icon(Icons.skip_previous_rounded,
                            color: Colors.white, size: 34)),
                    const SizedBox(width: 14),
                    StreamBuilder<PlayerState>(
                        stream: player.playerStateStream,
                        builder: (context, snapshot) {
                          final playing = snapshot.data?.playing ?? false;
                          return FilledButton.tonalIcon(
                              onPressed: loading
                                  ? null
                                  : (playing ? player.pause : _play),
                              icon: Icon(loading
                                  ? Icons.hourglass_top
                                  : playing
                                      ? Icons.pause_rounded
                                      : Icons.play_arrow_rounded),
                              label: Text(loading
                                  ? 'تحميل...'
                                  : playing
                                      ? 'إيقاف مؤقت'
                                      : 'استمع'));
                        }),
                    const SizedBox(width: 14),
                    IconButton(
                        onPressed: () => _next(),
                        icon: const Icon(Icons.skip_next_rounded,
                            color: Colors.white, size: 34))
                  ])
                ])),
            const SizedBox(height: 16),
            Card(
                child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('اختر السورة',
                              style: TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 8),
                          DropdownButtonFormField<int>(
                              initialValue: surah,
                              decoration:
                                  const InputDecoration(labelText: 'السورة'),
                              items: surahs
                                  .map((item) => DropdownMenuItem<int>(
                                      value: item.$1, child: Text(item.$2)))
                                  .toList(),
                              onChanged: (value) async {
                                if (value != null) {
                                  setState(() {
                                    surah = value;
                                    ayah = 1;
                                    error = null;
                                  });
                                  await player.stop();
                                }
                              }),
                          const SizedBox(height: 12),
                          SwitchListTile(
                              contentPadding: EdgeInsets.zero,
                              title:
                                  const Text('الانتقال للآية التالية تلقائيًا'),
                              value: autoAdvance,
                              onChanged: (v) => setState(() => autoAdvance = v))
                        ]))),
            if (error != null)
              Padding(
                  padding: const EdgeInsets.all(12),
                  child:
                      Text(error!, style: const TextStyle(color: Colors.red))),
            const Card(
                child: Padding(
                    padding: EdgeInsets.all(14),
                    child: Text(
                        'القارئ: مشاري العفاسي • مصدر الملفات: EveryAyah.com. يحتاج تشغيل التلاوة إلى اتصال بالإنترنت؛ أما بقية الدروس والألعاب الأساسية فتعمل دون اتصال.'))),
          ])));
}
