import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/providers.dart';
import '../../data/content/catalog.dart';

class LibraryScreen extends ConsumerStatefulWidget {
 const LibraryScreen({super.key});
 @override ConsumerState<LibraryScreen> createState()=>_LibraryScreenState();
}
class _LibraryScreenState extends ConsumerState<LibraryScreen>{
 String query='';
 @override Widget build(BuildContext context){
  final child=ref.watch(selectedChildProvider);
  final all=noorSections.expand((s)=>s.lessons).toList();
  return Scaffold(appBar:AppBar(title:const Text('مكتبتي')),body:child.when(loading:()=>const Center(child:CircularProgressIndicator()),error:(_,__)=>const SizedBox(),data:(c){
   if(c==null)return const SizedBox();
   return Column(children:[
    Padding(padding:const EdgeInsets.all(16),child:TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'ابحث عن درس أو موضوع'))),
    Expanded(child:FutureBuilder<List<String>>(future:ref.read(childRepositoryProvider).bookmarks(c.id),builder:(ctx,snap){
     final saved=snap.data??[];
     final term = query.trim().toLowerCase();
     final filtered = all.where((lesson) => term.isEmpty ||
       lesson.title.toLowerCase().contains(term) ||
       lesson.summary.toLowerCase().contains(term) ||
       lesson.body.toLowerCase().contains(term)).toList();
     return ListView(children:[
      Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Text('محتوى المكتبة • ${saved.length} محفوظ',style:Theme.of(context).textTheme.titleMedium)),
      if (filtered.isEmpty) const Padding(padding:EdgeInsets.all(24),child:Text('لا توجد نتائج مطابقة.',textAlign:TextAlign.center)),
      for(final lesson in filtered)Card(child:ListTile(leading:Icon(saved.contains(lesson.id)?Icons.bookmark:Icons.menu_book),title:Text(lesson.title),subtitle:Text(lesson.summary),onTap:() async { await showModalBottomSheet<void>(context:context,isScrollControlled:true,builder:(_)=>_LibraryLesson(lesson:lesson,childId:c.id)); if(mounted)setState((){}); }))
     ]);
    }))
   ]);
  }));
 }
}
class _LibraryLesson extends ConsumerWidget{
 const _LibraryLesson({required this.lesson,required this.childId});
 final NoorLesson lesson;final int childId;
 @override Widget build(BuildContext context,WidgetRef ref)=>SafeArea(child:Padding(padding:const EdgeInsets.all(22),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Text(lesson.title,style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:12),Text(lesson.body,style:const TextStyle(fontSize:17,height:1.7)),const SizedBox(height:12),Text('المصدر: ${lesson.source}',style:const TextStyle(fontSize:12)),
  FilledButton.icon(onPressed:()async{await ref.read(childRepositoryProvider).toggleBookmark(childId,lesson.id);if(context.mounted)Navigator.pop(context);},icon:const Icon(Icons.bookmark_add),label:const Text('تبديل الحفظ'))
 ]))));
}
