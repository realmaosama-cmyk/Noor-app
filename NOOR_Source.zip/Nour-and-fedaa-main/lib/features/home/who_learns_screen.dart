import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';

class WhoLearnsScreen extends ConsumerWidget {
  const WhoLearnsScreen({super.key});

  Future<void> _create(BuildContext context, WidgetRef ref) async {
    final name = TextEditingController();
    final age = ValueNotifier<int>(8);
    final gender = ValueNotifier<String>('unspecified');
    final avatar = ValueNotifier<String>('🦊');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إنشاء بطل جديد'),
        content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: name,
              autofocus: true,
              decoration: const InputDecoration(
                  labelText: 'اسم المتعلم',
                  prefixIcon: Icon(Icons.face_rounded))),
          const SizedBox(height: 12),
          ValueListenableBuilder<int>(
              valueListenable: age,
              builder: (_, value, __) => Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('العمر: $value سنوات',
                            style:
                                const TextStyle(fontWeight: FontWeight.w800)),
                        Slider(
                            min: 3,
                            max: 80,
                            divisions: 77,
                            value: value.toDouble(),
                            onChanged: (v) => age.value = v.round())
                      ])),
          const SizedBox(height: 8),
          ValueListenableBuilder<String>(
              valueListenable: gender,
              builder: (_, value, __) => DropdownButtonFormField<String>(
                  initialValue: value,
                  decoration: const InputDecoration(labelText: 'النوع'),
                  items: const [
                    DropdownMenuItem(
                        value: 'unspecified', child: Text('أفضل عدم التحديد')),
                    DropdownMenuItem(value: 'male', child: Text('ذكر')),
                    DropdownMenuItem(value: 'female', child: Text('أنثى'))
                  ],
                  onChanged: (v) => gender.value = v ?? value)),
          const SizedBox(height: 14),
          const Align(
              alignment: Alignment.centerRight,
              child: Text('اختر رفيق رحلتك',
                  style: TextStyle(fontWeight: FontWeight.w800))),
          const SizedBox(height: 8),
          ValueListenableBuilder<String>(
              valueListenable: avatar,
              builder: (_, value, __) => Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    '🦊',
                    '🦁',
                    '🐼',
                    '🐯',
                    '🐸',
                    '🐧',
                    '🦄',
                    '🚀',
                    '🌟',
                    '🌙'
                  ]
                      .map((item) => ChoiceChip(
                          label:
                              Text(item, style: const TextStyle(fontSize: 22)),
                          selected: item == value,
                          onSelected: (_) => avatar.value = item))
                      .toList())),
        ])),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('ابدأ المغامرة'))
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      final id = await ref.read(childRepositoryProvider).create(
          name: name.text.trim(),
          age: age.value,
          gender: gender.value,
          avatar: avatar.value);
      ref.invalidate(childrenProvider);
      ref.read(selectedChildIdProvider.notifier).state = id;
      if (context.mounted) context.go('/home');
    }
    name.dispose();
    age.dispose();
    gender.dispose();
    avatar.dispose();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final children = ref.watch(childrenProvider);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
              Color(0xFFE3F7F3),
              Color(0xFFF5F7FF),
              Color(0xFFF8FAFB)
            ])),
        child: SafeArea(
            child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 28, 22, 18),
                child: Column(children: [
                  const NoorBrand(),
                  const SizedBox(height: 28),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: .8),
                          borderRadius: BorderRadius.circular(28)),
                      child: const Column(children: [
                        Text('✨', style: TextStyle(fontSize: 30)),
                        SizedBox(height: 6),
                        Text('من سيخوض المغامرة اليوم؟',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                color: AppColors.ink)),
                        SizedBox(height: 5),
                        Text('اختر ملفك وافتح عوالم جديدة من التعلم والمرح',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Color(0xFF617383), height: 1.5)),
                      ])),
                  const SizedBox(height: 18),
                  Expanded(
                      child: children.when(
                    loading: () =>
                        const Center(child: CircularProgressIndicator()),
                    error: (_, __) =>
                        const Center(child: Text('تعذر تحميل الملفات الشخصية')),
                    data: (list) => list.isEmpty
                        ? const Center(
                            child: Text('أنشئ أول بطل لتبدأ الرحلة!',
                                style: TextStyle(fontWeight: FontWeight.w700)))
                        : ListView.separated(
                            itemCount: list.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 10),
                            itemBuilder: (ctx, i) {
                              final child = list[i];
                              return NoorEntrance(
                                  delay: i,
                                  child: Material(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(23),
                                      child: InkWell(
                                          borderRadius:
                                              BorderRadius.circular(23),
                                          onTap: () {
                                            ref
                                                .read(selectedChildIdProvider
                                                    .notifier)
                                                .state = child.id;
                                            context.go('/home');
                                          },
                                          child: Padding(
                                              padding: const EdgeInsets.all(15),
                                              child: Row(children: [
                                                CircleAvatar(
                                                    radius: 27,
                                                    backgroundColor:
                                                        AppColors.lavender,
                                                    child: Text(child.avatar,
                                                        style: const TextStyle(
                                                            fontSize: 28))),
                                                const SizedBox(width: 13),
                                                Expanded(
                                                    child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                      Text(child.name,
                                                          style: const TextStyle(
                                                              fontSize: 17,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w900)),
                                                      Text(
                                                          '${child.age} سنة • ${child.ageLabel} • المستوى ${child.level}',
                                                          style:
                                                              const TextStyle(
                                                                  color: Colors
                                                                      .blueGrey,
                                                                  fontSize: 12))
                                                    ])),
                                                const Icon(
                                                    Icons
                                                        .play_circle_fill_rounded,
                                                    color: AppColors.teal,
                                                    size: 30),
                                              ])))));
                            },
                          ),
                  )),
                  SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                              backgroundColor: AppColors.teal,
                              minimumSize: const Size.fromHeight(56)),
                          onPressed: () => _create(context, ref),
                          icon: const Icon(Icons.add_rounded),
                          label: const Text('إنشاء بطل جديد'))),
                  TextButton.icon(
                      onPressed: () => context.push('/parent'),
                      icon: const Icon(Icons.family_restroom_rounded),
                      label: const Text('مساحة ولي الأمر')),
                ]))),
      ),
    );
  }
}
