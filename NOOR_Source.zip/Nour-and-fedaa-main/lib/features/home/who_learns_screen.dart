import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/providers.dart';

class WhoLearnsScreen extends ConsumerWidget {
 const WhoLearnsScreen({super.key});
 Future<void> _create(BuildContext context,WidgetRef ref) async {
  final name=TextEditingController(); final age=ValueNotifier<int>(8);
  final gender=ValueNotifier<String>('unspecified'); final avatar=ValueNotifier<String>('🌟');
  final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
   title:const Text('إنشاء ملف جديد'),
   content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    TextField(controller:name,decoration:const InputDecoration(labelText:'اسم المستخدم')),
    const SizedBox(height:12),ValueListenableBuilder<int>(valueListenable:age,builder:(_,v,__)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
     Text('العمر: $v سنة'),Slider(min:3,max:80,divisions:77,value:v.toDouble(),onChanged:(x)=>age.value=x.round())])),
    const SizedBox(height:8),ValueListenableBuilder<String>(valueListenable:gender,builder:(_,v,__)=>DropdownButtonFormField<String>(initialValue:v,decoration:const InputDecoration(labelText:'النوع'),items:const [
     DropdownMenuItem<String>(value:'unspecified',child:Text('أفضل عدم التحديد')),DropdownMenuItem<String>(value:'male',child:Text('ذكر')),DropdownMenuItem<String>(value:'female',child:Text('أنثى'))],onChanged:(x)=>gender.value=x??v)),
    const SizedBox(height:12),const Align(alignment:Alignment.centerRight,child:Text('اختر الشخصية')),
    ValueListenableBuilder<String>(valueListenable:avatar,builder:(_,v,__)=>Wrap(spacing:8,children:['🌟','🧑','👧','👦','🦁','🐼','🦊','🌙'].map((a)=>ChoiceChip(label:Text(a,style:const TextStyle(fontSize:22)),selected:a==v,onSelected:(_)=>avatar.value=a)).toList()))
   ])),
   actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('إنشاء'))]));
  if(ok==true && name.text.trim().isNotEmpty){
   final id=await ref.read(childRepositoryProvider).create(name:name.text.trim(),age:age.value,gender:gender.value,avatar:avatar.value);
   ref.invalidate(childrenProvider); ref.read(selectedChildIdProvider.notifier).state=id;
   if(context.mounted)context.go('/home');
  }
  name.dispose();age.dispose();gender.dispose();avatar.dispose();
 }
 @override Widget build(BuildContext context,WidgetRef ref){
  final children=ref.watch(childrenProvider);
  return Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[
   const SizedBox(height:24),Container(width:76,height:76,decoration:const BoxDecoration(shape:BoxShape.circle,color:Color(0xFF168C83)),child:const Center(child:Icon(Icons.auto_awesome,color:Colors.white,size:38))),
   const SizedBox(height:12),Text('نــور',style:Theme.of(context).textTheme.headlineMedium),const Text('رحلة معرفة تنمو معك',style:TextStyle(color:Colors.grey)),
   const SizedBox(height:28),Text('من سيتعلم اليوم؟',style:Theme.of(context).textTheme.titleLarge),
   Expanded(child:children.when(loading:()=>const Center(child:CircularProgressIndicator()),error:(_,__)=>const Center(child:Text('تعذر تحميل الملفات الشخصية')),data:(list)=>ListView(padding:const EdgeInsets.only(top:18),children:[
    for(final c in list)Card(child:ListTile(contentPadding:const EdgeInsets.all(14),leading:CircleAvatar(radius:28,child:Text(c.avatar,style:const TextStyle(fontSize:26))),title:Text(c.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${c.age} سنة • ${c.ageLabel} • المستوى ${c.level}'),trailing:const Icon(Icons.arrow_forward_ios),onTap:(){ref.read(selectedChildIdProvider.notifier).state=c.id;context.go('/home');})),
    if(list.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('ابدأ بإنشاء أول ملف تعليمي.',textAlign:TextAlign.center))
   ]))),
   SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>_create(context,ref),icon:const Icon(Icons.add),label:const Text('إضافة مستخدم'))),
   TextButton.icon(onPressed:()=>context.push('/parent'),icon:const Icon(Icons.family_restroom),label:const Text('لوحة ولي الأمر'))
  ]))));
 }
}
