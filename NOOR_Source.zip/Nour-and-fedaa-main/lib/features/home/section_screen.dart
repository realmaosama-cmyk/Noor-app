import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/content/catalog.dart';
import '../../data/providers.dart';
import '../../data/models/child.dart';
import '../../core/widgets/noor_brand.dart';
import '../../core/services/noor_voice.dart';

class SectionScreen extends ConsumerWidget {
  const SectionScreen({super.key, required this.sectionId});
  final String sectionId;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    if (sectionId == 'achievements') return const _AchievementsScreen();
    final section = sectionById(sectionId);
    if (section == null)
      return const Scaffold(body: Center(child: Text('القسم غير موجود')));
    final art = switch (section.id) {
      'quran' ||
      'prophets' ||
      'figures' =>
        'assets/branding/noor-bg-forest.webp',
      'prayer' => 'assets/branding/noor-bg-1.jpg',
      'adhkar' || 'challenges' => 'assets/branding/noor-bg-space.webp',
      'akhlaq' || 'seerah' => 'assets/branding/noor-bg-2.jpg',
      'learn' => 'assets/branding/noor-bg-3.jpg',
      'space' ||
      'science' ||
      'coding' ||
      'future' ||
      'engineering' =>
        'assets/branding/noor-bg-space.webp',
      'animals' ||
      'nature' ||
      'sports' ||
      'cooking' =>
        'assets/branding/noor-bg-forest.webp',
      _ => 'assets/branding/noor-bg-ocean.webp',
    };
    final motif = switch (section.id) {
      'quran' => '۞',
      'prayer' => '🕌',
      'adhkar' => '🌙',
      'akhlaq' => '💚',
      'seerah' => '🌟',
      'figures' => '⭐',
      'prophets' => '🌿',
      _ => section.emoji
    };
    return Scaffold(
        appBar: AppBar(title: Text(section.title)),
        body: NoorPageBackground(
            asset: art,
            motif: motif,
            child: child.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => const Center(child: Text('تعذر تحميل الملف')),
                data: (c) {
                  if (c == null)
                    return const Center(child: Text('اختر مستخدمًا أولًا'));
                  final lessons = lessonsForAge(section, c);
                  return ListView(padding: const EdgeInsets.all(16), children: [
                    Text(section.description,
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    if (lessons.isEmpty)
                      const Card(
                          child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Text(
                                  'لا يوجد محتوى مناسب لهذه المرحلة حاليًا.'))),
                    for (final lesson in lessons)
                      FutureBuilder<bool>(
                          future: ref
                              .read(childRepositoryProvider)
                              .isCompleted(c.id, lesson.id),
                          builder: (ctx, snapshot) {
                            final done = snapshot.data ?? false;
                            return Card(
                                child: ListTile(
                                    leading: CircleAvatar(
                                        child: Icon(done
                                            ? Icons.check
                                            : Icons.menu_book)),
                                    title: Text(lesson.title),
                                    subtitle: Text(lesson.summary),
                                    trailing: Icon(
                                        done
                                            ? Icons.verified
                                            : Icons.chevron_left,
                                        color: done ? Colors.green : null),
                                    onTap: () => showModalBottomSheet<void>(
                                        context: context,
                                        isScrollControlled: true,
                                        builder: (_) => _LessonSheet(
                                            lesson: lesson, child: c))));
                          })
                  ]);
                })));
  }
}

class _LessonSheet extends ConsumerStatefulWidget {
  const _LessonSheet({required this.lesson, required this.child});
  final NoorLesson lesson;
  final Child child;
  @override
  ConsumerState<_LessonSheet> createState() => _LessonSheetState();
}

class _LessonSheetState extends ConsumerState<_LessonSheet> {
  int question = 0;
  int? selected;
  int correct = 0;
  bool finished = false;
  bool saved = false;
  bool bookmarkLoaded = false;
  @override
  void initState() {
    super.initState();
    _loadBookmark();
  }

  Future<void> _loadBookmark() async {
    final value = await ref
        .read(childRepositoryProvider)
        .isBookmarked(widget.child.id, widget.lesson.id);
    if (mounted)
      setState(() {
        saved = value;
        bookmarkLoaded = true;
      });
  }

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;
    final repo = ref.read(childRepositoryProvider);
    return SafeArea(
        child: Padding(
            padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20),
            child: SingleChildScrollView(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                  Row(children: [
                    Expanded(
                        child: Text(lesson.title,
                            style: Theme.of(context).textTheme.titleLarge)),
                    IconButton(
                        tooltip: 'استمع للدرس',
                        onPressed: () => NoorVoice.speak(
                            '${lesson.title}. ${_lessonBodyFor(widget.child, lesson)}'),
                        icon: const Icon(Icons.volume_up_rounded)),
                    IconButton(
                        onPressed: !bookmarkLoaded
                            ? null
                            : () async {
                                await repo.toggleBookmark(
                                    widget.child.id, lesson.id);
                                if (mounted) setState(() => saved = !saved);
                              },
                        icon: Icon(
                            saved ? Icons.bookmark : Icons.bookmark_border))
                  ]),
                  const SizedBox(height: 10),
                  Text(_lessonBodyFor(widget.child, lesson),
                      style: const TextStyle(fontSize: 17, height: 1.7)),
                  const SizedBox(height: 10),
                  Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(12)),
                      child: Text('المصدر: ${lesson.source}',
                          style: const TextStyle(fontSize: 12))),
                  const SizedBox(height: 20),
                  if (!finished) ...[
                    Text(
                        'اختبر فهمك • السؤال ${question + 1} من ${lesson.questions.length}',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 10),
                    Text(lesson.questions[question].prompt,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    for (var i = 0;
                        i < lesson.questions[question].options.length;
                        i++)
                      Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: OutlinedButton(
                              onPressed: selected == null
                                  ? () => setState(() => selected = i)
                                  : null,
                              style: OutlinedButton.styleFrom(
                                  backgroundColor: selected == i
                                      ? Theme.of(context)
                                          .colorScheme
                                          .primaryContainer
                                      : null),
                              child:
                                  Text(lesson.questions[question].options[i]))),
                    if (selected != null)
                      Text(
                          selected == lesson.questions[question].answer
                              ? 'إجابة صحيحة! ${lesson.questions[question].explanation}'
                              : 'حاول مرة أخرى. ${lesson.questions[question].explanation}',
                          style: TextStyle(
                              color:
                                  selected == lesson.questions[question].answer
                                      ? Colors.green
                                      : Colors.deepOrange)),
                    const SizedBox(height: 12),
                    FilledButton(
                        onPressed: selected == null
                            ? null
                            : () {
                                if (selected ==
                                    lesson.questions[question].answer)
                                  correct++;
                                if (question + 1 < lesson.questions.length) {
                                  setState(() {
                                    question++;
                                    selected = null;
                                  });
                                } else
                                  setState(() => finished = true);
                              },
                        child: Text(question + 1 == lesson.questions.length
                            ? 'إنهاء الاختبار'
                            : 'السؤال التالي'))
                  ] else ...[
                    const Icon(Icons.emoji_events,
                        color: Color(0xFFD6A84F), size: 54),
                    Text('أحسنت يا ${widget.child.name}!',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleLarge),
                    Text('إجابات صحيحة: $correct من ${lesson.questions.length}',
                        textAlign: TextAlign.center),
                    FilledButton(
                        onPressed: () async {
                          final score =
                              (correct * 100 / lesson.questions.length).round();
                          final already = await repo.isCompleted(
                              widget.child.id, lesson.id);
                          final completedBefore =
                              await repo.completedLessons(widget.child.id);
                          await repo.completeLesson(
                              widget.child.id, lesson.id, score);
                          if (!already) {
                            await repo.addReward(widget.child.id,
                                points: score == 100 ? 30 : 15,
                                stars: score == 100 ? 2 : 1);
                            if (completedBefore == 0)
                              await repo.awardBadge(
                                  widget.child.id, 'first_lesson');
                            if (completedBefore == 4)
                              await repo.awardBadge(
                                  widget.child.id, 'five_lessons');
                            if (completedBefore == 9)
                              await repo.awardBadge(
                                  widget.child.id, 'ten_lessons');
                          }
                          ref.invalidate(selectedChildProvider);
                          ref.invalidate(childrenProvider);
                          if (context.mounted) Navigator.pop(context);
                        },
                        child: const Text('حفظ الإنجاز'))
                  ]
                ]))));
  }
}

class _AchievementsScreen extends ConsumerWidget {
  const _AchievementsScreen();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = ref.watch(selectedChildProvider);
    return Scaffold(
        appBar: AppBar(title: const Text('إنجازاتي')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-ocean.webp',
            child: c.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => const SizedBox(),
                data: (child) {
                  if (child == null) return const SizedBox();
                  return FutureBuilder<Map<String, int>>(
                      future: ref
                          .read(childRepositoryProvider)
                          .progressSummary(child.id),
                      builder: (ctx, s) {
                        final summary =
                            s.data ?? {'completed': 0, 'average': 0};
                        return ListView(
                            padding: const EdgeInsets.all(20),
                            children: [
                              Card(
                                  child: Padding(
                                      padding: const EdgeInsets.all(22),
                                      child: Column(children: [
                                        Text(child.avatar,
                                            style:
                                                const TextStyle(fontSize: 52)),
                                        Text(child.name,
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleLarge),
                                        Text(
                                            'المستوى ${child.level} • ${child.points} نقطة • ${child.stars} نجمة')
                                      ]))),
                              _stat(context, 'الدروس المكتملة',
                                  '${summary['completed']}', Icons.menu_book),
                              _stat(context, 'متوسط نتائج الاختبارات',
                                  '${summary['average']}%', Icons.insights),
                              FutureBuilder<int>(
                                  future: ref
                                      .read(childRepositoryProvider)
                                      .badgeCount(child.id),
                                  builder: (ctx, b) => _stat(
                                      context,
                                      'الشارات المكتسبة',
                                      '${b.data ?? 0}',
                                      Icons.workspace_premium)),
                              const Card(
                                  child: Padding(
                                      padding: EdgeInsets.all(16),
                                      child: Text(
                                          'استمر في التعلم والمراجعة، فكل خطوة صغيرة تقربك من هدفك.')))
                            ]);
                      });
                })));
  }

  Widget _stat(BuildContext c, String title, String value, IconData icon) =>
      Card(
          child: ListTile(
              leading: Icon(icon),
              title: Text(title),
              trailing: Text(value, style: Theme.of(c).textTheme.titleLarge)));
}

String _lessonBodyFor(Child child, NoorLesson lesson) {
  final opening = lesson.body.split('.').first.trim();
  return switch (child.ageGroup) {
    AgeGroup.discovery => '${lesson.summary}. $opening.',
    AgeGroup.adventure => '${lesson.summary}.\n\n${lesson.body}',
    AgeGroup.challenge =>
      '${lesson.body}\n\nفكّر: كيف يمكن أن تطبّق ما تعلمته في حياتك اليومية؟',
    AgeGroup.independence =>
      '${lesson.body}\n\nسؤال للتأمل: ما الفكرة الأساسية؟ وكيف تشرحها لشخص آخر؟',
    AgeGroup.adult =>
      '${lesson.body}\n\nللتوسع: راجع المصدر المذكور، وتأمل في المعنى والسياق قبل استخلاص النتائج.',
  };
}
