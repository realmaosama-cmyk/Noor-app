import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/child.dart';
import '../../data/providers.dart';

class NoorGamesScreen extends ConsumerStatefulWidget {
  const NoorGamesScreen({super.key});
  @override
  ConsumerState<NoorGamesScreen> createState() => _NoorGamesScreenState();
}

class _NoorGamesScreenState extends ConsumerState<NoorGamesScreen> {
  int mode = 0;
  int round = 0;
  int score = 0;
  int? selected;
  bool answered = false;
  late List<int> order;
  final math.Random random = math.Random();
  static const icons = ['🌙', '⭐', '🌈', '🪐', '🌻', '🦋'];
  @override
  void initState() {
    super.initState();
    order = List.generate(6, (i) => i);
  }

  void next() {
    setState(() {
      round++;
      selected = null;
      answered = false;
      order.shuffle(random);
    });
  }

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    if (child == null)
      return const Scaffold(
          body: Center(child: Text('اختَر ملف المتعلم أولًا')));
    final question = _question(child, round);
    return Scaffold(
        appBar: AppBar(title: const Text('ملعب نور 🎮')),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          _HubBanner(
              emoji: '🎮',
              title: 'أهلًا في ملعب نور',
              subtitle: 'تحديات تتدرج مع عمرك • ${child.ageLabel}'),
          const SizedBox(height: 16),
          Wrap(spacing: 8, children: [
            ChoiceChip(
                label: const Text('مطابقة'),
                selected: mode == 0,
                onSelected: (_) {
                  setState(() => mode = 0);
                  next();
                }),
            ChoiceChip(
                label: const Text('رياضيات'),
                selected: mode == 1,
                onSelected: (_) {
                  setState(() => mode = 1);
                  next();
                }),
            ChoiceChip(
                label: const Text('منطق'),
                selected: mode == 2,
                onSelected: (_) {
                  setState(() => mode = 2);
                  next();
                }),
          ]),
          const SizedBox(height: 14),
          Card(
              child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(children: [
                          Expanded(
                              child: Text(
                                  mode == 0
                                      ? 'اعثر على الرمز المطلوب'
                                      : mode == 1
                                          ? 'حل التحدي الحسابي'
                                          : 'فكّر واختر النمط الصحيح',
                                  style:
                                      Theme.of(context).textTheme.titleLarge)),
                          Chip(label: Text('النقاط $score'))
                        ]),
                        const SizedBox(height: 18),
                        if (mode == 0) ...[
                          Text('ابحث عن: ${icons[(round + 2) % icons.length]}',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 42)),
                          const SizedBox(height: 14),
                          GridView.count(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              crossAxisCount: 3,
                              children: [
                                for (var i in order)
                                  Padding(
                                      padding: const EdgeInsets.all(5),
                                      child: _GameTile(
                                          label: icons[i],
                                          selected: selected == i,
                                          onTap: answered
                                              ? null
                                              : () async {
                                                  setState(() {
                                                    selected = i;
                                                    answered = true;
                                                    if (i ==
                                                        (round + 2) %
                                                            icons.length)
                                                      score += 10;
                                                  });
                                                  if (i ==
                                                      (round + 2) %
                                                          icons.length)
                                                    await _award(child.id);
                                                }))
                              ]),
                          if (answered)
                            Text(
                                selected == (round + 2) % icons.length
                                    ? 'أحسنت! وجدت الرمز 🎉'
                                    : 'محاولة جميلة! جرّب جولة أخرى.',
                                textAlign: TextAlign.center),
                        ] else ...[
                          Text(question.$1,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 28, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 16),
                          for (var i = 0; i < question.$2.length; i++)
                            Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: OutlinedButton(
                                    onPressed: answered
                                        ? null
                                        : () async {
                                            setState(() {
                                              selected = i;
                                              answered = true;
                                              if (i == question.$3) score += 10;
                                            });
                                            if (i == question.$3)
                                              await _award(child.id);
                                          },
                                    child: Text(question.$2[i],
                                        style: const TextStyle(fontSize: 18)))),
                          if (answered)
                            Text(
                                selected == question.$3
                                    ? 'إجابة صحيحة! +10 نقاط ⭐'
                                    : 'الإجابة الصحيحة: ${question.$2[question.$3]}',
                                textAlign: TextAlign.center),
                        ],
                        const SizedBox(height: 12),
                        FilledButton.icon(
                            onPressed: answered ? next : null,
                            icon: const Icon(Icons.arrow_forward_rounded),
                            label: const Text('التحدي التالي')),
                      ]))),
          const SizedBox(height: 12),
          Text(_gameHint(child), style: Theme.of(context).textTheme.bodyMedium),
          const Card(
              child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Text(
                      'الألعاب تعمل دون إنترنت. كل إجابة صحيحة تمنحك 10 نقاط ونجمة تُضاف إلى ملفك على هذا الجهاز.'))),
        ]));
  }

  (String, List<String>, int) _question(Child c, int n) {
    if (mode == 1) {
      final a = 2 + n % (c.age <= 8 ? 5 : 18);
      final b = 1 + (n * 3) % (c.age <= 8 ? 5 : 17);
      return ('$a + $b = ؟', ['$a', '${a + b}', '${a + b + 2}'], 1);
    }
    final items = c.age <= 8
        ? ('ما الذي يأتي بعد: ⭐ 🌙 ⭐ 🌙 ؟', ['⭐', '🌈', '🌻'], 0)
        : c.age <= 13
            ? ('إذا كان كل مربع = 4، فكم يساوي مربعان؟', ['6', '8', '12'], 1)
            : ('أي اختيار يكمل النمط: 2، 4، 8، 16، ؟', ['18', '24', '32'], 2);
    return items;
  }

  Future<void> _award(int childId) async {
    await ref
        .read(childRepositoryProvider)
        .addReward(childId, points: 10, stars: 1);
    ref.invalidate(selectedChildProvider);
    ref.invalidate(childrenProvider);
  }

  String _gameHint(Child c) => c.age <= 5
      ? 'تعرّف إلى الأشكال والألوان بهدوء، ولا يوجد وقت محدد للإجابة.'
      : c.age <= 9
          ? 'جرّب تذكر مواقع الرموز، وخذ وقتك في التفكير.'
          : c.age <= 13
              ? 'ابحث عن العلاقة بين الأرقام قبل اختيار الإجابة.'
              : 'حلّل النمط، وجرّب استراتيجية مختلفة إذا احتجت.';
}

class NoorStoriesScreen extends ConsumerWidget {
  const NoorStoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    final young = (child?.age ?? 8) <= 8;
    final role = child?.gender == 'female'
        ? 'قائدة نور'
        : child?.gender == 'male'
            ? 'قائد نور'
            : 'صديق نور';
    final stories = young
        ? const [
            (
              '🐢',
              'السلحفاة والنجم',
              'ساعد السلحفاة في اختيار الطريق الآمن إلى النجم.',
              'التأني والمثابرة'
            ),
            (
              '🌱',
              'بذرة صغيرة',
              'اختر ما تحتاجه البذرة لتنمو وتصبح شجرة.',
              'العناية بالطبيعة'
            ),
          ]
        : const [
            (
              '🧭',
              'سر الخريطة القديمة',
              'أمامك ثلاث طرق؛ اختر الأدلة التي تقودك للحل.',
              'الاستدلال واتخاذ القرار'
            ),
            (
              '🚀',
              'مهمة محطة الفضاء',
              'ساعد الفريق على توزيع الموارد وحل المشكلة.',
              'التعاون والتخطيط'
            ),
          ];
    return Scaffold(
      appBar: AppBar(title: const Text('قصص ومغامرات 📚')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _HubBanner(
            emoji: '📖',
            title: '$role • كل اختيار يصنع حكاية',
            subtitle: 'قصص قصيرة بمواقف وقرارات مناسبة لمرحلتك',
          ),
          for (final story in stories)
            Card(
              child: ListTile(
                isThreeLine: true,
                leading: Text(story.$1, style: const TextStyle(fontSize: 34)),
                title: Text(story.$2),
                subtitle: Text('${story.$3}\nالمهارة: ${story.$4}'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => showDialog<void>(
                  context: context,
                  builder: (_) => _StoryDialog(
                    title: story.$2,
                    intro: story.$3,
                    skill: story.$4,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StoryDialog extends StatefulWidget {
  const _StoryDialog(
      {required this.title, required this.intro, required this.skill});
  final String title;
  final String intro;
  final String skill;

  @override
  State<_StoryDialog> createState() => _StoryDialogState();
}

class _StoryDialogState extends State<_StoryDialog> {
  int? choice;
  static const options = [
    'أفكر في الحل وأجربه بنفسي.',
    'أبحث عن معلومة أو دليل إضافي.',
    'أتعاون مع صديق أو أحد أفراد أسرتي.',
  ];

  @override
  Widget build(BuildContext context) {
    final endings = [
      'خطوة شجاعة! التجربة تساعدك على اكتشاف ما ينجح وما يحتاج إلى تعديل.',
      'اختيار ذكي! جمع المعلومات قبل القرار يجعل رؤيتك أوضح.',
      'عمل رائع! مشاركة الأفكار قد تفتح حلولًا لم تكن ظاهرة من البداية.',
    ];
    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(widget.intro),
          const SizedBox(height: 14),
          if (choice == null) ...[
            const Text('ماذا ستفعل؟',
                style: TextStyle(fontWeight: FontWeight.w800)),
            for (var i = 0; i < options.length; i++)
              Padding(
                padding: const EdgeInsets.only(top: 7),
                child: OutlinedButton(
                  onPressed: () => setState(() => choice = i),
                  child: Text(options[i]),
                ),
              ),
          ] else ...[
            Text(endings[choice!]),
            const SizedBox(height: 8),
            Text('المهارة التي تدربت عليها: ${widget.skill}'),
          ],
        ],
      ),
      actions: [
        if (choice != null)
          TextButton(
              onPressed: () => setState(() => choice = null),
              child: const Text('اختيار آخر')),
        FilledButton(
          onPressed: choice == null ? null : () => Navigator.pop(context),
          child: const Text('إنهاء القصة'),
        ),
      ],
    );
  }
}

class NoorStudioScreen extends StatefulWidget {
  const NoorStudioScreen({super.key});

  @override
  State<NoorStudioScreen> createState() => _NoorStudioScreenState();
}

class _NoorStudioScreenState extends State<NoorStudioScreen> {
  final List<Offset?> points = [];
  Color color = const Color(0xFF0D9488);
  double stroke = 6;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('استوديو الإبداع 🎨'),
        actions: [
          IconButton(
            onPressed: () => setState(points.clear),
            icon: const Icon(Icons.delete_outline),
            tooltip: 'مسح اللوحة',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              spacing: 12,
              children: [
                for (final swatch in [
                  const Color(0xFF0D9488),
                  const Color(0xFFFF796C),
                  const Color(0xFF7566D9),
                  const Color(0xFFFFC857),
                  Colors.black,
                ])
                  InkWell(
                    onTap: () => setState(() => color = swatch),
                    child: CircleAvatar(
                      backgroundColor: swatch,
                      radius: 18,
                      child: color == swatch
                          ? const Icon(Icons.check, color: Colors.white)
                          : null,
                    ),
                  ),
                IconButton(
                  onPressed: () =>
                      setState(() => stroke = stroke == 6 ? 14 : 6),
                  icon: const Icon(Icons.brush),
                ),
              ],
            ),
          ),
          Expanded(
            child: Builder(
              builder: (canvasContext) => GestureDetector(
                onPanUpdate: (details) {
                  final box = canvasContext.findRenderObject()! as RenderBox;
                  setState(() =>
                      points.add(box.globalToLocal(details.globalPosition)));
                },
                onPanEnd: (_) => setState(() => points.add(null)),
                child: Container(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  width: double.infinity,
                  child: CustomPaint(
                    painter: _DrawingPainter(points, color, stroke),
                    child: const Center(
                      child: Text(
                        'ارسم فكرتك هنا ✨',
                        style: TextStyle(color: Colors.black26, fontSize: 20),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(12),
            child:
                Text('مساحة رسم محلية؛ لا يتم رفع رسومات الطفل إلى أي خادم.'),
          ),
        ],
      ),
    );
  }
}

class _DrawingPainter extends CustomPainter {
  _DrawingPainter(this.points, this.color, this.width);
  final List<Offset?> points;
  final Color color;
  final double width;
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < points.length - 1; i++) {
      final a = points[i], b = points[i + 1];
      if (a != null && b != null) canvas.drawLine(a, b, p);
    }
  }

  @override
  bool shouldRepaint(covariant _DrawingPainter old) =>
      old.points != points || old.color != color || old.width != width;
}

class NoorLabScreen extends ConsumerStatefulWidget {
  const NoorLabScreen({super.key});
  @override
  ConsumerState<NoorLabScreen> createState() => _NoorLabScreenState();
}

class _NoorLabScreenState extends ConsumerState<NoorLabScreen> {
  double temperature = 20;
  bool showCloud = false;
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('مختبر الاكتشاف 🔬')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const _HubBanner(
            emoji: '🧪',
            title: 'جرّب ولاحظ',
            subtitle: 'محاكاة تعليمية آمنة تعمل على الجهاز'),
        Card(
            child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(children: [
                  const Text('رحلة قطرة الماء',
                      style:
                          TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  Text(
                      temperature < 10
                          ? '❄️ تتجمد المياه في ظروف مناسبة.'
                          : temperature > 75
                              ? '♨️ يتبخر الماء ويتحول إلى بخار.'
                              : '💧 الماء في الحالة السائلة.',
                      style: const TextStyle(fontSize: 25),
                      textAlign: TextAlign.center),
                  Slider(
                      value: temperature,
                      min: 0,
                      max: 100,
                      divisions: 20,
                      label: '${temperature.round()}°',
                      onChanged: (v) => setState(() => temperature = v)),
                  Text('درجة الحرارة الافتراضية: ${temperature.round()}°'),
                  const SizedBox(height: 8),
                  FilledButton(
                      onPressed: () => setState(() => showCloud = !showCloud),
                      child: Text(
                          showCloud ? 'إخفاء دورة الماء' : 'اعرض دورة الماء')),
                  if (showCloud)
                    const Text('☀️ تبخر ← ☁️ تكاثف ← 🌧️ هطول ← 🌊 تجمع',
                        style: TextStyle(fontSize: 17),
                        textAlign: TextAlign.center)
                ]))),
        const Card(
            child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    'هذه محاكاة مبسطة للتعلم وليست تجربة مخبرية أو قياسًا علميًا حقيقيًا. لا تستخدم حرارة أو أدوات حقيقية دون إشراف شخص بالغ.')))
      ]));
}

class NoorGuideScreen extends ConsumerStatefulWidget {
  const NoorGuideScreen({super.key});

  @override
  ConsumerState<NoorGuideScreen> createState() => _NoorGuideScreenState();
}

class _NoorGuideScreenState extends ConsumerState<NoorGuideScreen> {
  final controller = TextEditingController();
  String? answer;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void ask(int age) {
    final question = controller.text.trim();
    if (question.isEmpty) return;
    final lower = question.toLowerCase();
    final response = age <= 5
        ? 'لنبدأ بصورة أو مثال بسيط. ما الشيء الذي تعرفه ويشبه هذا السؤال؟ اطلب من شخص كبير أن يقرأه معك.'
        : age <= 9
            ? lower.contains('رياض') || lower.contains('حساب')
                ? 'قسّم المسألة إلى أرقام صغيرة، واستخدم الرسم أو العدّ، ثم راجع الناتج.'
                : 'اقرأ السؤال ببطء، وحدد الكلمة المهمة، ثم جرّب خطوة واحدة في كل مرة.'
            : age <= 13
                ? 'اكتب المعلومات المتاحة، وحدد المطلوب، ثم جرّب طريقتين للحل وقارن النتيجة.'
                : 'حوّل السؤال إلى فرضية قابلة للفحص، وحدد ما تحتاج إلى التحقق منه من مصدر موثوق.';
    setState(() => answer = response);
  }

  @override
  Widget build(BuildContext context) {
    final age = ref.watch(selectedChildProvider).valueOrNull?.age ?? 8;
    return Scaffold(
      appBar: AppBar(title: const Text('مرشد نور ✨')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _HubBanner(
            emoji: '💡',
            title: 'اسأل عن طريقة الحل',
            subtitle: 'تلميحات تعليمية محلية مناسبة لعمرك، دون اتصال بالإنترنت',
          ),
          const SizedBox(height: 14),
          TextField(
            controller: controller,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'ما السؤال الذي تريد مساعدة فيه؟',
              hintText: 'اكتب السؤال أو الجزء الذي لم تفهمه...',
              prefixIcon: Icon(Icons.question_answer_outlined),
            ),
            onChanged: (_) => setState(() => answer = null),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => ask(age),
            icon: const Icon(Icons.lightbulb_outline),
            label: const Text('أرني تلميحًا'),
          ),
          if (answer != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(answer!,
                    style: const TextStyle(fontSize: 17, height: 1.6)),
              ),
            ),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'مرشد نور في هذا الإصدار يستخدم قواعد وتلميحات معدّة مسبقًا على الجهاز، وليس نموذج ذكاء اصطناعي متصلًا أو محادثة حرة. لا تكتب بيانات شخصية في الأسئلة.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HubBanner extends StatelessWidget {
  const _HubBanner(
      {required this.emoji, required this.title, required this.subtitle});
  final String emoji, title, subtitle;
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
              colors: [Color(0xFF155E75), Color(0xFF0D9488)])),
      child: Row(children: [
        Text(emoji, style: const TextStyle(fontSize: 40)),
        const SizedBox(width: 14),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 21,
                  fontWeight: FontWeight.w900)),
          Text(subtitle,
              style: const TextStyle(color: Colors.white70, height: 1.5))
        ]))
      ]));
}

class _GameTile extends StatelessWidget {
  const _GameTile(
      {required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => AnimatedScale(
      scale: selected ? 1.08 : 1,
      duration: const Duration(milliseconds: 180),
      child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(18),
                  border: selected
                      ? Border.all(
                          color: Theme.of(context).colorScheme.primary,
                          width: 2)
                      : null),
              child: Center(
                  child: Text(label, style: const TextStyle(fontSize: 36))))));
}
