import 'package:material_ui/material_ui.dart';
import 'package:go_router/go_router.dart';
import '../../core/widgets/noor_brand.dart';

class NoorWelcomeScreen extends StatefulWidget {
  const NoorWelcomeScreen({super.key});
  @override
  State<NoorWelcomeScreen> createState() => _NoorWelcomeScreenState();
}

class _NoorWelcomeScreenState extends State<NoorWelcomeScreen>
    with TickerProviderStateMixin {
  late final AnimationController _stars = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 5),
  )..repeat();
  late final AnimationController _intro = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..forward();

  @override
  void dispose() {
    _stars.dispose();
    _intro.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0B6575), Color(0xFF0C9E91), Color(0xFFB9E9D9)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Positioned(
                top: 45,
                left: 24,
                child: _FloatEmoji(controller: _stars, emoji: '✦', size: 30),
              ),
              Positioned(
                top: 135,
                right: 35,
                child: _FloatEmoji(controller: _stars, emoji: '⭐', size: 23),
              ),
              Positioned(
                bottom: 170,
                left: 35,
                child: _FloatEmoji(controller: _stars, emoji: '☁️', size: 44),
              ),
              Center(
                child: FadeTransition(
                  opacity: _intro,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, .12),
                      end: Offset.zero,
                    ).animate(CurvedAnimation(
                      parent: _intro,
                      curve: Curves.easeOutBack,
                    )),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const NoorBrand(light: true),
                        const SizedBox(height: 34),
                        const Text(
                          'كل يوم… اكتشاف جديد!',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 27,
                            fontWeight: FontWeight.w900,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 36),
                          child: Text(
                            'عالَم من المعرفة واللعب والإبداع، يتشكل على مقاس رحلتك',
                            style: TextStyle(
                              color: Colors.white,
                              height: 1.7,
                              fontSize: 16,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        const SizedBox(height: 26),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset('assets/branding/mascot-owl.png',
                                width: 76, height: 76),
                            Image.asset('assets/branding/mascot-fox.png',
                                width: 126, height: 126),
                            Image.asset('assets/branding/mascot-unicorn.png',
                                width: 76, height: 76),
                          ],
                        ),
                        const SizedBox(height: 26),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 34),
                          child: SizedBox(
                            width: double.infinity,
                            height: 58,
                            child: FilledButton.icon(
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFFFFD36C),
                                foregroundColor: const Color(0xFF18334A),
                                shape: const StadiumBorder(),
                              ),
                              onPressed: () => context.go('/'),
                              icon: const Icon(Icons.rocket_launch_rounded),
                              label: const Text(
                                'ابدأ رحلتك',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.w900),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 20,
                left: 0,
                right: 0,
                child: Center(
                  child: Text(
                    'تعلم • العب • اكتشف',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: .8),
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FloatEmoji extends StatelessWidget {
  const _FloatEmoji({
    required this.controller,
    required this.emoji,
    required this.size,
  });
  final AnimationController controller;
  final String emoji;
  final double size;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: controller,
        builder: (_, __) => Transform.translate(
          offset: Offset(0, mathSin(controller.value * 6.283) * 9),
          child: Text(
            emoji,
            style: TextStyle(
              fontSize: size,
              color: Colors.white.withValues(alpha: .8),
            ),
          ),
        ),
      );
}

double mathSin(double value) =>
    (value < 3.14159 ? value / 3.14159 : (6.28318 - value) / 3.14159) * 2 - 1;
