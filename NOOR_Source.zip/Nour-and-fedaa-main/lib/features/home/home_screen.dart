import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';
import '../../data/content/catalog.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  static const _colors = [
    AppColors.teal,
    AppColors.coral,
    Color(0xFF8B7CE8),
    AppColors.sky,
    Color(0xFFE8AE43),
    Color(0xFF68B78B)
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    final states = ref.watch(sectionStatesProvider);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            tooltip: 'تبديل المستخدم',
            icon: const Icon(Icons.swap_horiz_rounded),
            onPressed: () => context.go('/')),
        title: const NoorBrand(compact: true),
        actions: [
          IconButton(
              tooltip: 'المكتبة',
              onPressed: () => context.push('/library'),
              icon: const Icon(Icons.auto_stories_rounded)),
          IconButton(
              tooltip: 'ملفي',
              onPressed: () => context.push('/profile'),
              icon: const Icon(Icons.face_rounded)),
          const SizedBox(width: 5),
        ],
      ),
      body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFF2FAF8),
                    Color(0xFFF7F7FF),
                    Color(0xFFFFFAF2)
                  ]),
              image: DecorationImage(
                  image: AssetImage('assets/branding/noor-bg-forest.webp'),
                  fit: BoxFit.cover,
                  colorFilter:
                      ColorFilter.mode(Color(0xEAF7FBF9), BlendMode.srcOver))),
          child: child.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) =>
                const Center(child: Text('حدث خطأ، حاول مرة أخرى')),
            data: (c) {
              if (c == null)
                return Center(
                    child: FilledButton(
                        onPressed: () => context.go('/'),
                        child: const Text('اختيار المتعلم')));
              final enabled = states.valueOrNull ?? const <String, bool>{};
              final visible = sectionsForChild(c)
                  .where((s) => enabled[s.id] ?? true)
                  .toList();
              final totalLessons = visible.fold<int>(
                  0, (sum, section) => sum + lessonsForAge(section, c).length);
              final progress = totalLessons == 0
                  ? 0.0
                  : (c.stars / (totalLessons * 3)).clamp(0.0, 1.0);
              return SafeArea(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                  children: [
                    NoorEntrance(
                        delay: 0,
                        child: _HeroCard(
                            name: c.name,
                            ageLabel: c.ageLabel,
                            avatar: c.avatar,
                            points: c.points,
                            level: c.level,
                            stars: c.stars,
                            progress: progress)),
                    if (c.interests.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: c.interests
                                  .take(4)
                                  .map((v) => Chip(
                                      visualDensity: VisualDensity.compact,
                                      backgroundColor: Colors.white,
                                      avatar: const Icon(Icons.favorite_rounded,
                                          size: 14, color: AppColors.coral),
                                      label: Text(v,
                                          style: const TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700))))
                                  .toList()))
                    ],
                    const SizedBox(height: 20),
                    NoorEntrance(
                        delay: 1,
                        child: Row(children: [
                          Expanded(
                              child: Text('خريطة مغامرتك',
                                  style:
                                      Theme.of(context).textTheme.titleLarge)),
                          Text('${visible.length} عوالم',
                              style: const TextStyle(
                                  color: AppColors.teal,
                                  fontWeight: FontWeight.w800)),
                        ])),
                    const SizedBox(height: 12),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: visible.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisSpacing: 13,
                              crossAxisSpacing: 13,
                              childAspectRatio: 1.04),
                      itemBuilder: (ctx, i) {
                        final section = visible[i];
                        final color = _colors[i % _colors.length];
                        final count = lessonsForAge(section, c).length;
                        return NoorEntrance(
                          delay: i + 2,
                          child: _WorldCard(
                              section: section,
                              color: color,
                              count: count,
                              onTap: () =>
                                  context.push('/section/${section.id}')),
                        );
                      },
                    ),
                    const SizedBox(height: 19),
                    NoorEntrance(
                        delay: visible.length + 3,
                        child: _MissionCard(
                            onTap: () => context.push('/section/challenges'))),
                    const SizedBox(height: 12),
                    NoorEntrance(
                        delay: visible.length + 4,
                        child: Row(children: [
                          Expanded(
                              child: _QuickAction(
                                  icon: Icons.emoji_events_rounded,
                                  title: 'إنجازاتي',
                                  subtitle: 'شاراتك ومستواك',
                                  color: const Color(0xFFFFF0CB),
                                  onTap: () =>
                                      context.push('/section/achievements'))),
                          const SizedBox(width: 10),
                          Expanded(
                              child: _QuickAction(
                                  icon: Icons.card_giftcard_rounded,
                                  title: 'متجر النجوم',
                                  subtitle: 'افتح شخصيات',
                                  color: const Color(0xFFECEBFF),
                                  onTap: () => context.push('/rewards'))),
                        ])),
                    const SizedBox(height: 18),
                    Text('مناطق جديدة للاستكشاف',
                        style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 10),
                    GridView.count(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisCount: 2,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 1.35,
                        children: [
                          _QuickAction(
                              icon: Icons.sports_esports_rounded,
                              title: 'ملعب الألعاب',
                              subtitle: 'تحديات حسب عمرك',
                              color: const Color(0xFFE4F5F1),
                              onTap: () => context.push('/games')),
                          _QuickAction(
                              icon: Icons.auto_stories_rounded,
                              title: 'قصص تفاعلية',
                              subtitle: 'اختر مسارك',
                              color: const Color(0xFFFFE9E2),
                              onTap: () => context.push('/stories')),
                          _QuickAction(
                              icon: Icons.palette_rounded,
                              title: 'استوديو الإبداع',
                              subtitle: 'ارسم وابتكر',
                              color: const Color(0xFFECEBFF),
                              onTap: () => context.push('/studio')),
                          _QuickAction(
                              icon: Icons.science_rounded,
                              title: 'مختبر الاكتشاف',
                              subtitle: 'جرّب وتعلّم',
                              color: const Color(0xFFFFF0CB),
                              onTap: () => context.push('/lab')),
                          _QuickAction(
                              icon: Icons.lightbulb_rounded,
                              title: 'مرشد نور',
                              subtitle: 'تلميحات ذكية',
                              color: const Color(0xFFE4F0FF),
                              onTap: () => context.push('/guide')),
                          _QuickAction(
                              icon: Icons.family_restroom_rounded,
                              title: 'منطقة الأسرة',
                              subtitle: 'متابعة وتوجيه',
                              color: const Color(0xFFFCE8F2),
                              onTap: () => context.push('/parent')),
                        ]),
                  ],
                ),
              );
            },
          )),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard(
      {required this.name,
      required this.ageLabel,
      required this.avatar,
      required this.points,
      required this.level,
      required this.stars,
      required this.progress});
  final String name, ageLabel, avatar;
  final int points, level, stars;
  final double progress;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color(0xFF145B70),
                Color(0xFF0D9B91),
                Color(0xFF54B9A4)
              ]),
          boxShadow: [
            BoxShadow(
                color: AppColors.teal.withValues(alpha: .22),
                blurRadius: 22,
                offset: const Offset(0, 10))
          ],
        ),
        child: Stack(children: [
          Positioned(
              left: -12,
              top: -20,
              child: Icon(Icons.auto_awesome,
                  size: 94, color: Colors.white.withValues(alpha: .08))),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(
                  radius: 29,
                  backgroundColor: Colors.white.withValues(alpha: .2),
                  child: Text(avatar, style: const TextStyle(fontSize: 31))),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text('أهلًا يا $name! 👋',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 21,
                            fontWeight: FontWeight.w900)),
                    Text('$ageLabel • مستكشف نور',
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: .82),
                            fontWeight: FontWeight.w600)),
                  ])),
              const Icon(Icons.waving_hand_rounded,
                  color: AppColors.gold, size: 28),
            ]),
            const SizedBox(height: 20),
            Row(children: [
              _StatPill(icon: Icons.star_rounded, value: '$stars نجمة'),
              const SizedBox(width: 8),
              _StatPill(icon: Icons.bolt_rounded, value: '$points نقطة'),
              const SizedBox(width: 8),
              _StatPill(
                  icon: Icons.military_tech_rounded, value: 'مستوى $level'),
            ]),
            const SizedBox(height: 16),
            Row(children: [
              const Expanded(
                  child: Text('تقدمك في الرحلة',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w700))),
              Text('${(progress * 100).round()}%',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w900))
            ]),
            const SizedBox(height: 8),
            ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 10,
                    backgroundColor: Colors.white.withValues(alpha: .22),
                    color: AppColors.gold)),
          ]),
        ]),
      );
}

class _StatPill extends StatelessWidget {
  const _StatPill({required this.icon, required this.value});
  final IconData icon;
  final String value;
  @override
  Widget build(BuildContext context) => Expanded(
      child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 7),
          decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(14)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: AppColors.gold, size: 16),
            const SizedBox(width: 4),
            Flexible(
                child: Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w800)))
          ])));
}

String _worldArt(String id) {
  if (['space', 'science', 'coding', 'future', 'engineering'].contains(id))
    return 'assets/branding/noor-bg-space.webp';
  if (['animals', 'nature', 'life-skills', 'cooking', 'sports'].contains(id))
    return 'assets/branding/noor-bg-forest.webp';
  if (['creative', 'wellbeing', 'emotions', 'music', 'world'].contains(id))
    return 'assets/branding/noor-bg-ocean.webp';
  return 'assets/branding/noor-bg-space.webp';
}

class _WorldCard extends StatelessWidget {
  const _WorldCard(
      {required this.section,
      required this.color,
      required this.count,
      required this.onTap});
  final NoorSection section;
  final Color color;
  final int count;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        child: InkWell(
          borderRadius: BorderRadius.circular(25),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: color.withValues(alpha: .16)),
                boxShadow: [
                  BoxShadow(
                      color: color.withValues(alpha: .07),
                      blurRadius: 15,
                      offset: const Offset(0, 6))
                ]),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                    width: 58,
                    height: 54,
                    decoration: BoxDecoration(
                        color: color.withValues(alpha: .13),
                        borderRadius: BorderRadius.circular(17)),
                    clipBehavior: Clip.antiAlias,
                    child: Stack(fit: StackFit.expand, children: [
                      Image.asset(_worldArt(section.id),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Center(
                              child: Text(section.emoji,
                                  style: const TextStyle(fontSize: 27)))),
                      Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                              padding: const EdgeInsets.all(3),
                              decoration: const BoxDecoration(
                                  color: Colors.white70,
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(10))),
                              child: Text(section.emoji,
                                  style: const TextStyle(fontSize: 14))))
                    ])),
                const Spacer(),
                Icon(Icons.arrow_outward_rounded, color: color, size: 19),
              ]),
              const Spacer(),
              Text(section.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      color: AppColors.ink)),
              const SizedBox(height: 4),
              Text('$count مغامرات تعليمية',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 11,
                      color: AppColors.ink.withValues(alpha: .62),
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                height: 5,
                decoration: BoxDecoration(
                    color: color.withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(9)),
                alignment: Alignment.centerRight,
                child: FractionallySizedBox(
                    widthFactor: count == 0 ? 0 : .72,
                    child: DecoratedBox(
                        decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(9)))),
              ),
            ]),
          ),
        ),
      );
}

class _MissionCard extends StatelessWidget {
  const _MissionCard({required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
        color: const Color(0xFFFFF1D5),
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: onTap,
            child: Padding(
                padding: const EdgeInsets.all(17),
                child: Row(children: [
                  Container(
                      width: 51,
                      height: 51,
                      decoration: BoxDecoration(
                          color: AppColors.gold.withValues(alpha: .35),
                          borderRadius: BorderRadius.circular(17)),
                      child: const Icon(Icons.flag_rounded,
                          color: Color(0xFFAD7620), size: 29)),
                  const SizedBox(width: 13),
                  const Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        Text('مهمة اليوم',
                            style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 17,
                                color: AppColors.ink)),
                        SizedBox(height: 3),
                        Text('حلّ تحديًا جديدًا واجمع نجومًا إضافية',
                            style:
                                TextStyle(fontSize: 12, color: AppColors.ink))
                      ])),
                  const Icon(Icons.chevron_left_rounded, color: AppColors.ink),
                ]))),
      );
}

class _QuickAction extends StatelessWidget {
  const _QuickAction(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.color,
      required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: color.withValues(alpha: .38)),
                  boxShadow: [
                    BoxShadow(
                        color: color.withValues(alpha: .12),
                        blurRadius: 14,
                        offset: const Offset(0, 5))
                  ]),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(14)),
                        child: Icon(icon, color: AppColors.ink)),
                    const SizedBox(height: 8),
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, color: AppColors.ink)),
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 11,
                            color: AppColors.ink.withValues(alpha: .62)))
                  ]))));
}
