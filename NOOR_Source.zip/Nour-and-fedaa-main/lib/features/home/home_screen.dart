import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/providers.dart';
import '../../data/content/catalog.dart';

class HomeScreen extends ConsumerWidget {
 const HomeScreen({super.key});
 @override Widget build(BuildContext context,WidgetRef ref){
  final child=ref.watch(selectedChildProvider);final states=ref.watch(sectionStatesProvider);
  return Scaffold(appBar:AppBar(leading:IconButton(tooltip:'تبديل المستخدم',icon:const Icon(Icons.swap_horiz),onPressed:()=>context.go('/')),
   title:const Text('نور | NOOR'),actions:[IconButton(tooltip:'المكتبة',onPressed:()=>context.push('/library'),icon:const Icon(Icons.bookmark_outline)),IconButton(tooltip:'ملفي',onPressed:()=>context.push('/profile'),icon:const Icon(Icons.person_outline))]),
   body:child.when(loading:()=>const Center(child:CircularProgressIndicator()),error:(_,__)=>const Center(child:Text('حدث خطأ')),data:(c){
    if(c==null)return Center(child:FilledButton(onPressed:()=>context.go('/'),child:const Text('اختيار المستخدم')));
    final enabled=states.valueOrNull??const <String,bool>{};
    final visible=noorSections.where((s)=>enabled[s.id]??true).toList();
    final tint=c.age<=5?const Color(0xFFEAF5F1):c.age<=13?const Color(0xFFECEBFA):const Color(0xFFE9EEF4);
    return SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[
     Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:tint,borderRadius:BorderRadius.circular(26)),child:Row(children:[
      CircleAvatar(radius:32,child:Text(c.avatar,style:const TextStyle(fontSize:30))),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
       Text('أهلًا ${c.name} 👋',style:Theme.of(context).textTheme.titleLarge),Text('رحلتك اليوم • ${c.ageLabel}',style:Theme.of(context).textTheme.bodyMedium),const SizedBox(height:8),Text('⭐ ${c.stars}    •    ${c.points} نقطة    •    المستوى ${c.level}',style:const TextStyle(fontWeight:FontWeight.w700))
      ]))
     ])),
     const SizedBox(height:20),Text('ماذا تحب أن تتعلم اليوم؟',style:Theme.of(context).textTheme.titleLarge),
     const SizedBox(height:12),GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:visible.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.12),itemBuilder:(ctx,i){
      final s=visible[i];return Card(child:InkWell(borderRadius:BorderRadius.circular(22),onTap:()=>context.push('/section/${s.id}'),child:Padding(padding:const EdgeInsets.all(14),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
       Text(s.emoji,style:const TextStyle(fontSize:38)),const SizedBox(height:8),Text(s.title,textAlign:TextAlign.center,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),Text('${s.lessons.length} أنشطة',style:Theme.of(context).textTheme.bodySmall)
      ]))));
     }),
     const SizedBox(height:16),Card(child:ListTile(leading:const Icon(Icons.emoji_events_outlined),title:const Text('إنجازاتي'),subtitle:const Text('النقاط والمستويات والتقدم'),trailing:const Icon(Icons.chevron_left),onTap:()=>context.push('/section/achievements'))),
     Card(child:ListTile(leading:const Icon(Icons.card_giftcard),title:const Text('متجر المكافآت'),subtitle:const Text('افتح شخصيات جديدة بالنقاط'),trailing:const Icon(Icons.chevron_left),onTap:()=>context.push('/rewards'))),
     Card(child:ListTile(leading:const Icon(Icons.search),title:const Text('ابحث في مكتبة نور'),trailing:const Icon(Icons.chevron_left),onTap:()=>context.push('/library')))
    ]));
   }));
 }
}
