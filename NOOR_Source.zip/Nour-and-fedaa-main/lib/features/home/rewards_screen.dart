import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/providers.dart';

class RewardsScreen extends ConsumerWidget{
 const RewardsScreen({super.key});
 static const rewards=[('🌙','هلال','رمز مميز للملف',40),('🦁','أسد','شخصية شجاعة',80),('🐼','باندا','شخصية لطيفة',100),('🦊','ثعلب','شخصية ذكية',120)];
 @override Widget build(BuildContext context,WidgetRef ref){
  final child=ref.watch(selectedChildProvider);
  return Scaffold(appBar:AppBar(title:const Text('متجر نور للمكافآت')),body:child.when(loading:()=>const Center(child:CircularProgressIndicator()),error:(_,__)=>const SizedBox(),data:(c){
   if(c==null)return const SizedBox();
   return ListView(padding:const EdgeInsets.all(18),children:[
    Card(child:ListTile(leading:const Icon(Icons.stars),title:Text('${c.points} نقطة متاحة'),subtitle:const Text('اجمع النقاط من الدروس والاختبارات'))),
    for(final item in rewards)Card(child:ListTile(leading:Text(item.$1,style:const TextStyle(fontSize:32)),title:Text(item.$2),subtitle:Text('${item.$3} • ${item.$4} نقطة'),trailing:FilledButton(onPressed:c.points<item.$4?null:()async{
     final ok=await ref.read(childRepositoryProvider).purchaseAvatar(c.id,item.$1,item.$4);
     if(ok){ref.invalidate(selectedChildProvider);ref.invalidate(childrenProvider);if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم فتح الشخصية الجديدة!')));}
    },child:const Text('فتح'))))
   ]);
  }));
 }
}
