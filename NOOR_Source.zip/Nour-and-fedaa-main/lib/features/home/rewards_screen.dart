import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../data/providers.dart';

class RewardsScreen extends ConsumerWidget {
  const RewardsScreen({super.key});
  static const rewards = [
    ('🌙', 'حارس الهلال', 'رفيق هادئ لرحلتك', 40),
    ('🦁', 'الأسد الشجاع', 'قلب قوي وروح لطيفة', 80),
    ('🐼', 'الباندا المرح', 'يحب الاكتشاف', 100),
    ('🦊', 'الثعلب الذكي', 'خبير الألغاز', 120),
    ('🐯', 'النمر السريع', 'مستعد للتحديات', 150),
    ('🐧', 'البطريق المغامر', 'يحب العوالم الجديدة', 180),
    ('🦄', 'وحيد القرن اللامع', 'شخصية نادرة', 220),
    ('🚀', 'مستكشف الفضاء', 'رفيق النجوم والكواكب', 260),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    return Scaffold(
        appBar: AppBar(title: const Text('متجر نجوم نور')),
        body: child.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const SizedBox(),
          data: (c) {
            if (c == null) return const SizedBox();
            return ListView(padding: const EdgeInsets.all(18), children: [
              Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(27),
                      gradient: const LinearGradient(
                          colors: [Color(0xFF165B70), Color(0xFF0D9B91)])),
                  child: Row(children: [
                    const Icon(Icons.stars_rounded,
                        color: AppColors.gold, size: 42),
                    const SizedBox(width: 13),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          const Text('رصيدك من النجوم',
                              style: TextStyle(
                                  color: Colors.white70,
                                  fontWeight: FontWeight.w700)),
                          Text('${c.points} نقطة',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 25,
                                  fontWeight: FontWeight.w900))
                        ]))
                  ])),
              const SizedBox(height: 18),
              const Text('اختر رفيقًا جديدًا',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              for (final item in rewards)
                Card(
                    child: Padding(
                        padding: const EdgeInsets.all(13),
                        child: Row(children: [
                          Container(
                              width: 58,
                              height: 58,
                              decoration: BoxDecoration(
                                  color: AppColors.lavender,
                                  borderRadius: BorderRadius.circular(18)),
                              alignment: Alignment.center,
                              child: Text(item.$1,
                                  style: const TextStyle(fontSize: 34))),
                          const SizedBox(width: 12),
                          Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                Text(item.$2,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 16)),
                                Text(item.$3,
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.blueGrey)),
                                Text('⭐ ${item.$4} نقطة',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w800,
                                        color: AppColors.teal))
                              ])),
                          FilledButton(
                              onPressed: c.points < item.$4
                                  ? null
                                  : () async {
                                      final ok = await ref
                                          .read(childRepositoryProvider)
                                          .purchaseAvatar(
                                              c.id, item.$1, item.$4);
                                      if (ok) {
                                        ref.invalidate(selectedChildProvider);
                                        ref.invalidate(childrenProvider);
                                        if (context.mounted)
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(SnackBar(
                                                  content: Text(
                                                      'مبروك! أصبح ${item.$2} رفيقك الجديد 🎉')));
                                      }
                                    },
                              child: const Text('فتح'))
                        ]))),
            ]);
          },
        ));
  }
}
