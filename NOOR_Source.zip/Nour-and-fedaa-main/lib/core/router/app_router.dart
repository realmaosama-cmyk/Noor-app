import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/home/home_screen.dart';
import '../../features/home/section_screen.dart';
import '../../features/home/who_learns_screen.dart';
import '../../features/parent/parent_dashboard_screen.dart';
import '../../features/parent/parent_gate_screen.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/home/library_screen.dart';
import '../../features/home/rewards_screen.dart';
final routerProvider=Provider<GoRouter>((ref)=>GoRouter(initialLocation:'/',routes:[
 GoRoute(path:'/',builder:(_,__)=>const WhoLearnsScreen()),
 GoRoute(path:'/home',builder:(_,__)=>const HomeScreen()),
 GoRoute(path:'/section/:id',builder:(_,s)=>SectionScreen(sectionId:s.pathParameters['id']!)),
 GoRoute(path:'/profile',builder:(_,__)=>const ProfileScreen()),
 GoRoute(path:'/library',builder:(_,__)=>const LibraryScreen()),
 GoRoute(path:'/rewards',builder:(_,__)=>const RewardsScreen()),
 GoRoute(path:'/parent',builder:(_,__)=>const ParentGateScreen()),
 GoRoute(path:'/parent/dashboard',builder:(_,__)=>const ParentDashboardScreen()),
]));
