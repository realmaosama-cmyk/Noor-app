import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';

class NoorBrand extends StatelessWidget {
  const NoorBrand({super.key, this.compact = false, this.light = false});
  final bool compact;
  final bool light;
  @override
  Widget build(BuildContext context) {
    final foreground = light ? Colors.white : const Color(0xFF18334A);
    return Row(mainAxisSize: MainAxisSize.min, children: [
      _NoorMark(size: compact ? 44 : 66, light: light),
      const SizedBox(width: 11),
      Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('نــور',
                style: TextStyle(
                    color: foreground,
                    fontSize: compact ? 22 : 30,
                    fontWeight: FontWeight.w900,
                    height: 1.05)),
            if (!compact)
              Text('NOOR • LEARN & PLAY',
                  style: TextStyle(
                      color: foreground.withValues(alpha: .72),
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2)),
          ]),
    ]);
  }
}

class _NoorMark extends StatefulWidget {
  const _NoorMark({required this.size, required this.light});
  final double size;
  final bool light;
  @override
  State<_NoorMark> createState() => _NoorMarkState();
}

class _NoorMarkState extends State<_NoorMark>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2400))
    ..repeat(reverse: true);
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        final pulse = .94 + _controller.value * .08;
        return Transform.scale(
            scale: pulse,
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                      colors: widget.light
                          ? const [Color(0xFFFFD978), Color(0xFFF5A94B)]
                          : const [Color(0xFF0C9E91), Color(0xFF176D83)]),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xFF0D9B91).withValues(alpha: .24),
                        blurRadius: 20,
                        offset: const Offset(0, 7))
                  ]),
              child: ClipOval(
                  child: Image.asset('assets/branding/noor-symbol.png',
                      width: widget.size,
                      height: widget.size,
                      fit: BoxFit.cover)),
            ));
      });
}

class NoorEntrance extends StatelessWidget {
  const NoorEntrance({super.key, required this.delay, required this.child});
  final int delay;
  final Widget child;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 420 + delay.clamp(0, 8).toInt() * 65),
      curve: Curves.easeOutBack,
      builder: (context, value, _) => Opacity(
          opacity: value.clamp(0.0, 1.0).toDouble(),
          child: Transform.translate(
              offset: Offset(0, 20 * (1 - value)), child: child)));
}

class NoorPageBackground extends StatefulWidget {
  const NoorPageBackground(
      {super.key, required this.child, required this.asset, this.motif = '✦'});
  final Widget child;
  final String asset;
  final String motif;
  @override
  State<NoorPageBackground> createState() => _NoorPageBackgroundState();
}

class _NoorPageBackgroundState extends State<NoorPageBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ambient =
      AnimationController(vsync: this, duration: const Duration(seconds: 12))
        ..repeat();
  @override
  void dispose() {
    _ambient.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Stack(fit: StackFit.expand, children: [
      Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: dark
                      ? const [
                          Color(0xFF101D29),
                          Color(0xFF182B3B),
                          Color(0xFF1E263C)
                        ]
                      : const [
                          Color(0xFFF2FAF8),
                          Color(0xFFF7F5FF),
                          Color(0xFFFFFAF2)
                        ]),
              image: DecorationImage(
                  image: AssetImage(widget.asset),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                      dark ? const Color(0xD9101D29) : const Color(0xE8FFFFFF),
                      BlendMode.srcOver)))),
      AnimatedBuilder(
          animation: _ambient,
          builder: (_, __) {
            final t = _ambient.value * 2 * math.pi;
            return IgnorePointer(
                child: Stack(children: [
              Positioned(
                  top: 24 + 12 * math.sin(t),
                  right: 22,
                  child: Opacity(
                      opacity: dark ? .22 : .15,
                      child: Text(widget.motif,
                          style: const TextStyle(fontSize: 34)))),
              Positioned(
                  top: 160 + 18 * math.sin(t + 1.4),
                  left: 18,
                  child: Opacity(
                      opacity: dark ? .20 : .12,
                      child: const Text('✦',
                          style: TextStyle(
                              fontSize: 23, color: Color(0xFFFFC85A))))),
              Positioned(
                  bottom: 110 + 14 * math.sin(t + 2.5),
                  right: 34,
                  child: Opacity(
                      opacity: dark ? .18 : .10,
                      child: const Text('✧',
                          style: TextStyle(
                              fontSize: 38, color: Color(0xFF0D9B91))))),
            ]));
          }),
      widget.child,
    ]);
  }
}
