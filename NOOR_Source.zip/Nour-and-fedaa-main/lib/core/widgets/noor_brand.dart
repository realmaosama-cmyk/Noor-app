import 'package:material_ui/material_ui.dart';

/// A lightweight, fully offline brand mark for NOOR.
class NoorBrand extends StatelessWidget {
  const NoorBrand({super.key, this.compact = false, this.light = false});
  final bool compact;
  final bool light;

  @override
  Widget build(BuildContext context) {
    final foreground = light ? Colors.white : const Color(0xFF18334A);
    final secondary = light ? const Color(0xFFFFE39A) : const Color(0xFF0D9B91);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: compact ? 44 : 62,
          height: compact ? 44 : 62,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: light
                  ? [const Color(0xFFFFD978), const Color(0xFFF5A94B)]
                  : [const Color(0xFF0C9E91), const Color(0xFF176D83)],
            ),
            boxShadow: [
              BoxShadow(
                color: secondary.withValues(alpha: .24),
                blurRadius: 18,
                offset: const Offset(0, 7),
              ),
            ],
          ),
          child: Icon(Icons.auto_awesome,
              color: Colors.white, size: compact ? 25 : 35),
        ),
        const SizedBox(width: 11),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('نــور',
                style: TextStyle(
                    color: foreground,
                    fontSize: compact ? 22 : 29,
                    fontWeight: FontWeight.w900,
                    height: 1.05)),
            if (!compact)
              Text('NOOR • LEARN & PLAY',
                  style: TextStyle(
                      color: foreground.withValues(alpha: .72),
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.15)),
          ],
        ),
      ],
    );
  }
}

class NoorEntrance extends StatelessWidget {
  const NoorEntrance({super.key, required this.delay, required this.child});
  final int delay;
  final Widget child;

  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 430 + delay * 55),
        curve: Curves.easeOutBack,
        builder: (context, value, _) => Opacity(
          opacity: value.clamp(0.0, 1.0).toDouble(),
          child: Transform.translate(
              offset: Offset(0, 18 * (1 - value)), child: child),
        ),
      );
}
