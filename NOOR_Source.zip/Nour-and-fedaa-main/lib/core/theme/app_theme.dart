import 'package:material_ui/material_ui.dart';
class AppColors {
 static const ink=Color(0xFF182B3A), navy=Color(0xFF102A43), teal=Color(0xFF168C83),
 gold=Color(0xFFD6A84F), mist=Color(0xFFF3F6F5), lavender=Color(0xFFECEBFA);
}
class AppTheme {
 static ThemeData light(){
  final scheme=ColorScheme.fromSeed(seedColor:AppColors.teal,brightness:Brightness.light);
  return ThemeData(useMaterial3:true,colorScheme:scheme,scaffoldBackgroundColor:AppColors.mist,
   cardTheme:CardThemeData(color:Colors.white,elevation:1,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22))),
   appBarTheme:const AppBarTheme(backgroundColor:Colors.transparent,elevation:0,centerTitle:true,foregroundColor:AppColors.ink),
   textTheme:const TextTheme(headlineMedium:TextStyle(fontSize:30,fontWeight:FontWeight.w800,color:AppColors.ink),
    titleLarge:TextStyle(fontSize:22,fontWeight:FontWeight.w700,color:AppColors.ink),
    bodyLarge:TextStyle(fontSize:17,color:AppColors.ink)),
   inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)),
   elevatedButtonTheme:ElevatedButtonThemeData(style:ElevatedButton.styleFrom(minimumSize:const Size(120,54),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),textStyle:const TextStyle(fontSize:17,fontWeight:FontWeight.w700))));
 }
 static ThemeData dark(){
  final scheme=ColorScheme.fromSeed(seedColor:AppColors.teal,brightness:Brightness.dark);
  return ThemeData(useMaterial3:true,colorScheme:scheme,scaffoldBackgroundColor:const Color(0xFF101B24),
   appBarTheme:const AppBarTheme(backgroundColor:Colors.transparent,centerTitle:true),
   cardTheme:CardThemeData(color:const Color(0xFF1C2B36),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22))),
   inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:const Color(0xFF263744),border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)));
 }
}
