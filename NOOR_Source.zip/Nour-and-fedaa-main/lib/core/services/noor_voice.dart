import 'package:flutter_tts/flutter_tts.dart';

/// Lightweight on-device speech helper. Arabic voice availability depends on
/// the speech engine and language packs installed on the Android device.
class NoorVoice {
  NoorVoice._();

  static final FlutterTts _engine = FlutterTts();
  static bool _configured = false;

  static Future<void> speak(String text) async {
    if (!_configured) {
      await _engine.setLanguage('ar');
      await _engine.setSpeechRate(0.44);
      await _engine.setPitch(1.02);
      await _engine.awaitSpeakCompletion(true);
      _configured = true;
    }
    await _engine.stop();
    await _engine.speak(text);
  }

  static Future<void> stop() => _engine.stop();
}
