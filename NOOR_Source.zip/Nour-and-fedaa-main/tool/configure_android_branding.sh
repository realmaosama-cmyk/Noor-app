#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RES="$ROOT/android/app/src/main/res"
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$density"
  cp "$ROOT/assets/android_launcher/ic_launcher_${density}.png" "$RES/mipmap-$density/ic_launcher.png"
done
mkdir -p "$RES/mipmap-anydpi-v26" "$RES/drawable"
cat > "$RES/mipmap-anydpi-v26/ic_launcher.xml" <<'XML'
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/noor_launcher_background" />
    <foreground android:drawable="@drawable/noor_launcher_foreground" />
</adaptive-icon>
XML
cat > "$RES/drawable/noor_launcher_foreground.xml" <<'XML'
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#FFFFFFFF" android:pathData="M54,39 C43,30 29,29 17,34 L17,75 C30,70 43,71 54,81 C65,71 78,70 91,75 L91,34 C79,29 65,30 54,39 Z" />
    <path android:fillColor="#FFB9F2E9" android:pathData="M52,41 L52,78 C42,71 31,70 21,73 L21,38 C32,34 43,35 52,41 Z" />
    <path android:fillColor="#FFFFD978" android:pathData="M54,39 L54,81 L57,81 L57,39 Z" />
    <path android:fillColor="#FFFFD978" android:pathData="M79,13 L83,25 L96,29 L83,34 L79,47 L74,34 L62,29 L74,25 Z" />
    <path android:fillColor="#FFFFFFFF" android:pathData="M28,17 C19,25 20,39 31,45 C25,35 28,24 39,18 C35,16 31,16 28,17 Z" />
</vector>
XML
cat > "$RES/values-noor.xml.tmp" <<'XML'
<resources><color name="noor_launcher_background">#0D9B91</color></resources>
XML
mkdir -p "$RES/values"
mv "$RES/values-noor.xml.tmp" "$RES/values/noor_launcher.xml"
MANIFEST="$ROOT/android/app/src/main/AndroidManifest.xml"
if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
  sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET" />\n<application#' "$MANIFEST"
fi
if grep -q 'android:icon=' "$MANIFEST"; then
  sed -i 's#android:icon="[^"]*"#android:icon="@mipmap/ic_launcher"#' "$MANIFEST"
else
  sed -i 's#<application#<application android:icon="@mipmap/ic_launcher"#' "$MANIFEST"
fi
sed -i 's/android:label="[^"]*"/android:label="نور | NOOR"/' "$MANIFEST"
