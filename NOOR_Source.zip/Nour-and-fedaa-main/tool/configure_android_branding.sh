#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RES="$ROOT/android/app/src/main/res"
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$density"
  cp "$ROOT/assets/android_launcher/ic_launcher_${density}.png" "$RES/mipmap-$density/ic_launcher.png"
done
mkdir -p "$RES/mipmap-anydpi-v26" "$RES/drawable"
cat > "$RES/mipmap-anydpi-v26/ic_launcher.xml" <<'XML'
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/noor_launcher_background" />
    <foreground android:drawable="@drawable/noor_launcher_foreground" />
</adaptive-icon>
XML
cat > "$RES/drawable/noor_launcher_foreground.xml" <<'XML'
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#FFFFFFFF" android:pathData="M54,20 L62,43 L85,54 L62,62 L54,86 L45,62 L23,54 L45,43 Z" />
    <path android:fillColor="#FFFFE091" android:pathData="M79,19 L83,29 L94,33 L83,37 L79,48 L75,37 L64,33 L75,29 Z" />
    <path android:fillColor="#FFFFFFFF" android:pathData="M25,69 L28,77 L37,80 L28,84 L25,93 L21,84 L13,80 L21,77 Z" />
</vector>
XML
cat > "$RES/values-noor.xml.tmp" <<'XML'
<resources><color name="noor_launcher_background">#0D9B91</color></resources>
XML
mkdir -p "$RES/values"
mv "$RES/values-noor.xml.tmp" "$RES/values/noor_launcher.xml"
MANIFEST="$ROOT/android/app/src/main/AndroidManifest.xml"
if grep -q 'android:icon=' "$MANIFEST"; then
  sed -i 's#android:icon="[^"]*"#android:icon="@mipmap/ic_launcher"#' "$MANIFEST"
else
  sed -i 's#<application#<application android:icon="@mipmap/ic_launcher"#' "$MANIFEST"
fi
sed -i 's/android:label="[^"]*"/android:label="نور | NOOR"/' "$MANIFEST"
