import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/content/catalog.dart';
import 'package:noor/data/models/child.dart';

void main() {
  test('every lesson has a unique id, source, and valid quiz', () {
    final lessons = noorSections.expand((section) => section.lessons).toList();
    final ids = lessons.map((lesson) => lesson.id).toSet();
    expect(ids.length, lessons.length);
    expect(lessons.length, greaterThanOrEqualTo(47));
    expect(noorSections.length, greaterThanOrEqualTo(19));
    for (final lesson in lessons) {
      expect(lesson.source.trim(), isNotEmpty);
      expect(lesson.questions, isNotEmpty);
      for (final question in lesson.questions) {
        expect(question.options.length, greaterThanOrEqualTo(2));
        expect(
            question.answer, inInclusiveRange(0, question.options.length - 1));
        expect(question.prompt.trim(), isNotEmpty);
      }
    }
  });

  test('every section has a unique id and visible learning content', () {
    final ids = noorSections.map((section) => section.id).toSet();
    expect(ids.length, noorSections.length);
    for (final section in noorSections) {
      expect(section.title.trim(), isNotEmpty);
      expect(section.lessons, isNotEmpty);
    }
  });

  test('age stage classification supports children and adults', () {
    expect(const Child(id: 1, name: 'A', age: 4).ageGroup, AgeGroup.discovery);
    expect(const Child(id: 2, name: 'B', age: 8).ageGroup, AgeGroup.adventure);
    expect(const Child(id: 3, name: 'C', age: 12).ageGroup, AgeGroup.challenge);
    expect(
        const Child(id: 4, name: 'D', age: 16).ageGroup, AgeGroup.independence);
    expect(const Child(id: 5, name: 'E', age: 30).ageGroup, AgeGroup.adult);
    expect(const Child(id: 6, name: 'F', age: 5).ageGroup, AgeGroup.discovery);
    expect(const Child(id: 7, name: 'G', age: 6).ageGroup, AgeGroup.adventure);
    expect(
        const Child(id: 8, name: 'H', age: 14).ageGroup, AgeGroup.independence);
  });

  test('expanded worlds cover programming, geography, languages, and wellbeing',
      () {
    for (final id in ['coding', 'world', 'english', 'wellbeing']) {
      expect(sectionById(id), isNotNull);
      expect(sectionById(id)!.lessons.length, greaterThanOrEqualTo(3));
    }
  });

  test('preferences prioritize matching learning worlds without hiding others',
      () {
    final learner =
        const Child(id: 10, name: 'A', age: 11, interests: ['رياضيات']);
    final ordered = sectionsForChild(learner);
    expect(ordered.first.id, 'math');
    expect(ordered.length, greaterThan(1));
  });

  test('age filtering keeps lessons within their published age range', () {
    final section = sectionById('arabic');
    expect(section, isNotNull);
    final youngLearner = const Child(id: 9, name: 'A', age: 4);
    final visible = lessonsForAge(section!, youngLearner);
    expect(visible.every((lesson) => lesson.suitableFor(4)), isTrue);
    expect(visible.length, greaterThanOrEqualTo(1));
  });
}
