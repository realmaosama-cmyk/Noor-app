import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/content/catalog.dart';
import 'package:noor/data/models/child.dart';

void main() {
  test('every published lesson has a unique id and source', () {
    final lessons = noorSections.expand((section) => section.lessons).toList();
    final ids = lessons.map((lesson) => lesson.id).toSet();
    expect(ids.length, lessons.length);
    expect(lessons, isNotEmpty);
    for (final lesson in lessons) {
      expect(lesson.source.trim(), isNotEmpty);
      expect(lesson.questions, isNotEmpty);
      for (final question in lesson.questions) {
        expect(question.options.length, greaterThanOrEqualTo(2));
        expect(question.answer, inInclusiveRange(0, question.options.length - 1));
        expect(question.prompt.trim(), isNotEmpty);
      }
    }
  });

  test('age stage classification supports children and adults', () {
    expect(const Child(id: 1, name: 'A', age: 4).ageGroup, AgeGroup.discovery);
    expect(const Child(id: 2, name: 'B', age: 8).ageGroup, AgeGroup.adventure);
    expect(const Child(id: 3, name: 'C', age: 12).ageGroup, AgeGroup.challenge);
    expect(const Child(id: 4, name: 'D', age: 16).ageGroup, AgeGroup.independence);
    expect(const Child(id: 5, name: 'E', age: 30).ageGroup, AgeGroup.adult);
    expect(const Child(id: 6, name: 'F', age: 5).ageGroup, AgeGroup.discovery);
    expect(const Child(id: 7, name: 'G', age: 6).ageGroup, AgeGroup.adventure);
    expect(const Child(id: 8, name: 'H', age: 14).ageGroup, AgeGroup.independence);
  });
}
