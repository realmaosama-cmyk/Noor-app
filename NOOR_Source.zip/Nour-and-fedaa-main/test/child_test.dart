import 'package:flutter_test/flutter_test.dart';
import 'package:noor/data/models/child.dart';

void main() {
  test('age groups adapt across five life stages', () {
    expect(const Child(id:1,name:'أ',age:4).ageGroup, AgeGroup.discovery);
    expect(const Child(id:2,name:'ب',age:8).ageGroup, AgeGroup.adventure);
    expect(const Child(id:3,name:'ج',age:12).ageGroup, AgeGroup.challenge);
    expect(const Child(id:4,name:'د',age:16).ageGroup, AgeGroup.independence);
    expect(const Child(id:5,name:'هـ',age:30).ageGroup, AgeGroup.adult);
  });
  test('level rises every 100 points', () {
    expect(const Child(id:1,name:'نور',age:8,points:250).level,3);
  });
  test('gender and avatar have safe defaults for migrated records', () {
    const c=Child(id:1,name:'مستخدم',age:9);
    expect(c.gender,'unspecified');
    expect(c.avatar,'🌟');
  });
}
