# معمارية نور | NOOR

## التجربة التعليمية
- واجهة مغامرات عربية RTL مع هوية موحدة وحركة دخول وبطاقات وأزرار تفاعلية.
- العمر يخصص صياغة الشرح والتلميحات وفق المرحلة دون إخفاء الدروس أو العوالم.
- ملفات متعددة للمتعلمين مع مخزون رفاق مستقل لكل طفل، وشخصية وغرفة قابلة للتخصيص.
- ألعاب قصيرة، قصص اختيارية، استوديو رسم، محاكاة علمية، ومرشد تلميحات محلي.

## الوحدات
- `features/home`: الرئيسية، العوالم، الدروس، المكتبة، المكافآت، الألعاب الأساسية والمتاهة واكتشاف الاختلافات وترتيب القصص والإبداع والمختبر والمرشد.
- `features/profile`: إدارة ملف المتعلم ومظهره.
- `features/parent`: بوابة ولي الأمر، ملخص التقدم وتقارير الإتقان حسب القسم، التحكم في الأقسام والوقت الإرشادي.
- `data/content/catalog.dart`: الكتالوج والأسئلة والمراجع والفئات العمرية.
- `data/db`: SQLite والترقيات الإضافية حتى v9، بما فيها مخزون الرفاق دون استبدال بيانات الأطفال أو التقدم.
- `data/repositories`: الملفات الشخصية والتقدم والمكافآت والاستخدام.
- `core/theme` و`core/widgets`: الألوان والهوية والحركة.

## التشغيل والخصوصية
- البيانات وملفات المتعلمين محفوظة محليًا في SQLite.
- الألعاب والقصص والرسم والمحاكاة والمرشد الأساسي تعمل دون اتصال؛ المتاهة والاختلافات وترتيب القصص بثلاثة مستويات لكل لعبة.
- مرشد نور يعتمد على تلميحات معدة مسبقًا وليس خدمة ذكاء اصطناعي أو اتصالًا خارجيًا.
- لا توجد محادثات عامة أو مزامنة سحابية في هذا الإصدار.
- لا تعرض الدروس صورًا تجسد الأنبياء أو الصحابة.

## GitHub Actions
ملف Workflow الفعلي هو `.github/workflows/android.yml`. يدعم مستودعًا يحتوي `NOOR_Source.zip` أو مشروع Flutter مباشرة، ويستخدم Flutter stable ثم التنسيق والتحليل والاختبارات. في أحداث المستودع التي تملك صلاحية أسرار الإصدار، يحقن keystore الحالي من GitHub Secrets ويبني APK release موقّعًا فقط. تُحذف مواد التوقيع قبل تغليف المصدر ولا يُبنى AAB. لا يُشغّل APK الموقّع لطلبات السحب القادمة من forks التي لا تملك الأسرار.


## NOOR 1.2 — Hybrid experience update

- The content catalog contains 30 worlds and 90 core lessons. Age ranges remain descriptive metadata; every learner can open every world and lesson.
- Nine new worlds cover astronomy, animal science, emotional literacy, financial literacy, digital citizenship, rhythm, sports, cooking, and engineering.
- Learner onboarding has five steps: name/avatar, age, optional presentation, interests, and a short non-graded starter quiz.
- Interest preferences reorder relevant worlds but do not hide other worlds. Gender affects optional wording only; it does not restrict content.
- Visual assets are bundled locally: the NOOR symbol, launcher icon sizes, three mascot portraits, and space/forest/ocean backgrounds.
- The games hub offers matching, mathematics, logic, and word challenges with streak feedback.
- The Android release remains a signed APK only; the CI workflow formats, analyzes, tests, builds, verifies the signature, and uploads the APK artifact.


## خريطة المغامرة وإتاحة المحتوى
- المساران الشرعي والعلمي يظهران على هيئة مسار مغامرة متعرج مع ظهور متتابع للعقد.
- محتوى legacy المتاح لكل قسم يُحمّل داخل شاشة القسم نفسها، وتُزال العناوين المتطابقة مع دروس الفهرس الأساسي.
- بيانات العمر في المحتوى وصفية؛ لا تُستخدم كشرط وصول.
- انتقالات الصفحات ومؤثرات النقر تعمل محليًا، ويمكن إيقاف المؤثرات من إعدادات الملف الشخصي.
