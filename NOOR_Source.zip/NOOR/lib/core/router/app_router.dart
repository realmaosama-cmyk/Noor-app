import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/home/home_screen.dart';
import '../../features/home/welcome_screen.dart';
import '../../features/home/section_screen.dart';
import '../../features/home/who_learns_screen.dart';
import '../../features/parent/parent_dashboard_screen.dart';
import '../../features/parent/parent_gate_screen.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/home/library_screen.dart';
import '../../features/home/legacy_content_screen.dart';
import '../../features/home/rewards_screen.dart';
import '../../features/home/feature_hub_screen.dart';
import '../../features/home/prayer_tracker_screen.dart';
import '../../features/home/quran_recitation_screen.dart';
import '../../features/home/memory_game_screen.dart';
import '../../features/home/letter_builder_game_screen.dart';
import '../../features/home/learning_domain_screen.dart';
import '../../features/home/quran_library_screen.dart';

final routerProvider = Provider<GoRouter>((ref) =>
    GoRouter(initialLocation: '/welcome', routes: [
      GoRoute(
          path: '/domain/:id',
          builder: (_, state) =>
              LearningDomainScreen(domainId: state.pathParameters['id']!)),
      GoRoute(
          path: '/quran-library',
          builder: (_, __) => const QuranLibraryScreen()),
      GoRoute(path: '/quran-hub', builder: (_, __) => const QuranHubScreen()),
      GoRoute(
          path: '/legacy-content',
          builder: (_, __) => const LegacyContentScreen()),
      GoRoute(path: '/welcome', builder: (_, __) => const NoorWelcomeScreen()),
      GoRoute(path: '/', builder: (_, __) => const WhoLearnsScreen()),
      GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
      GoRoute(
          path: '/section/:id',
          builder: (_, s) => SectionScreen(sectionId: s.pathParameters['id']!)),
      GoRoute(
          path: '/prayer-tracker',
          builder: (_, __) => const PrayerTrackerScreen()),
      GoRoute(
          path: '/quran-recitation',
          builder: (_, __) => const QuranRecitationScreen()),
      GoRoute(
          path: '/memory-game',
          builder: (_, __) => const NoorMemoryGameScreen()),
      GoRoute(
          path: '/letter-game',
          builder: (_, __) => const NoorLetterBuilderGameScreen()),
      GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
      GoRoute(path: '/library', builder: (_, __) => const LibraryScreen()),
      GoRoute(path: '/rewards', builder: (_, __) => const RewardsScreen()),
      GoRoute(path: '/games', builder: (_, __) => const NoorGamesScreen()),
      GoRoute(path: '/stories', builder: (_, __) => const NoorStoriesScreen()),
      GoRoute(path: '/studio', builder: (_, __) => const NoorStudioScreen()),
      GoRoute(path: '/lab', builder: (_, __) => const NoorLabScreen()),
      GoRoute(path: '/guide', builder: (_, __) => const NoorGuideScreen()),
      GoRoute(path: '/parent', builder: (_, __) => const ParentGateScreen()),
      GoRoute(
          path: '/parent/dashboard',
          builder: (_, __) => const ParentDashboardScreen()),
    ]));
