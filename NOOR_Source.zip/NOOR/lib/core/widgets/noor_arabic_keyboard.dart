import 'package:material_ui/material_ui.dart';

/// Child-friendly Arabic keyboard in a familiar Arabic 101 layout.
class NoorArabicKeyboard extends StatefulWidget {
  const NoorArabicKeyboard({
    super.key,
    required this.controller,
    this.onUseSystemKeyboard,
  });

  final TextEditingController controller;
  final VoidCallback? onUseSystemKeyboard;

  @override
  State<NoorArabicKeyboard> createState() => _NoorArabicKeyboardState();
}

class _NoorArabicKeyboardState extends State<NoorArabicKeyboard> {
  static const numberRow = [
    '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '٠',
  ];
  static const rows = <List<String>>[
    ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'],
    ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط'],
    ['ئ', 'ء', 'ؤ', 'ر', 'لا', 'ى', 'ة', 'و', 'ز', 'ظ', 'ذ'],
    ['أ', 'إ', 'آ', 'ٱ'],
  ];

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_refresh);
  }

  @override
  void didUpdateWidget(covariant NoorArabicKeyboard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_refresh);
      widget.controller.addListener(_refresh);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  void _insert(String value) {
    final current = widget.controller.value;
    final selection = current.selection;
    final start = selection.isValid ? selection.start : current.text.length;
    final end = selection.isValid ? selection.end : current.text.length;
    final text = current.text.replaceRange(start, end, value);
    widget.controller.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: start + value.length),
    );
  }

  void _backspace() {
    final current = widget.controller.value;
    final selection = current.selection;
    final start = selection.isValid ? selection.start : current.text.length;
    final end = selection.isValid ? selection.end : current.text.length;
    if (start == 0 && end == 0) return;
    var deleteStart = start;
    if (start == end) {
      final preceding = current.text.substring(0, start).characters;
      if (preceding.isEmpty) return;
      deleteStart = start - preceding.last.length;
    }
    final text = current.text.replaceRange(deleteStart, end, '');
    widget.controller.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: deleteStart),
    );
  }

  Widget _key(String label, {VoidCallback? onTap, bool utility = false}) {
    final colors = Theme.of(context).colorScheme;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(2.5),
        child: Material(
          color: utility ? colors.secondaryContainer : colors.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onTap,
            child: SizedBox(
              height: utility ? 46 : 45,
              child: Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(label, style: TextStyle(
                    fontSize: utility ? 13 : 19,
                    fontWeight: FontWeight.w800,
                    color: colors.onSurface,
                  )),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * .86),
        child: Material(
          color: colors.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 38, height: 4, decoration: BoxDecoration(
                color: colors.outlineVariant, borderRadius: BorderRadius.circular(8))),
              const SizedBox(height: 10),
              Row(children: [
                Icon(Icons.translate_rounded, color: colors.primary),
                const SizedBox(width: 8),
                const Expanded(child: Text('اكتب اسم الطفل', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
                IconButton(tooltip: 'مسح الاسم', visualDensity: VisualDensity.compact,
                  onPressed: widget.controller.clear, icon: const Icon(Icons.backspace_outlined)),
                IconButton(tooltip: 'إغلاق لوحة المفاتيح', visualDensity: VisualDensity.compact,
                  onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.keyboard_hide_rounded)),
              ]),
              TextField(
                controller: widget.controller,
                readOnly: true,
                showCursor: false,
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: 'الاسم يظهر هنا', filled: true,
                  fillColor: colors.surfaceContainerLow,
                  prefixIcon: const Icon(Icons.person_outline_rounded),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
              const SizedBox(height: 8),
              Directionality(textDirection: TextDirection.rtl, child: Row(children: [
                for (final digit in numberRow)
                  _key(digit, onTap: () => _insert(digit)),
              ])),
              for (final row in rows)
                Directionality(textDirection: TextDirection.rtl, child: Row(children: [
                  for (final letter in row) _key(letter, onTap: () => _insert(letter)),
                ])),
              const SizedBox(height: 3),
              Directionality(textDirection: TextDirection.rtl, child: Row(children: [
                _key('مسافة', utility: true, onTap: () => _insert(' ')),
                _key('حذف', utility: true, onTap: _backspace),
                _key('مسح', utility: true, onTap: widget.controller.clear),
              ])),
              if (widget.onUseSystemKeyboard != null) ...[
                const SizedBox(height: 6),
                TextButton.icon(
                  onPressed: widget.onUseSystemKeyboard,
                  icon: const Icon(Icons.keyboard_alt_outlined),
                  label: const Text('استخدام كيبورد الجهاز'),
                ),
              ],
              const SizedBox(height: 5),
              SizedBox(width: double.infinity, height: 50, child: FilledButton.icon(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.check_rounded),
                label: const Text('تم — متابعة', style: TextStyle(fontWeight: FontWeight.w900)),
              )),
            ]),
          ),
        ),
      ),
    );
  }
}
