import 'dart:async';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'data/providers.dart';

class NoorApp extends ConsumerWidget {
  const NoorApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dark = ref.watch(darkModeProvider).valueOrNull ?? false;
    return MaterialApp.router(
        title: 'نور | NOOR',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: dark ? ThemeMode.dark : ThemeMode.light,
        locale: const Locale('ar', 'EG'),
        supportedLocales: const [Locale('ar', 'EG')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        routerConfig: ref.watch(routerProvider));
  }
}

/// يسجل وقت بقاء التطبيق في الواجهة الأمامية لكل ملف مستخدم.
/// القياس تقريبي ويُحفظ على دفعات قصيرة لتقليل فقد البيانات.
class UsageTrackingScope extends ConsumerStatefulWidget {
  const UsageTrackingScope({super.key, required this.child});
  final Widget child;

  @override
  ConsumerState<UsageTrackingScope> createState() => _UsageTrackingScopeState();
}

class _UsageTrackingScopeState extends ConsumerState<UsageTrackingScope>
    with WidgetsBindingObserver {
  Timer? _timer;
  DateTime _lastTick = DateTime.now();
  bool _active = true;
  bool _limitDialogOpen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (_active) unawaited(_flushFor(ref.read(selectedChildIdProvider)));
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _lastTick = DateTime.now();
      _active = true;
    } else if (_active) {
      unawaited(_flushFor(ref.read(selectedChildIdProvider)));
      _active = false;
    }
  }

  Future<void> _flushFor(int? childId, {bool checkLimit = true}) async {
    if (!_active || childId == null) return;
    final now = DateTime.now();
    final seconds = now.difference(_lastTick).inSeconds;
    _lastTick = now;
    if (seconds > 0)
      await ref.read(childRepositoryProvider).addUsage(childId, seconds);
    if (!checkLimit || !_active) return;
    final limit = await ref.read(settingsRepositoryProvider).dailyLimit();
    if (limit <= 0 || !mounted || _limitDialogOpen) return;
    final used =
        await ref.read(childRepositoryProvider).todaySecondsUsed(childId);
    if (used >= limit * 60 && mounted && !_limitDialogOpen) _showLimitDialog();
  }

  void _showLimitDialog() {
    if (_limitDialogOpen || !mounted) return;
    _limitDialogOpen = true;
    showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => PopScope(
            canPop: false,
            child: AlertDialog(
              icon: const Icon(Icons.nightlight_round, size: 42),
              title: const Text('انتهى وقت اليوم'),
              content: const Text(
                  'أحسنت في رحلتك اليوم! حان وقت الراحة. يمكنك العودة غدًا أو طلب مساعدة ولي الأمر.'),
              actions: [
                FilledButton(
                    onPressed: () {
                      GoRouter.of(dialogContext).go('/parent');
                    },
                    child: const Text('مساحة ولي الأمر'))
              ],
            ))).whenComplete(() {
      _limitDialogOpen = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<int?>(selectedChildIdProvider, (previous, next) {
      if (previous != next) {
        _limitDialogOpen = false;
        unawaited(_flushFor(previous, checkLimit: false));
        _lastTick = DateTime.now();
      }
    });
    return widget.child;
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}
