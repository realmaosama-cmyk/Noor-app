import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/models/child.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';

class NoorGamesScreen extends ConsumerStatefulWidget {
  const NoorGamesScreen({super.key});
  @override
  ConsumerState<NoorGamesScreen> createState() => _NoorGamesScreenState();
}

class _NoorGamesScreenState extends ConsumerState<NoorGamesScreen> {
  int mode = 0;
  int round = 0;
  int score = 0;
  int streak = 0;
  int? selected;
  bool answered = false;
  late List<int> order;
  final math.Random random = math.Random();
  static const icons = ['🌙', '⭐', '🌈', '🪐', '🌻', '🦋'];
  @override
  void initState() {
    super.initState();
    order = List.generate(6, (i) => i);
  }

  void next() {
    setState(() {
      round++;
      selected = null;
      answered = false;
      order.shuffle(random);
    });
  }

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    if (child == null)
      return const Scaffold(
          body: Center(child: Text('اختَر ملف المتعلم أولًا')));
    final question = _question(child, round);
    return Scaffold(
        appBar: AppBar(title: const Text('ملعب نور 🎮')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-space.webp',
            child: ListView(padding: const EdgeInsets.all(18), children: [
              _HubBanner(
                  emoji: '🎮',
                  title: 'أهلًا في ملعب نور',
                  subtitle: 'تحديات تتدرج مع عمرك • ${child.ageLabel}'),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: () => context.push('/memory-game'),
                        icon: const Icon(Icons.grid_view_rounded),
                        label: const Text('ذاكرة النجوم'))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: () => context.push('/letter-game'),
                        icon: const Icon(Icons.abc_rounded),
                        label: const Text('تركيب الحروف')))
              ]),
              const SizedBox(height: 16),
              Wrap(spacing: 8, children: [
                ChoiceChip(
                    label: const Text('مطابقة'),
                    selected: mode == 0,
                    onSelected: (_) {
                      setState(() => mode = 0);
                      next();
                    }),
                ChoiceChip(
                    label: const Text('رياضيات'),
                    selected: mode == 1,
                    onSelected: (_) {
                      setState(() => mode = 1);
                      next();
                    }),
                ChoiceChip(
                    label: const Text('منطق'),
                    selected: mode == 2,
                    onSelected: (_) {
                      setState(() => mode = 2);
                      next();
                    }),
                ChoiceChip(
                    label: const Text('كلمات'),
                    selected: mode == 3,
                    onSelected: (_) {
                      setState(() => mode = 3);
                      next();
                    }),
              ]),
              const SizedBox(height: 14),
              Card(
                  child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Row(children: [
                              Expanded(
                                  child: Text(
                                      mode == 0
                                          ? 'اعثر على الرمز المطلوب'
                                          : mode == 1
                                              ? 'حل التحدي الحسابي'
                                              : mode == 2
                                                  ? 'فكّر واختر النمط الصحيح'
                                                  : 'اختر الكلمة المناسبة',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge)),
                              Chip(label: Text('⭐ $score  •  🔥 $streak'))
                            ]),
                            const SizedBox(height: 18),
                            if (mode == 0) ...[
                              Text(
                                  'ابحث عن: ${icons[(round + 2) % icons.length]}',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 42)),
                              const SizedBox(height: 14),
                              GridView.count(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  crossAxisCount: 3,
                                  children: [
                                    for (var i in order)
                                      Padding(
                                          padding: const EdgeInsets.all(5),
                                          child: _GameTile(
                                              label: icons[i],
                                              selected: selected == i,
                                              onTap: answered
                                                  ? null
                                                  : () async {
                                                      setState(() {
                                                        selected = i;
                                                        answered = true;
                                                        if (i ==
                                                            (round + 2) %
                                                                icons.length) {
                                                          score += 10;
                                                          streak++;
                                                        } else {
                                                          streak = 0;
                                                        }
                                                      });
                                                      if (i ==
                                                          (round + 2) %
                                                              icons.length)
                                                        await _award(child.id);
                                                    }))
                                  ]),
                              if (answered)
                                Text(
                                    selected == (round + 2) % icons.length
                                        ? 'أحسنت! وجدت الرمز 🎉'
                                        : 'محاولة جميلة! جرّب جولة أخرى.',
                                    textAlign: TextAlign.center),
                            ] else ...[
                              Text(question.$1,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      fontSize: 28,
                                      fontWeight: FontWeight.w900)),
                              const SizedBox(height: 16),
                              for (var i = 0; i < question.$2.length; i++)
                                Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: OutlinedButton(
                                        onPressed: answered
                                            ? null
                                            : () async {
                                                setState(() {
                                                  selected = i;
                                                  answered = true;
                                                  if (i == question.$3) {
                                                    score += 10;
                                                    streak++;
                                                  } else {
                                                    streak = 0;
                                                  }
                                                });
                                                if (i == question.$3)
                                                  await _award(child.id);
                                              },
                                        child: Text(question.$2[i],
                                            style: const TextStyle(
                                                fontSize: 18)))),
                              if (answered)
                                Text(
                                    selected == question.$3
                                        ? 'إجابة صحيحة! +10 نقاط ⭐'
                                        : 'الإجابة الصحيحة: ${question.$2[question.$3]}',
                                    textAlign: TextAlign.center),
                            ],
                            const SizedBox(height: 12),
                            FilledButton.icon(
                                onPressed: answered ? next : null,
                                icon: const Icon(Icons.arrow_forward_rounded),
                                label: const Text('التحدي التالي')),
                          ]))),
              const SizedBox(height: 12),
              Text(_gameHint(child),
                  style: Theme.of(context).textTheme.bodyMedium),
              if (streak >= 3)
                const Card(
                    child: Padding(
                        padding: EdgeInsets.all(14),
                        child: Text(
                            '🔥 سلسلة رائعة! ثلاث إجابات صحيحة متتالية. استمر في المحاولة الذكية!'))),
              const Card(
                  child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Text(
                          'الألعاب تعمل دون إنترنت. كل إجابة صحيحة تمنحك 10 نقاط ونجمة تُضاف إلى ملفك على هذا الجهاز.'))),
            ])));
  }

  (String, List<String>, int) _question(Child c, int n) {
    if (mode == 3) {
      final words = c.age <= 7
          ? const [
              ('أي صورة/كلمة تدل على شيء نقرأه؟', ['كتاب', 'كرة', 'ماء'], 0),
              ('أين نرى السمك؟', ['في الماء', 'في الشجرة', 'في السماء'], 0)
            ]
          : const [
              ('أي كلمة تعني عكس «كبير»؟', ['صغير', 'طويل', 'واسع'], 0),
              ('أكمل: كتاب، قلم، ...', ['ممحاة', 'سحابة', 'نافذة'], 0),
              ('أي كلمة تبدأ بحرف الميم؟', ['شمس', 'مفتاح', 'باب'], 1),
              ('اختر كلمة تصف البحر:', ['هادئ', 'يكتب', 'يركض'], 0)
            ];
      return words[n % words.length];
    }
    if (mode == 1) {
      final a = 2 + n % (c.age <= 8 ? 5 : 18);
      final b = 1 + (n * 3) % (c.age <= 8 ? 5 : 17);
      return ('$a + $b = ؟', ['$a', '${a + b}', '${a + b + 2}'], 1);
    }
    final items = c.age <= 8
        ? ('ما الذي يأتي بعد: ⭐ 🌙 ⭐ 🌙 ؟', ['⭐', '🌈', '🌻'], 0)
        : c.age <= 13
            ? ('إذا كان كل مربع = 4، فكم يساوي مربعان؟', ['6', '8', '12'], 1)
            : ('أي اختيار يكمل النمط: 2، 4، 8، 16، ؟', ['18', '24', '32'], 2);
    return items;
  }

  Future<void> _award(int childId) async {
    await ref
        .read(childRepositoryProvider)
        .addReward(childId, points: 10, stars: 1);
    ref.invalidate(selectedChildProvider);
    ref.invalidate(childrenProvider);
  }

  String _gameHint(Child c) => c.age <= 5
      ? 'تعرّف إلى الأشكال والألوان بهدوء، ولا يوجد وقت محدد للإجابة.'
      : c.age <= 9
          ? 'جرّب تذكر مواقع الرموز، وخذ وقتك في التفكير.'
          : c.age <= 13
              ? 'ابحث عن العلاقة بين الأرقام قبل اختيار الإجابة.'
              : 'حلّل النمط، وجرّب استراتيجية مختلفة إذا احتجت.';
}

class NoorStoriesScreen extends ConsumerWidget {
  const NoorStoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    final young = (child?.age ?? 8) <= 8;
    final role = child?.gender == 'female'
        ? 'قائدة نور'
        : child?.gender == 'male'
            ? 'قائد نور'
            : 'صديق نور';
    final stories = young
        ? const [
            (
              '🐢',
              'السلحفاة والنجم',
              'ساعد السلحفاة في اختيار الطريق الآمن إلى النجم.',
              'التأني والمثابرة'
            ),
            (
              '🌱',
              'بذرة صغيرة',
              'اختر ما تحتاجه البذرة لتنمو وتصبح شجرة.',
              'العناية بالطبيعة'
            ),
            (
              '🐬',
              'صديق البحر',
              'ساعد الدلفين الصغير في حماية الشاطئ.',
              'المسؤولية والتعاون'
            )
          ]
        : const [
            (
              '🧭',
              'سر الخريطة القديمة',
              'أمامك ثلاث طرق؛ اختر الأدلة التي تقودك للحل.',
              'الاستدلال واتخاذ القرار'
            ),
            (
              '🚀',
              'مهمة محطة الفضاء',
              'ساعد الفريق على توزيع الموارد وحل المشكلة.',
              'التعاون والتخطيط'
            ),
            (
              '🔐',
              'شفرة المدينة الذكية',
              'حل سلسلة من القرائن لفتح بوابة المدينة.',
              'المنطق والتفكير النقدي'
            )
          ];
    return Scaffold(
        appBar: AppBar(title: const Text('قصص ومغامرات 📚')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-forest.webp',
            child: ListView(padding: const EdgeInsets.all(18), children: [
              _HubBanner(
                  emoji: '📖',
                  title: '$role • كل اختيار يصنع حكاية',
                  subtitle: 'قصص قصيرة بمواقف وقرارات مناسبة لمرحلتك'),
              for (final story in stories)
                Card(
                    child: ListTile(
                        isThreeLine: true,
                        leading: Text(story.$1,
                            style: const TextStyle(fontSize: 34)),
                        title: Text(story.$2),
                        subtitle: Text('${story.$3}\nالمهارة: ${story.$4}'),
                        trailing: const Icon(Icons.chevron_left),
                        onTap: () =>
                            _openStory(context, story.$2, story.$3, young))),
            ])));
  }

  void _openStory(
      BuildContext context, String title, String summary, bool young) {
    int choice = -1;
    bool revealed = false;
    final options = young
        ? const [
            'أراقب العلامات حولي.',
            'أسأل صديقًا عن الطريق.',
            'أجرب خطوة صغيرة بحذر.'
          ]
        : const [
            'أحلل الأدلة وأرتبها.',
            'أوزع الأدوار مع الفريق.',
            'أختبر فرضية وأراجع النتيجة.'
          ];

    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(title),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(summary),
                  const SizedBox(height: 12),
                  for (var i = 0; i < options.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 7),
                      child: ChoiceChip(
                        label: Text(options[i]),
                        selected: choice == i,
                        onSelected: revealed
                            ? null
                            : (_) => setDialogState(() {
                                  choice = i;
                                }),
                      ),
                    ),
                  if (revealed)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        choice == 0
                            ? 'أحسنت! الملاحظة الجيدة فتحت لك دليلًا جديدًا. ✨'
                            : choice == 1
                                ? 'رائع! التعاون أضاف فكرة ساعدت الفريق. 🤝'
                                : 'ممتاز! التجربة الآمنة علمتك شيئًا جديدًا. 🌟',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF0D9488),
                        ),
                      ),
                    ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('إغلاق'),
                ),
                FilledButton(
                  onPressed: choice < 0
                      ? null
                      : () => setDialogState(() {
                            revealed = true;
                          }),
                  child: Text(revealed ? 'تم' : 'اختر هذا المسار'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class NoorStudioScreen extends StatefulWidget {
  const NoorStudioScreen({super.key});
  @override
  State<NoorStudioScreen> createState() => _NoorStudioScreenState();
}

class _NoorStudioScreenState extends State<NoorStudioScreen> {
  final List<Offset?> points = [];
  Color color = const Color(0xFF0D9488);
  double stroke = 6;

  @override
  Widget build(BuildContext context) {
    const palette = [
      Color(0xFF0D9488),
      Color(0xFFFF796C),
      Color(0xFF7566D9),
      Color(0xFFFFC857),
      Colors.black,
      Color(0xFF4D9DE0),
      Color(0xFF71B77A),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('استوديو الإبداع 🎨'),
        actions: [
          IconButton(
            onPressed: () => setState(() {
              points.clear();
            }),
            icon: const Icon(Icons.delete_outline),
            tooltip: 'مسح اللوحة',
          ),
        ],
      ),
      body: NoorPageBackground(
          asset: 'assets/branding/noor-bg-ocean.webp',
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: Wrap(
                        spacing: 10,
                        runSpacing: 8,
                        children: palette
                            .map((value) => InkWell(
                                  onTap: () => setState(() {
                                    color = value;
                                  }),
                                  borderRadius: BorderRadius.circular(30),
                                  child: CircleAvatar(
                                    backgroundColor: value,
                                    radius: 18,
                                    child: color == value
                                        ? const Icon(Icons.check,
                                            color: Colors.white)
                                        : null,
                                  ),
                                ))
                            .toList(),
                      ),
                    ),
                    IconButton(
                      onPressed: () => setState(() {
                        stroke = stroke == 6 ? 14 : 6;
                      }),
                      icon: const Icon(Icons.brush_rounded),
                      tooltip: 'تغيير حجم الفرشاة',
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Builder(
                  builder: (canvasContext) => GestureDetector(
                    onPanUpdate: (details) {
                      final box = canvasContext.findRenderObject() as RenderBox;
                      setState(() {
                        points.add(box.globalToLocal(details.globalPosition));
                      });
                    },
                    onPanEnd: (_) => setState(() {
                      points.add(null);
                    }),
                    child: Container(
                      width: double.infinity,
                      color:
                          Theme.of(context).colorScheme.surfaceContainerHighest,
                      child: CustomPaint(
                        painter: _DrawingPainter(points, color, stroke),
                        child: const Center(
                          child: Text(
                            'ارسم فكرتك هنا ✨',
                            style:
                                TextStyle(color: Colors.black26, fontSize: 20),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                    'مساحة رسم محلية؛ لا يتم رفع رسومات الطفل إلى أي خادم.'),
              ),
            ],
          )),
    );
  }
}

class _DrawingPainter extends CustomPainter {
  _DrawingPainter(this.points, this.color, this.width);
  final List<Offset?> points;
  final Color color;
  final double width;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < points.length - 1; i++) {
      final start = points[i];
      final end = points[i + 1];
      if (start != null && end != null) {
        canvas.drawLine(start, end, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DrawingPainter oldDelegate) =>
      oldDelegate.points != points ||
      oldDelegate.color != color ||
      oldDelegate.width != width;
}

class NoorLabScreen extends ConsumerStatefulWidget {
  const NoorLabScreen({super.key});
  @override
  ConsumerState<NoorLabScreen> createState() => _NoorLabScreenState();
}

class _NoorLabScreenState extends ConsumerState<NoorLabScreen> {
  double temperature = 20;
  bool showCloud = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('مختبر الاكتشاف 🔬')),
        body: NoorPageBackground(
          asset: 'assets/branding/noor-bg-space.webp',
          child: ListView(padding: const EdgeInsets.all(18), children: [
            const _HubBanner(
                emoji: '🧪',
                title: 'جرّب ولاحظ',
                subtitle: 'محاكاة تعليمية آمنة تعمل على الجهاز'),
            Card(
                child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(children: [
                      const Text('رحلة قطرة الماء',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold)),
                      Text(
                          temperature < 10
                              ? '❄️ تتجمد المياه في ظروف مناسبة.'
                              : temperature > 75
                                  ? '♨️ يتبخر الماء ويتحول إلى بخار.'
                                  : '💧 الماء في الحالة السائلة.',
                          style: const TextStyle(fontSize: 25),
                          textAlign: TextAlign.center),
                      Slider(
                          value: temperature,
                          min: 0,
                          max: 100,
                          divisions: 20,
                          label: '${temperature.round()}°',
                          onChanged: (v) => setState(() => temperature = v)),
                      Text('درجة الحرارة الافتراضية: ${temperature.round()}°'),
                      const SizedBox(height: 8),
                      FilledButton(
                          onPressed: () =>
                              setState(() => showCloud = !showCloud),
                          child: Text(showCloud
                              ? 'إخفاء دورة الماء'
                              : 'اعرض دورة الماء')),
                      if (showCloud)
                        const Text('☀️ تبخر ← ☁️ تكاثف ← 🌧️ هطول ← 🌊 تجمع',
                            style: TextStyle(fontSize: 17),
                            textAlign: TextAlign.center),
                    ]))),
            const Card(
                child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                        'هذه محاكاة مبسطة للتعلم وليست تجربة مخبرية أو قياسًا علميًا حقيقيًا. لا تستخدم حرارة أو أدوات حقيقية دون إشراف شخص بالغ.'))),
          ]),
        ),
      );
}

class NoorGuideScreen extends ConsumerWidget {
  const NoorGuideScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    final age = child?.age ?? 8;
    final tips = age <= 5
        ? [
            'ابدأ بصورة أو لون تعرفه.',
            'جرّب مرة أخرى ببطء.',
            'اطلب من شخص كبير أن يقرأ السؤال معك.'
          ]
        : age <= 9
            ? [
                'قسّم السؤال إلى خطوات صغيرة.',
                'ابحث عن كلمة أو رقم تعرفه.',
                'اشرح ما فهمته بصوتك.'
              ]
            : age <= 13
                ? [
                    'حدد المعلومات المهمة أولًا.',
                    'جرّب أكثر من طريقة للحل.',
                    'راجع النتيجة وقارنها بالسؤال.'
                  ]
                : [
                    'حلّل المشكلة إلى فرضيات.',
                    'ابحث عن مصدر موثوق يدعم الفكرة.',
                    'قيّم الحل وحدد ما يمكن تحسينه.'
                  ];
    return Scaffold(
      appBar: AppBar(title: const Text('مرشد نور ✨')),
      body: NoorPageBackground(
        asset: 'assets/branding/noor-bg-ocean.webp',
        child: ListView(padding: const EdgeInsets.all(18), children: [
          _HubBanner(
              emoji: '💡',
              title: 'أنا هنا لأساعدك',
              subtitle:
                  'تلميحات تعليمية محلية مناسبة لعمرك، دون اتصال بالإنترنت'),
          for (var i = 0; i < tips.length; i++)
            Card(
                child: ListTile(
                    leading: CircleAvatar(child: Text('${i + 1}')),
                    title: Text(tips[i]))),
          const Card(
              child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                      'مرشد نور في هذا الإصدار يعتمد على إرشادات معدّة مسبقًا على الجهاز، وليس نموذج ذكاء اصطناعي متصلًا أو محادثة حرة.'))),
        ]),
      ),
    );
  }
}

class _HubBanner extends StatelessWidget {
  const _HubBanner(
      {required this.emoji, required this.title, required this.subtitle});
  final String emoji, title, subtitle;
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
              colors: [Color(0xFF155E75), Color(0xFF0D9488)])),
      child: Row(children: [
        Text(emoji, style: const TextStyle(fontSize: 40)),
        const SizedBox(width: 14),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 21,
                  fontWeight: FontWeight.w900)),
          Text(subtitle,
              style: const TextStyle(color: Colors.white70, height: 1.5))
        ]))
      ]));
}

class _GameTile extends StatelessWidget {
  const _GameTile(
      {required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => AnimatedScale(
      scale: selected ? 1.08 : 1,
      duration: const Duration(milliseconds: 180),
      child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(18),
                  border: selected
                      ? Border.all(
                          color: Theme.of(context).colorScheme.primary,
                          width: 2)
                      : null),
              child: Center(
                  child: Text(label, style: const TextStyle(fontSize: 36))))));
}
