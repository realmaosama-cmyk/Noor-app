import 'dart:math';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';

class NoorMemoryGameScreen extends ConsumerStatefulWidget {
  const NoorMemoryGameScreen({super.key});
  @override
  ConsumerState<NoorMemoryGameScreen> createState() =>
      _NoorMemoryGameScreenState();
}

class _NoorMemoryGameScreenState extends ConsumerState<NoorMemoryGameScreen> {
  static const symbols = ['🌙', '⭐', '🦋', '🌈', '🕌', '🌻'];
  late List<int> cards;
  final Set<int> revealed = {};
  final Set<int> matched = {};
  int? first;
  int moves = 0;
  bool busy = false;
  bool rewarded = false;

  @override
  void initState() {
    super.initState();
    _reset();
  }

  void _reset() {
    cards = List<int>.generate(12, (index) => index % symbols.length)
      ..shuffle(Random());
    revealed.clear();
    matched.clear();
    first = null;
    moves = 0;
    busy = false;
    rewarded = false;
  }

  Future<void> _tap(int index) async {
    if (busy || matched.contains(index) || revealed.contains(index)) return;
    setState(() => revealed.add(index));
    if (first == null) {
      first = index;
      return;
    }
    moves++;
    final previous = first!;
    if (cards[previous] == cards[index]) {
      setState(() {
        matched.add(previous);
        matched.add(index);
        first = null;
      });
      if (matched.length == cards.length) await _finish();
    } else {
      busy = true;
      await Future<void>.delayed(const Duration(milliseconds: 850));
      if (!mounted) return;
      setState(() {
        revealed.remove(previous);
        revealed.remove(index);
        first = null;
        busy = false;
      });
    }
  }

  Future<void> _finish() async {
    if (rewarded) return;
    rewarded = true;
    final child = await ref.read(selectedChildProvider.future);
    if (child == null) return;
    await ref
        .read(childRepositoryProvider)
        .addReward(child.id, points: 60, stars: 3);
    await ref
        .read(childRepositoryProvider)
        .awardBadge(child.id, 'memory_master');
    ref.invalidate(selectedChildProvider);
    ref.invalidate(childrenProvider);
    if (mounted)
      showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
                icon: const Icon(Icons.emoji_events_rounded,
                    color: Color(0xFFFFC85A), size: 48),
                title: const Text('بطل الذاكرة!'),
                content: Text(
                    'أنهيت كل الأزواج في $moves محاولة. حصلت على 60 نقطة و3 نجوم!'),
                actions: [
                  FilledButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        setState(_reset);
                      },
                      child: const Text('العب مرة أخرى'))
                ],
              ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('لعبة ذاكرة النجوم')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-space.webp',
            motif: '⭐',
            child: ListView(padding: const EdgeInsets.all(18), children: [
              Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      gradient: const LinearGradient(
                          colors: [Color(0xFF183B68), Color(0xFF168F91)])),
                  child: Column(children: [
                    const Text('اكشف البطاقات واعثر على كل زوج متشابه',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 17),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 8),
                    Text(
                        'المحاولات: $moves  •  الأزواج: ${matched.length ~/ 2} من 6',
                        style: const TextStyle(color: Colors.white70))
                  ])),
              const SizedBox(height: 16),
              GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: cards.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: .95),
                  itemBuilder: (context, index) {
                    final open =
                        revealed.contains(index) || matched.contains(index);
                    return AnimatedScale(
                        scale: open ? 1 : .96,
                        duration: const Duration(milliseconds: 180),
                        child: Material(
                            color:
                                open ? Colors.white : const Color(0xFF1B7788),
                            borderRadius: BorderRadius.circular(20),
                            child: InkWell(
                                borderRadius: BorderRadius.circular(20),
                                onTap: () => _tap(index),
                                child: Center(
                                    child: Text(
                                        open ? symbols[cards[index]] : '✦',
                                        style: TextStyle(
                                            fontSize: open ? 38 : 32,
                                            color: open
                                                ? null
                                                : Colors.white))))));
                  }),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                  onPressed: () => setState(_reset),
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('إعادة اللعبة')),
            ])),
      );
}
