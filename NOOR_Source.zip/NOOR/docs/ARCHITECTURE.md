# معمارية نور | NOOR

## التجربة التعليمية
- واجهة مغامرات عربية RTL مع هوية موحدة وحركة دخول وبطاقات وأزرار تفاعلية.
- تصفية الدروس حسب العمر، وتدرج صياغة الشرح والتلميحات وفق المرحلة.
- ملفات متعددة للمتعلمين مع رفيق وشخصية قابلة للاختيار.
- ألعاب قصيرة، قصص اختيارية، استوديو رسم، محاكاة علمية، ومرشد تلميحات محلي.

## الوحدات
- `features/home`: الرئيسية، العوالم، الدروس، المكتبة، المكافآت، ومراكز الألعاب والقصص والإبداع والمختبر والمرشد.
- `features/profile`: إدارة ملف المتعلم ومظهره.
- `features/parent`: بوابة ولي الأمر، ملخص التقدم، التحكم في الأقسام والوقت الإرشادي.
- `data/content/catalog.dart`: الكتالوج والأسئلة والمراجع والفئات العمرية.
- `data/db`: SQLite والترقيات.
- `data/repositories`: الملفات الشخصية والتقدم والمكافآت والاستخدام.
- `core/theme` و`core/widgets`: الألوان والهوية والحركة.

## التشغيل والخصوصية
- البيانات وملفات المتعلمين محفوظة محليًا في SQLite.
- الألعاب والقصص والرسم والمحاكاة والمرشد الأساسي تعمل دون اتصال.
- مرشد نور يعتمد على تلميحات معدة مسبقًا وليس خدمة ذكاء اصطناعي أو اتصالًا خارجيًا.
- لا توجد محادثات عامة أو مزامنة سحابية في هذا الإصدار.
- لا تعرض الدروس صورًا تجسد الأنبياء أو الصحابة.

## GitHub Actions
يُفك `NOOR_Source.zip`، ثم يهيئ Android عند الحاجة ويستخدم أحدث Flutter مستقر من قناة `stable`. يشغل التنسيق والتحليل والاختبارات ثم يبني APK release فقط، ويحدث أرشيف المصدر على فرع العمل بعد نجاح البناء. لا يُبنى AAB.


## NOOR 1.2 — Hybrid experience update

- The content catalog now contains 30 worlds and 80 lessons. Each lesson keeps its own age range, learning text, quiz questions, and source note.
- Nine new worlds cover astronomy, animal science, emotional literacy, financial literacy, digital citizenship, rhythm, sports, cooking, and engineering.
- Learner onboarding has five steps: name/avatar, age, optional presentation, interests, and a short non-graded starter quiz.
- Interest preferences reorder relevant worlds but do not hide other worlds. Gender affects optional wording only; it does not restrict content.
- Visual assets are bundled locally: the NOOR symbol, launcher icon sizes, three mascot portraits, and space/forest/ocean backgrounds.
- The games hub offers matching, mathematics, logic, and word challenges with streak feedback.
- The Android release remains a signed APK only; the CI workflow formats, analyzes, tests, builds, verifies the signature, and uploads the APK artifact.
