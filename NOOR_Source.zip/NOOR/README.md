# نور | NOOR

**نور** مساحة تعلم عربية تفاعلية تجمع المعرفة واللعب والإبداع، وتكيّف مستوى التجربة مع عمر المتعلم وملفه الشخصي.

## التجربة
- هوية بصرية عربية RTL باسم **نور | NOOR**، شعار SVG، ألوان موحدة، بطاقات متحركة وأزرار تفاعلية.
- 30 عالمًا تعليميًا و80 درسًا واختبارًا قصيرًا، مع مصادر ومجالات عمرية.
- مسارات عمرية متدرجة: اكتشاف مبكر، مغامرة، تحديات، واستقلالية.
- اختيار شخصية ورفيق رحلة دون حصر الألعاب أو الموضوعات حسب النوع؛ التخصيص في أسلوب الخطاب والشخصيات مع بقاء جميع الأنشطة متاحة للجميع.
- ملعب ألعاب بأربعة أنماط (مطابقة، رياضيات، منطق، كلمات) ومكافآت محلية.
- قصص بمواقف واختيارات، واستوديو رسم محلي، ومختبر محاكاة دورة الماء.
- مرشد نور يقدم تلميحات معدة مسبقًا حسب العمر ويعمل دون اتصال؛ ليس نموذج ذكاء اصطناعي متصلًا.
- ملفات متعددة، تقدم وشارات ومكافآت، مكتبة بحث وحفظ، ولوحة ولي الأمر مع حدود وقت إرشادية.
- الخصائص الأساسية تعمل دون إنترنت؛ لا توجد محادثات عامة أو مزامنة سحابية في هذا الإصدار.

## التقنية
Flutter / Dart، Riverpod، go_router، SQLite. الأصول والواجهات الأساسية محلية.

## البناء والتحقق
GitHub Actions يستخدم أحدث Flutter مستقر من قناة `stable` ويشغل `flutter pub get` ثم `dart format lib test` و`flutter analyze` و`flutter test`، وبعدها يبني **APK release فقط** عبر `flutter build apk --release`. ينشر APK وأرشيف المصدر كملفات artifacts. لا يتم إنشاء AAB.

> المحتوى الديني تعليمي أولي ويحتاج مراجعة شرعية متخصصة قبل النشر العام. المحاكاة العلمية تعليمية وليست تجارب فعلية.


## تجربة NOOR الجديدة
- مقدمة ترحيبية متحركة وهوية شعار متحركة داخل التطبيق.
- معالج إنشاء ملف من خمس خطوات: الاسم والشخصية، العمر 3–16، النوع الاختياري، الاهتمامات، وتحدي تعارف قصير غير تقييمي.
- تخصيص ترتيب العوالم حسب اهتمامات المتعلم، مع استمرار إتاحة الأنشطة للجميع.
- تصميم واجهة بخلفيات متدرجة وبطاقات تفاعلية؛ إصلاح بطاقات مناطق الاستكشاف التي كانت تظهر كمساحات رمادية.
- تهيئة أيقونة Android adaptive launcher من ملفات الهوية.
- توقيع APK من GitHub Actions باستخدام Secrets دون تخزين مفاتيح التوقيع في المستودع.


### الإصدار 1.1.0 (سابق)
- مقدمة ترحيبية متحركة وشعار نور نابض بالحركة.
- ثلاث شخصيات كرتونية أصلية ورسوم خلفيات لطيفة مدمجة محليًا.
- معالج إنشاء ملف من خمس خطوات: الاسم والشخصية، العمر 3–16، النوع الاختياري، الاهتمامات، وتحدي تعارف قصير غير تقييمي.
- ترتيب العوالم تلقائيًا وفق اهتمامات المتعلم مع إبقاء المحتوى متاحًا للجميع.
- إضافة عالم مستقبل الأبطال بخمس دروس عن المال والتفكير النقدي والتصميم والذكاء الاصطناعي والمشروعات.
- إصلاح بطاقات مناطق الاستكشاف التي كانت تظهر كمساحات رمادية بسبب عنصر Expanded داخل GridView.
- أيقونات Android adaptive launcher وشعار التطبيق.
- توقيع APK من GitHub Actions باستخدام أسرار المستودع، دون تضمين مفاتيح التوقيع في أرشيف المصدر.


## NOOR 1.2 — Hybrid Adventure Learning

- 30 learning worlds and 80 age-aware lessons with quizzes and source notes.
- Learner onboarding includes name, age, optional presentation, interests, and a short non-graded starter check.
- New worlds: astronomy, animal science, emotional literacy, money skills, digital citizenship, rhythm, sports, cooking, and engineering.
- New custom visual assets: fox, owl, unicorn, space, forest, and ocean artwork; refreshed NOOR logo and Android launcher icons.
- Games now include memory, math, logic, and word challenges with streak feedback.
- Gender is used only for optional presentation language; it never hides learning worlds or activities.

Release target: signed Android APK only.

- قراءة الدروس بصوت عربي عبر محرك تحويل النص إلى كلام في الجهاز؛ توفر الصوت العربي يعتمد على المحرك وحزمة اللغة المثبتة.


## Islamic learning and family tools (v1.3)

- The nine core Islamic learning areas contain lessons, quizzes, and references.
- Daily Ayah and Hadith cards rotate locally by date.
- Prayer checklist is stored per learner and day; schema v4 adds its table without deleting existing profiles or progress.
- Verse-by-verse Alafasy recitation streams from EveryAyah.com and requires internet. The app does not synthesize Qur'an recitation with text-to-speech.
- Parent settings include night mode and a daily usage limit with a rest screen; the limit is per selected child.
- Themed pages use lightweight animated ambient decorations.
