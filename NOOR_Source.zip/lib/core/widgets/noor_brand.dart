import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';

class NoorBrand extends StatelessWidget {
  const NoorBrand({super.key, this.compact = false, this.light = false});
  final bool compact;
  final bool light;
  @override
  Widget build(BuildContext context) {
    final foreground = light ? Colors.white : const Color(0xFF18334A);
    return Row(mainAxisSize: MainAxisSize.min, children: [
      _NoorMark(size: compact ? 44 : 66, light: light),
      const SizedBox(width: 11),
      Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('نــور',
                style: TextStyle(
                    color: foreground,
                    fontSize: compact ? 22 : 30,
                    fontWeight: FontWeight.w900,
                    height: 1.05)),
            if (!compact)
              Text('NOOR • LEARN • GROW • SHINE',
                  style: TextStyle(
                      color: foreground.withValues(alpha: .72),
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2)),
          ]),
    ]);
  }
}

class _NoorMark extends StatefulWidget {
  const _NoorMark({required this.size, required this.light});
  final double size;
  final bool light;
  @override
  State<_NoorMark> createState() => _NoorMarkState();
}

class _NoorMarkState extends State<_NoorMark>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2800))
    ..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
      animation: _controller,
      builder: (_, __) => Transform.scale(
          scale: .97 + _controller.value * .06,
          child: Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: widget.light
                          ? const [Color(0xFFFFE5A0), Color(0xFFE8A94D)]
                          : const [Color(0xFF0A9D91), Color(0xFF155B78)]),
                  border: Border.all(
                      color: const Color(0xFFBDEFE8).withValues(alpha: .82), width: 2.2),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xFF0D9B91).withValues(alpha: .25),
                        blurRadius: 26,
                        spreadRadius: 1.5,
                        offset: const Offset(0, 8))
                  ]),
              child: CustomPaint(
                  painter: _NoorMarkPainter(
                      light: widget.light, phase: _controller.value)))));
}

class _NoorMarkPainter extends CustomPainter {
  const _NoorMarkPainter({required this.light, required this.phase});
  final bool light;
  final double phase;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.shortestSide;
    final gold = Paint()..color = const Color(0xFFFFD978);
    final white = Paint()..color = Colors.white;
    final soft = Paint()..color = const Color(0xFFBDEFE8);

    final moonCenter = Offset(s * .285, s * .285);
    final moon = Path()
      ..addOval(Rect.fromCircle(center: moonCenter, radius: s * .115));
    final moonCut = Path()
      ..addOval(Rect.fromCircle(
          center: Offset(s * .335, s * .245), radius: s * .112));
    canvas.drawPath(
        Path.combine(PathOperation.difference, moon, moonCut), gold);

    final starCenter = Offset(s * .755, s * (.235 - phase * .018));
    final star = Path();
    for (var i = 0; i < 8; i++) {
      final angle = -math.pi / 2 + i * math.pi / 4;
      final radius = i.isEven ? s * .105 : s * .043;
      final point = Offset(starCenter.dx + math.cos(angle) * radius,
          starCenter.dy + math.sin(angle) * radius);
      if (i == 0) {
        star.moveTo(point.dx, point.dy);
      } else {
        star.lineTo(point.dx, point.dy);
      }
    }
    star.close();
    canvas.drawPath(star, gold);

    final leftPage = Path()
      ..moveTo(s * .50, s * .57)
      ..cubicTo(s * .40, s * .48, s * .28, s * .45, s * .19, s * .49)
      ..lineTo(s * .19, s * .76)
      ..cubicTo(s * .31, s * .72, s * .42, s * .75, s * .50, s * .83)
      ..close();
    final rightPage = Path()
      ..moveTo(s * .50, s * .57)
      ..cubicTo(s * .60, s * .48, s * .72, s * .45, s * .81, s * .49)
      ..lineTo(s * .81, s * .76)
      ..cubicTo(s * .69, s * .72, s * .58, s * .75, s * .50, s * .83)
      ..close();
    canvas.drawPath(leftPage, white);
    canvas.drawPath(rightPage, soft);
    canvas.drawLine(
        Offset(s * .50, s * .57),
        Offset(s * .50, s * .83),
        Paint()
          ..color = const Color(0xFF0D8E87)
          ..strokeWidth = s * .018
          ..strokeCap = StrokeCap.round);
    canvas.drawCircle(Offset(s * .22, s * .34), s * .018, white);
    canvas.drawCircle(Offset(s * .78, s * .43), s * .014, gold);
  }

  @override
  bool shouldRepaint(covariant _NoorMarkPainter oldDelegate) =>
      oldDelegate.phase != phase || oldDelegate.light != light;
}

class NoorEntrance extends StatelessWidget {
  const NoorEntrance({super.key, required this.delay, required this.child});
  final int delay;
  final Widget child;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 420 + delay.clamp(0, 8).toInt() * 65),
      curve: Curves.easeOutBack,
      builder: (context, value, _) => Opacity(
          opacity: value.clamp(0.0, 1.0).toDouble(),
          child: Transform.translate(
              offset: Offset(0, 20 * (1 - value)), child: child)));
}

class NoorPageBackground extends StatefulWidget {
  const NoorPageBackground(
      {super.key, required this.child, required this.asset, this.motif = '✦'});
  final Widget child;
  final String asset;
  final String motif;
  @override
  State<NoorPageBackground> createState() => _NoorPageBackgroundState();
}

class _NoorPageBackgroundState extends State<NoorPageBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ambient =
      AnimationController(vsync: this, duration: const Duration(seconds: 12))
        ..repeat();
  @override
  void dispose() {
    _ambient.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Stack(fit: StackFit.expand, children: [
      Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: dark
                      ? const [
                          Color(0xFF101D29),
                          Color(0xFF182B3B),
                          Color(0xFF1E263C)
                        ]
                      : const [
                          Color(0xFFF2FAF8),
                          Color(0xFFF7F5FF),
                          Color(0xFFFFFAF2)
                        ]),
              image: DecorationImage(
                  image: AssetImage(widget.asset),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                      dark ? const Color(0xD9101D29) : const Color(0xE8FFFFFF),
                      BlendMode.srcOver)))),
      AnimatedBuilder(
          animation: _ambient,
          builder: (_, __) {
            final t = _ambient.value * 2 * math.pi;
            return IgnorePointer(
                child: Stack(children: [
              Positioned(
                  top: 24 + 12 * math.sin(t),
                  right: 22,
                  child: Opacity(
                      opacity: dark ? .22 : .15,
                      child: Text(widget.motif,
                          style: const TextStyle(fontSize: 34)))),
              Positioned(
                  top: 160 + 18 * math.sin(t + 1.4),
                  left: 18,
                  child: Opacity(
                      opacity: dark ? .20 : .12,
                      child: const Text('✦',
                          style: TextStyle(
                              fontSize: 23, color: Color(0xFFFFC85A))))),
              Positioned(
                  bottom: 110 + 14 * math.sin(t + 2.5),
                  right: 34,
                  child: Opacity(
                      opacity: dark ? .18 : .10,
                      child: const Text('✧',
                          style: TextStyle(
                              fontSize: 38, color: Color(0xFF0D9B91))))),
            ]));
          }),
      widget.child,
    ]);
  }
}
