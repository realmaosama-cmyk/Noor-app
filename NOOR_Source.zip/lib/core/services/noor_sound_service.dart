import 'dart:async';
import 'package:material_ui/material_ui.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';

/// Local sound effects and the original Nour & Fedaa song.
class NoorSoundService {
  NoorSoundService._();

  static final AudioPlayer _effects = AudioPlayer();
  static final AudioPlayer _music = AudioPlayer();
  static bool _enabled = true;
  static bool _musicEnabled = true;

  static bool get enabled => _enabled;
  static bool get musicEnabled => _musicEnabled;
  static bool get musicPlaying => _music.playing;

  static Future<void> setEnabled(bool value) async {
    _enabled = value;
    if (!value) await _effects.stop();
  }

  static Future<void> setMusicEnabled(bool value) async {
    _musicEnabled = value;
    if (!value) {
      await _music.stop();
    } else if (!_music.playing) {
      await playIntroScore(loop: true);
    }
  }

  static Future<void> playEffect(String filename) async {
    if (!_enabled) return;
    const allowed = {
      'correct.wav',
      'intro_score.wav',
      'joy.wav',
      'levelup.wav',
      'success.wav',
      'tap.wav',
    };
    if (!allowed.contains(filename)) return;
    try {
      await _effects.stop();
      await _effects.setAsset(
        'assets/content/legacy/media/audio/sfx/$filename',
      );
      await _effects.play();
    } catch (_) {
      // Missing device audio output must never block a learning activity.
    }
  }

  static Future<void> playSong() async {
    if (!_musicEnabled) return;
    try {
      final session = await AudioSession.instance;
      await session.configure(AudioSessionConfiguration.music());
      await _music.stop();
      await _music.setVolume(0.72);
      await _music.setLoopMode(LoopMode.off);
      await _music.setAsset(
        'assets/content/legacy/media/audio/song/nour_fedaa_song.mp3',
      );
      await _music.play();
    } catch (_) {
      // Surface a silent fallback rather than crashing the app.
    }
  }

  static Future<void> playIntroScore({bool loop = true}) async {
    if (!_musicEnabled) return;
    try {
      final session = await AudioSession.instance;
      await session.configure(AudioSessionConfiguration.music());
      await _music.stop();
      await _music.setVolume(0.14);
      await _music.setLoopMode(loop ? LoopMode.one : LoopMode.off);
      await _music.setAsset(
        'assets/content/legacy/media/audio/sfx/intro_score.wav',
      );
      await _music.play();
    } catch (_) {}
  }

  static Future<void> pauseMusic() => _music.pause();
  static Future<void> resumeMusic() async {
    if (!_musicEnabled) return;
    await _music.play();
  }
  static Future<void> stopMusic() => _music.stop();

  static Future<void> stopAll() async {
    await Future.wait([_effects.stop(), _music.stop()]);
  }
}


/// Plays a quiet local click for route changes without blocking navigation.
class NoorNavigationSoundObserver extends NavigatorObserver {
  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    unawaited(NoorSoundService.playEffect('tap.wav'));
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    unawaited(NoorSoundService.playEffect('tap.wav'));
  }
}
