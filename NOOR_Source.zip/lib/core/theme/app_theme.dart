import 'package:material_ui/material_ui.dart';

class AppColors {
  static const ink = Color(0xFF18334A);
  static const navy = Color(0xFF123B55);
  static const teal = Color(0xFF0D9B91);
  static const gold = Color(0xFFFFC85A);
  static const mist = Color(0xFFF3F8F8);
  static const lavender = Color(0xFFEDEBFF);
  static const coral = Color(0xFFFF8D75);
  static const sky = Color(0xFF78C9EF);
}

class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
        seedColor: AppColors.teal, brightness: Brightness.light);
    return ThemeData(
      useMaterial3: true,
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.linux: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.macOS: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.windows: FadeUpwardsPageTransitionsBuilder(),
        },
      ),
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.mist,
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
      ),
      appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          foregroundColor: AppColors.ink),
      textTheme: const TextTheme(
        headlineMedium: TextStyle(
            fontSize: 30, fontWeight: FontWeight.w900, color: AppColors.ink),
        titleLarge: TextStyle(
            fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.ink),
        titleMedium: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.ink),
        bodyLarge: TextStyle(fontSize: 17, color: AppColors.ink, height: 1.55),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
            minimumSize: const Size(120, 54),
            elevation: 2,
            shadowColor: AppColors.teal.withValues(alpha: .22),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            textStyle:
                const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      ),
      filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
              minimumSize: const Size(120, 52),
              elevation: 1,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              textStyle:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
      chipTheme: ChipThemeData(
          backgroundColor: Colors.white,
          selectedColor: AppColors.teal.withValues(alpha: .16),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
        seedColor: AppColors.teal, brightness: Brightness.dark);
    return ThemeData(
      useMaterial3: true,
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.linux: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.macOS: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.windows: FadeUpwardsPageTransitionsBuilder(),
        },
      ),
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFF101D29),
      appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent, centerTitle: true),
      cardTheme: CardThemeData(
          color: const Color(0xFF1C3040),
          margin: EdgeInsets.zero,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(25))),
      inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF263B4B),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide.none)),
    );
  }
}
