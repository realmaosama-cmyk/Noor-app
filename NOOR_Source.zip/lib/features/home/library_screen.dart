import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/providers.dart';
import '../../data/content/catalog.dart';
import '../../data/content/legacy_content.dart';
import '../../core/widgets/noor_brand.dart';

class LibraryScreen extends ConsumerStatefulWidget {
  const LibraryScreen({super.key});
  @override
  ConsumerState<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends ConsumerState<LibraryScreen> {
  String query = '';

  String _key(String value) => value
      .trim()
      .toLowerCase()
      .replaceAll(RegExp(r'[ًٌٍَُِّْـ]'), '')
      .replaceAll(RegExp(r'\s+'), ' ');

  bool _matches(String term, Iterable<String> fields) =>
      term.isEmpty || fields.any((field) => _key(field).contains(term));

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider);
    final catalog = noorSections.expand((s) => s.lessons).toList(growable: false);
    return Scaffold(
      appBar: AppBar(title: const Text('مكتبتي')),
      body: NoorPageBackground(
        asset: 'assets/branding/noor-bg-ocean.webp',
        child: child.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const Center(child: Text('تعذر تحميل الملف')),
          data: (learner) {
            if (learner == null) return const Center(child: Text('اختر ملف المتعلم أولًا'));
            return Column(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  onChanged: (value) => setState(() => query = value),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search_rounded),
                    hintText: 'ابحث في كل مكتبة نور: الدروس والمحتوى القديم',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Expanded(
                child: FutureBuilder<List<LegacyContentItem>>(
                  future: LegacyContentRepository.loadAll(learner.age),
                  builder: (context, legacySnapshot) {
                    if (legacySnapshot.connectionState == ConnectionState.waiting &&
                        !legacySnapshot.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (legacySnapshot.hasError) {
                      return const Center(child: Text('تعذر تحميل فهرس المكتبة الإضافية'));
                    }
                    final legacy = legacySnapshot.data ?? const <LegacyContentItem>[];
                    final catalogContentKeys = catalog
                        .map((item) => '${_key(item.title)}|${_key(item.body)}')
                        .toSet();
                    final filteredCatalog = catalog.where((item) => _matches(
                      _key(query), [item.title, item.summary, item.body, item.source],
                    )).toList(growable: false);
                    final filteredLegacy = legacy.where((item) =>
                      !catalogContentKeys.contains('${_key(item.title)}|${_key(item.body)}') &&
                      _matches(_key(query), [item.title, item.summary, item.body, item.source, item.category])
                    ).toList(growable: false);

                    return FutureBuilder<List<String>>(
                      future: ref.read(childRepositoryProvider).bookmarks(learner.id),
                      builder: (context, savedSnapshot) {
                        final saved = savedSnapshot.data ?? const <String>[];
                        return ListView(
                          padding: const EdgeInsets.fromLTRB(14, 0, 14, 24),
                          children: [
                            Card(child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Row(children: [
                                const Icon(Icons.auto_stories_rounded, color: Colors.teal),
                                const SizedBox(width: 8),
                                Expanded(child: Text(
                                  '${catalog.length + legacy.length} مادة قبل إزالة التكرار • ${saved.length} محفوظة',
                                  style: const TextStyle(fontWeight: FontWeight.w800),
                                )),
                              ]),
                            )),
                            if (filteredCatalog.isNotEmpty) ...[
                              const Padding(
                                padding: EdgeInsets.fromLTRB(4, 10, 4, 4),
                                child: Text('المسار التعليمي الأساسي',
                                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                              ),
                              for (final lesson in filteredCatalog)
                                Card(child: ListTile(
                                  leading: Icon(saved.contains(lesson.id)
                                      ? Icons.bookmark_rounded : Icons.menu_book_rounded),
                                  title: Text(lesson.title),
                                  subtitle: Text(lesson.summary, maxLines: 2,
                                    overflow: TextOverflow.ellipsis),
                                  onTap: () async {
                                    await showModalBottomSheet<void>(
                                      context: context,
                                      isScrollControlled: true,
                                      builder: (_) => _CatalogLibraryLesson(
                                        lesson: lesson, childId: learner.id),
                                    );
                                    if (mounted) setState(() {});
                                  },
                                )),
                            ],
                            if (filteredLegacy.isNotEmpty) ...[
                              const Padding(
                                padding: EdgeInsets.fromLTRB(4, 18, 4, 4),
                                child: Text('مكتبة نور الإضافية',
                                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                              ),
                              for (final item in filteredLegacy)
                                Card(child: ListTile(
                                  leading: CircleAvatar(child: Text(item.emoji)),
                                  title: Text(item.title),
                                  subtitle: Text(item.summary, maxLines: 2,
                                    overflow: TextOverflow.ellipsis),
                                  trailing: Icon(saved.contains(item.id)
                                      ? Icons.bookmark_rounded : Icons.chevron_left_rounded),
                                  onTap: () async {
                                    await showModalBottomSheet<void>(
                                      context: context,
                                      isScrollControlled: true,
                                      builder: (_) => _LegacyLibraryLesson(
                                        item: item, childId: learner.id),
                                    );
                                    if (mounted) setState(() {});
                                  },
                                )),
                            ],
                            if (filteredCatalog.isEmpty && filteredLegacy.isEmpty)
                              const Padding(
                                padding: EdgeInsets.all(28),
                                child: Text('لا توجد نتائج مطابقة. جرّب كلمة أخرى.',
                                  textAlign: TextAlign.center),
                              ),
                          ],
                        );
                      },
                    );
                  },
                ),
              ),
            ]);
          },
        ),
      ),
    );
  }
}

class _CatalogLibraryLesson extends ConsumerWidget {
  const _CatalogLibraryLesson({required this.lesson, required this.childId});
  final NoorLesson lesson;
  final int childId;

  @override
  Widget build(BuildContext context, WidgetRef ref) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(22),
      child: SingleChildScrollView(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(lesson.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Text(lesson.body, style: const TextStyle(fontSize: 17, height: 1.7)),
          const SizedBox(height: 12),
          Text('المصدر: ${lesson.source}', style: const TextStyle(fontSize: 12)),
          FilledButton.icon(
            onPressed: () async {
              await ref.read(childRepositoryProvider).toggleBookmark(childId, lesson.id);
              if (context.mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.bookmark_add_rounded),
            label: const Text('تبديل الحفظ'),
          ),
        ],
      )),
    ),
  );
}

class _LegacyLibraryLesson extends ConsumerWidget {
  const _LegacyLibraryLesson({required this.item, required this.childId});
  final LegacyContentItem item;
  final int childId;

  @override
  Widget build(BuildContext context, WidgetRef ref) => SafeArea(
    child: Padding(
      padding: EdgeInsets.fromLTRB(20, 18, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(children: [
            Text(item.emoji, style: const TextStyle(fontSize: 28)),
            const SizedBox(width: 10),
            Expanded(child: Text(item.title,
              style: Theme.of(context).textTheme.titleLarge)),
          ]),
          const SizedBox(height: 12),
          Text(item.body, style: const TextStyle(fontSize: 16, height: 1.7)),
          if (item.steps.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('خطوات ومعلومات', style: TextStyle(fontWeight: FontWeight.w900)),
            for (final step in item.steps)
              ListTile(dense: true, contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.check_circle_outline_rounded),
                title: Text(step)),
          ],
          if (item.questions.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('${item.questions.length} أسئلة تدريبية متاحة في قسمها الأصلي.',
              style: const TextStyle(color: Colors.blueGrey)),
          ],
          if (item.source.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('المصدر: ${item.source}', style: Theme.of(context).textTheme.bodySmall),
          ],
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () async {
              await ref.read(childRepositoryProvider).toggleBookmark(childId, item.id);
              if (context.mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.bookmark_add_rounded),
            label: const Text('حفظ في مكتبتي'),
          ),
        ],
      )),
    ),
  );
}
