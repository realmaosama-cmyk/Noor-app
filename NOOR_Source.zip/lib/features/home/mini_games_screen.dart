import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/noor_sound_service.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';
import '../../data/repositories/mini_game_rules.dart';
import '../../data/repositories/missions_repository.dart';

class NoorMiniGamesScreen extends ConsumerStatefulWidget {
  const NoorMiniGamesScreen({super.key});

  @override
  ConsumerState<NoorMiniGamesScreen> createState() => _NoorMiniGamesScreenState();
}

class _NoorMiniGamesScreenState extends ConsumerState<NoorMiniGamesScreen> {
  static const _mazeRoutes = <List<int>>[
    [0, 1, 2, 3, 4, 9, 14, 13, 12, 11, 16, 21, 22, 23, 24],
    [0, 5, 10, 11, 12, 7, 2, 3, 4, 9, 14, 19, 24],
    [0, 1, 6, 11, 16, 15, 20, 21, 22, 17, 12, 13, 14, 19, 24],
  ];
  static const _mazeOpenLevels = <Set<int>>[
    {0, 1, 2, 3, 4, 6, 9, 11, 12, 13, 14, 16, 19, 20, 21, 22, 23, 24},
    {0, 2, 3, 4, 5, 7, 9, 10, 11, 12, 14, 15, 19, 20, 24},
    {0, 1, 3, 6, 8, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 24},
  ];
  static const _differenceLeftLevels = <List<String>>[
    ['🌳', '🌞', '🐝', '🌷', '🦋', '🍃'],
    ['🐱', '🌞', '🌳', '🚗', '🍎', '🌈'],
    ['🚀', '⭐', '🌙', '🪐', '👽', '☄️'],
  ];
  static const _differenceRightLevels = <List<String>>[
    ['🌳', '🌤️', '🐝', '🌻', '🦋', '🍂'],
    ['🐶', '🌞', '🌳', '🚗', '🍐', '🌙'],
    ['🚀', '🌟', '🌙', '🪐', '🛰️', '☄️'],
  ];
  static const _differenceIndicesLevels = <Set<int>>[
    {1, 3, 5},
    {0, 4, 5},
    {1, 4},
  ];
  static const _storyEventsLevels = <List<String>>[
    [
      '🌱 نضع البذرة في التربة',
      '💧 نسقيها ونوفر ضوء الشمس',
      '🌿 تنمو وتظهر الأوراق',
    ],
    [
      '🥚 تضع الدجاجة البيضة',
      '🐣 يخرج الكتكوت من البيضة',
      '🐥 يكبر الكتكوت تدريجيًا',
      '🐔 تصبح دجاجة بالغة',
    ],
    [
      '☁️ يتبخر الماء بفعل حرارة الشمس',
      '💧 يتكاثف البخار وتتكون السحب',
      '🌧️ يسقط المطر على الأرض',
      '🏞️ تتجمع المياه وتبدأ الدورة من جديد',
    ],
  ];
  static const _storyDisplayOrders = <List<int>>[
    [2, 0, 1],
    [2, 0, 3, 1],
    [2, 0, 3, 1],
  ];

  Set<int> get _mazeOpen => _mazeOpenLevels[_level - 1];
  Set<int> get _differenceIndices => _differenceIndicesLevels[_level - 1];
  List<String> get _leftPictures => _differenceLeftLevels[_level - 1];
  List<String> get _rightPictures => _differenceRightLevels[_level - 1];
  List<String> get _storyEvents => _storyEventsLevels[_level - 1];
  List<int> get _storyChallengeOrder => List<int>.generate(_storyEvents.length, (i) => i);
  List<int> get _storyDisplayOrder => _storyDisplayOrders[_level - 1];

  int _mode = 0;
  int _level = 1;
  int _mazePosition = 0;
  int _mazeMoves = 0;
  final Set<int> _foundDifferences = {};
  final List<int> _storySelection = [];
  bool _completed = false;
  bool _saving = false;

  Future<void> _finish() async {
    if (_completed || _saving) return;
    final child = ref.read(selectedChildProvider).valueOrNull;
    if (child == null) return;
    setState(() => _saving = true);
    try {
      await NoorMissionsRepository().recordGameCompletion(
        child.id,
        points: 20 + (_level * 5),
        stars: _level,
      );
      await NoorSoundService.playEffect('success.wav');
      ref.invalidate(selectedChildProvider);
      ref.invalidate(childrenProvider);
      if (!mounted) return;
      setState(() {
        _completed = true;
        _saving = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر حفظ المكافأة الآن. تقدمك في اللعبة ما زال ظاهرًا.')),
      );
    }
  }

  void _reset() {
    setState(() {
      _mazePosition = 0;
      _mazeMoves = 0;
      _foundDifferences.clear();
      _storySelection.clear();
      _completed = false;
      _saving = false;
    });
  }

  void _changeLevel(int level) {
    if (_saving || level == _level) return;
    setState(() => _level = level);
    _reset();
  }

  void _changeMode(int mode) {
    if (_saving || mode == _mode) return;
    setState(() => _mode = mode);
    _reset();
  }

  Future<void> _moveTo(int next) async {
    if (_completed || _saving || !_mazeOpen.contains(next)) return;
    if (!NoorMiniGameRules.isAdjacentCell(_mazePosition, next)) return;
    setState(() {
      _mazePosition = next;
      _mazeMoves++;
    });
    await NoorSoundService.playEffect('tap.wav');
    if (next == 24) await _finish();
  }

  Future<void> _tapDifference(int index) async {
    if (_completed || _saving || _foundDifferences.contains(index)) return;
    if (_differenceIndices.contains(index)) {
      setState(() => _foundDifferences.add(index));
      await NoorSoundService.playEffect('correct.wav');
      if (NoorMiniGameRules.hasFoundAllDifferences(
          _foundDifferences, _differenceIndices)) {
        await _finish();
      }
    } else {
      await NoorSoundService.playEffect('tap.wav');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('قريب! دقّق في التفاصيل مرة أخرى.')),
      );
    }
  }

  Future<void> _selectStoryEvent(int index) async {
    if (_completed || _saving || _storySelection.contains(index)) return;
    setState(() => _storySelection.add(index));
    if (_storySelection.length == _storyEvents.length) {
      if (NoorMiniGameRules.isCorrectStoryOrder(
          _storySelection, _storyChallengeOrder)) {
        await _finish();
      } else {
        await NoorSoundService.playEffect('tap.wav');
        if (!mounted) return;
        setState(_storySelection.clear);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ترتيب غير صحيح. حاول مرة أخرى دون استعجال.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    if (child == null) {
      return const Scaffold(body: Center(child: Text('اختَر ملف المتعلم أولًا')));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('مغامرات الألعاب الجديدة')),
      body: NoorPageBackground(
        asset: 'assets/branding/noor-bg-ocean.webp',
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _MiniGameBanner(name: child.name, age: child.age),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('🧭 المتاهة'),
                  selected: _mode == 0,
                  onSelected: (_) => _changeMode(0),
                ),
                ChoiceChip(
                  label: const Text('🔎 اكتشف الاختلافات'),
                  selected: _mode == 1,
                  onSelected: (_) => _changeMode(1),
                ),
                ChoiceChip(
                  label: const Text('📚 رتّب القصة'),
                  selected: _mode == 2,
                  onSelected: (_) => _changeMode(2),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 8,
                runSpacing: 6,
                children: [
                  const Text('المستوى:', style: TextStyle(fontWeight: FontWeight.w900)),
                  for (var level = 1; level <= 3; level++)
                    ChoiceChip(
                      label: Text('$level'),
                      selected: _level == level,
                      onSelected: (_) => _changeLevel(level),
                    ),
                  Text('مكافأة ${20 + _level * 5} نقطة'),
                ],
              ),
              ),
            ),
            const SizedBox(height: 12),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              switchInCurve: Curves.easeOutBack,
              child: KeyedSubtree(
                key: ValueKey('mini-game-$_mode-level-$_level'),
                child: _gamePanel(),
              ),
            ),
            if (_completed) ...[
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: [
                      const Text('🏆', style: TextStyle(fontSize: 54)),
                      const Text('مغامرة مكتملة!', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                      Text('حصلت على ${20 + _level * 5} نقطة و$_level نجمة، وتم تسجيل إنجاز لعبة في مهامك.'),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: _reset,
                        icon: const Icon(Icons.replay_rounded),
                        label: const Text('العب مرة أخرى'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _gamePanel() {
    if (_mode == 0) return _mazePanel();
    if (_mode == 1) return _differencePanel();
    return _storyPanel();
  }

  Widget _mazePanel() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('المستوى $_level: ساعد المستكشف على الوصول إلى الكنز ⭐', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            const SizedBox(height: 5),
            Text('الحركات: $_mazeMoves • مسار إرشادي: ${_mazeRoutes[_level - 1].length - 1} حركة • اضغط على الخانة المجاورة.'),
            const SizedBox(height: 14),
            AspectRatio(
              aspectRatio: 1,
              child: GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                itemCount: 25,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  crossAxisSpacing: 5,
                  mainAxisSpacing: 5,
                ),
                itemBuilder: (context, index) {
                  final open = _mazeOpen.contains(index);
                  final current = index == _mazePosition;
                  final goal = index == 24;
                  final adjacent = open && NoorMiniGameRules.isAdjacentCell(_mazePosition, index);
                  return InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: open && !_completed && !_saving ? () => _moveTo(index) : null,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      decoration: BoxDecoration(
                        color: !open
                            ? const Color(0xFF35566B)
                            : current
                                ? const Color(0xFFFFD978)
                                : goal
                                    ? const Color(0xFFDDF4E9)
                                    : adjacent
                                        ? const Color(0xFFE7F3FF)
                                        : const Color(0xFFF2F7F6),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.white, width: 1.5),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        current ? '🧒' : goal ? '⭐' : open ? (adjacent ? '·' : '') : '',
                        style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            _MazeControls(onMove: _moveTo, position: _mazePosition),
          ],
        ),
      ),
    );
  }

  Widget _differencePanel() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('هل تلاحظ الاختلافات؟ • المستوى $_level', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            const Text('الصورة الأولى', style: TextStyle(fontWeight: FontWeight.w800)),
            _PictureRow(items: _leftPictures, found: const {}, onTap: null),
            const SizedBox(height: 12),
            const Text('الصورة الثانية — اضغط على الاختلافات', style: TextStyle(fontWeight: FontWeight.w800)),
            _PictureRow(items: _rightPictures, found: _foundDifferences, onTap: _tapDifference),
            const SizedBox(height: 10),
            Text('اكتشفت ${_foundDifferences.length} من ${_differenceIndices.length}', style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: _foundDifferences.length / _differenceIndices.length, minHeight: 8),
          ],
        ),
      ),
    );
  }

  Widget _storyPanel() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(_level == 1 ? 'رتّب مراحل نمو النبتة من البداية للنهاية.' : _level == 2 ? 'رتّب مراحل نمو الدجاجة من البيضة إلى الدجاجة البالغة.' : 'رتّب مراحل دورة الماء في الطبيعة.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
            const SizedBox(height: 12),
            for (final index in _storyDisplayOrder)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: OutlinedButton(
                  onPressed: _storySelection.contains(index) || _completed || _saving
                      ? null
                      : () => _selectStoryEvent(index),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: _storySelection.contains(index)
                        ? const Color(0xFFE3F4EB)
                        : null,
                    padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 10),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 14,
                        child: Text(_storySelection.contains(index)
                            ? '${_storySelection.indexOf(index) + 1}'
                            : '•'),
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Text(_storyEvents[index], textAlign: TextAlign.right)),
                    ],
                  ),
                ),
              ),
            Text('اختر الخطوات بالترتيب الصحيح. (${_storySelection.length}/${_storyEvents.length})', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _MiniGameBanner extends StatelessWidget {
  const _MiniGameBanner({required this.name, required this.age});
  final String name;
  final int age;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [Color(0xFF126F75), Color(0xFF7185D8)]),
        ),
        child: Row(
          children: [
            const Text('🧩', style: TextStyle(fontSize: 42)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('يا $name، هيا نكتشف!', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 19)),
                Text('ألعاب تفكير وملاحظة • العمر $age سنة', style: const TextStyle(color: Colors.white, height: 1.5)),
              ]),
            ),
          ],
        ),
      );
}

class _PictureRow extends StatelessWidget {
  const _PictureRow({required this.items, required this.found, required this.onTap});
  final List<String> items;
  final Set<int> found;
  final ValueChanged<int>? onTap;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          for (var i = 0; i < items.length; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 5),
                child: InkWell(
                  onTap: onTap == null ? null : () => onTap!(i),
                  borderRadius: BorderRadius.circular(12),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    height: 58,
                    decoration: BoxDecoration(
                      color: found.contains(i) ? const Color(0xFFDDF4E9) : const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: found.contains(i) ? const Color(0xFF26956F) : const Color(0xFFE2E8F0), width: found.contains(i) ? 2 : 1),
                    ),
                    alignment: Alignment.center,
                    child: Text(items[i], style: const TextStyle(fontSize: 25)),
                  ),
                ),
              ),
            ),
        ],
      );
}

class _MazeControls extends StatelessWidget {
  const _MazeControls({required this.onMove, required this.position});
  final ValueChanged<int> onMove;
  final int position;

  @override
  Widget build(BuildContext context) {
    const columns = 5;
    final row = position ~/ columns;
    final col = position % columns;
    return Column(
      children: [
        IconButton.filledTonal(onPressed: row > 0 ? () => onMove(position - columns) : null, icon: const Icon(Icons.keyboard_arrow_up_rounded)),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton.filledTonal(onPressed: col > 0 ? () => onMove(position - 1) : null, icon: const Icon(Icons.keyboard_arrow_right_rounded)),
            const SizedBox(width: 36),
            IconButton.filledTonal(onPressed: col < 4 ? () => onMove(position + 1) : null, icon: const Icon(Icons.keyboard_arrow_left_rounded)),
          ],
        ),
        IconButton.filledTonal(onPressed: row < 4 ? () => onMove(position + columns) : null, icon: const Icon(Icons.keyboard_arrow_down_rounded)),
      ],
    );
  }
}
