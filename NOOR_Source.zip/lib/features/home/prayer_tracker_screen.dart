import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';

class PrayerTrackerScreen extends ConsumerStatefulWidget {
  const PrayerTrackerScreen({super.key});
  @override
  ConsumerState<PrayerTrackerScreen> createState() =>
      _PrayerTrackerScreenState();
}

class _PrayerTrackerScreenState extends ConsumerState<PrayerTrackerScreen> {
  static const prayers = [
    ('fajr', 'الفجر', '🌅'),
    ('dhuhr', 'الظهر', '☀️'),
    ('asr', 'العصر', '🌤️'),
    ('maghrib', 'المغرب', '🌇'),
    ('isha', 'العشاء', '🌙')
  ];
  late final String day = DateTime.now().toIso8601String().substring(0, 10);
  Set<String> done = {};
  bool loaded = false;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final child = await ref.read(selectedChildProvider.future);
    if (child == null) return;
    final result =
        await ref.read(childRepositoryProvider).prayersForDay(child.id, day);
    if (mounted)
      setState(() {
        done = result;
        loaded = true;
      });
  }

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider).valueOrNull;
    return Scaffold(
        appBar: AppBar(title: const Text('متتبع صلاتي')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-space.webp',
            motif: '🕌',
            child: child == null
                ? const Center(child: Text('اختر ملف المتعلم أولًا'))
                : !loaded
                    ? const Center(child: CircularProgressIndicator())
                    : ListView(padding: const EdgeInsets.all(18), children: [
                        Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(26),
                                gradient: const LinearGradient(colors: [
                                  Color(0xFF174B65),
                                  Color(0xFF15998D)
                                ])),
                            child: Column(children: [
                              Text(child.avatar,
                                  style: const TextStyle(fontSize: 42)),
                              Text('خطوة جميلة يا ${child.name}',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 20)),
                              const SizedBox(height: 6),
                              Text('${done.length} من 5 صلوات مسجلة اليوم',
                                  style: const TextStyle(color: Colors.white)),
                              const SizedBox(height: 12),
                              ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: LinearProgressIndicator(
                                      value: done.length / 5,
                                      minHeight: 10,
                                      backgroundColor: Colors.white24,
                                      color: const Color(0xFFFFD36C)))
                            ])),
                        const SizedBox(height: 16),
                        const Text('علّم الصلاة بعد أدائها',
                            style: TextStyle(
                                fontWeight: FontWeight.w900, fontSize: 18)),
                        const SizedBox(height: 8),
                        for (final item in prayers)
                          Card(
                              child: CheckboxListTile(
                                  value: done.contains(item.$1),
                                  onChanged: (value) async {
                                    final next = value == true;
                                    await ref
                                        .read(childRepositoryProvider)
                                        .setPrayerDone(
                                            child.id, day, item.$1, next);
                                    if (mounted)
                                      setState(() {
                                        if (next) {
                                          done.add(item.$1);
                                        } else {
                                          done.remove(item.$1);
                                        }
                                      });
                                  },
                                  secondary: Text(item.$3,
                                      style: const TextStyle(fontSize: 28)),
                                  title: Text(item.$2,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w800)),
                                  subtitle: Text(done.contains(item.$1)
                                      ? 'تم تسجيلها اليوم'
                                      : 'لم تُسجل بعد'))),
                        const SizedBox(height: 10),
                        const Card(
                            child: Padding(
                                padding: EdgeInsets.all(14),
                                child: Text(
                                    'هذا المتتبع للتشجيع والتنظيم فقط، ولا يحكم على الطفل أو يستبدل توجيه الأسرة.'))),
                      ])));
  }
}
