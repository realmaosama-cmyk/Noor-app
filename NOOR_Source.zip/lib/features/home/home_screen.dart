import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/noor_brand.dart';
import 'adventure_map.dart';
import '../../data/providers.dart';
import '../../data/content/catalog.dart';
import '../../data/content/daily_content.dart';
import '../../data/content/learning_domains.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    final states = ref.watch(sectionStatesProvider);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            tooltip: 'تبديل المستخدم',
            icon: const Icon(Icons.swap_horiz_rounded),
            onPressed: () => context.go('/')),
        title: const NoorBrand(compact: true),
        actions: [
          IconButton(
            tooltip: 'مكتبة نور',
            onPressed: () => context.push('/legacy-content'),
            icon: const Icon(Icons.auto_awesome_rounded),
          ),
          IconButton(
              tooltip: 'المكتبة',
              onPressed: () => context.push('/library'),
              icon: const Icon(Icons.auto_stories_rounded)),
          IconButton(
              tooltip: 'ملفي',
              onPressed: () => context.push('/profile'),
              icon: const Icon(Icons.face_rounded)),
          const SizedBox(width: 5),
        ],
      ),
      body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFF2FAF8),
                    Color(0xFFF7F7FF),
                    Color(0xFFFFFAF2)
                  ]),
              image: DecorationImage(
                  image: AssetImage('assets/branding/noor-bg-forest.webp'),
                  fit: BoxFit.cover,
                  colorFilter:
                      ColorFilter.mode(Color(0xEAF7FBF9), BlendMode.srcOver))),
          child: child.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) =>
                const Center(child: Text('حدث خطأ، حاول مرة أخرى')),
            data: (c) {
              if (c == null)
                return Center(
                    child: FilledButton(
                        onPressed: () => context.go('/'),
                        child: const Text('اختيار المتعلم')));
              final enabled = states.valueOrNull ?? const <String, bool>{};
              final visible = sectionsForChild(c)
                  .where((s) => enabled[s.id] ?? true)
                  .toList();
              final totalLessons = visible.fold<int>(
                  0, (sum, section) => sum + lessonsForAge(section, c).length);
              final visibleLessonIds = visible
                  .expand((section) => lessonsForAge(section, c))
                  .map((lesson) => lesson.id)
                  .toList(growable: false);
              return FutureBuilder<int>(
                future: ref.read(childRepositoryProvider)
                    .masteredLessonsInSection(c.id, visibleLessonIds),
                builder: (context, masterySnapshot) {
                  final mastered = masterySnapshot.data ?? 0;
                  final progress = totalLessons == 0
                      ? 0.0
                      : (mastered / totalLessons).clamp(0.0, 1.0).toDouble();
                  return SafeArea(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                  children: [
                    NoorEntrance(
                        delay: 0,
                        child: _HeroCard(
                            name: c.name,
                            ageLabel: c.ageLabel,
                            avatar: c.avatar,
                            points: c.points,
                            level: c.level,
                            stars: c.stars,
                            progress: progress)),
                    const SizedBox(height: 14),
                    NoorEntrance(
                        delay: 1,
                        child: _DailyWisdomCard(wisdom: wisdomForToday())),
                    if (c.interests.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: c.interests
                                  .take(4)
                                  .map((v) => Chip(
                                      visualDensity: VisualDensity.compact,
                                      backgroundColor: Colors.white,
                                      avatar: const Icon(Icons.favorite_rounded,
                                          size: 14, color: AppColors.coral),
                                      label: Text(v,
                                          style: const TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700))))
                                  .toList()))
                    ],
                    const SizedBox(height: 20),
                    NoorEntrance(
                        delay: 1,
                        child: Row(children: [
                          Expanded(
                              child: Text('اختر طريق رحلتك',
                                  style:
                                      Theme.of(context).textTheme.titleLarge)),
                          Text('${visible.length} مجالًا',
                              style: const TextStyle(
                                  color: AppColors.teal,
                                  fontWeight: FontWeight.w800)),
                        ])),
                    const SizedBox(height: 12),
                    NoorEntrance(
                      delay: 2,
                      child: NoorAdventureMap(
                        domains: noorLearningDomains,
                        sectionCounts: {
                          for (final domain in noorLearningDomains)
                            domain.id: domain.sections(visible).length,
                        },
                        lessonCounts: {
                          for (final domain in noorLearningDomains)
                            domain.id: domain.sections(visible).fold<int>(
                                  0,
                                  (sum, section) =>
                                      sum + lessonsForAge(section, c).length,
                                ),
                        },
                        onOpen: (id) => context.push('/domain/$id'),
                      ),
                    ),
                    NoorEntrance(
                        delay: 5,
                        child: _MissionCard(
                            onTap: () => context.push('/missions'))),
                    const SizedBox(height: 12),
                    NoorEntrance(
                        delay: 6,
                        child: Row(children: [
                          Expanded(
                              child: _QuickAction(
                                  icon: Icons.emoji_events_rounded,
                                  title: 'إنجازاتي',
                                  subtitle: 'شاراتك ومستواك',
                                  color: const Color(0xFFFFF0CB),
                                  onTap: () =>
                                      context.push('/section/achievements'))),
                          const SizedBox(width: 10),
                          Expanded(
                              child: _QuickAction(
                                  icon: Icons.card_giftcard_rounded,
                                  title: 'متجر النجوم',
                                  subtitle: 'افتح شخصيات',
                                  color: const Color(0xFFECEBFF),
                                  onTap: () => context.push('/rewards'))),
                        ])),
                    const SizedBox(height: 18),
                    Text('مناطق جديدة للاستكشاف',
                        style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 10),
                    GridView.count(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisCount: 2,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 1.35,
                        children: [
                          _QuickAction(
                              icon: Icons.flag_rounded,
                              title: 'مهامي اليومية',
                              subtitle: 'تحديات ومكافآت',
                              color: const Color(0xFFFFF0CB),
                              onTap: () => context.push('/missions')),
                          _QuickAction(
                              icon: Icons.sports_esports_rounded,
                              title: 'ملعب الألعاب',
                              subtitle: 'تحديات حسب عمرك',
                              color: const Color(0xFFE4F5F1),
                              onTap: () => context.push('/games')),
                          _QuickAction(
                              icon: Icons.auto_stories_rounded,
                              title: 'قصص تفاعلية',
                              subtitle: 'اختر مسارك',
                              color: const Color(0xFFFFE9E2),
                              onTap: () => context.push('/stories')),
                          _QuickAction(
                              icon: Icons.palette_rounded,
                              title: 'استوديو الإبداع',
                              subtitle: 'ارسم وابتكر',
                              color: const Color(0xFFECEBFF),
                              onTap: () => context.push('/studio')),
                          _QuickAction(
                              icon: Icons.science_rounded,
                              title: 'مختبر الاكتشاف',
                              subtitle: 'جرّب وتعلّم',
                              color: const Color(0xFFFFF0CB),
                              onTap: () => context.push('/lab')),
                          _QuickAction(
                              icon: Icons.lightbulb_rounded,
                              title: 'مرشد نور',
                              subtitle: 'تلميحات ذكية',
                              color: const Color(0xFFE4F0FF),
                              onTap: () => context.push('/guide')),
                          _QuickAction(
                              icon: Icons.family_restroom_rounded,
                              title: 'منطقة الأسرة',
                              subtitle: 'متابعة وتوجيه',
                              color: const Color(0xFFFCE8F2),
                              onTap: () => context.push('/parent')),
                          _QuickAction(
                              icon: Icons.check_circle_rounded,
                              title: 'متتبع صلاتي',
                              subtitle: 'سجل صلوات اليوم',
                              color: const Color(0xFFE4F5F1),
                              onTap: () => context.push('/prayer-tracker')),
                          _QuickAction(
                              icon: Icons.headphones_rounded,
                              title: 'تلاوة القرآن',
                              subtitle: 'استمع آية بآية',
                              color: const Color(0xFFECEBFF),
                              onTap: () => context.push('/quran-recitation')),
                        ]),
                  ],
                ),
                  );
                },
              );
            },
          )),
    );
  }
}

class _DailyWisdomCard extends StatelessWidget {
  const _DailyWisdomCard({required this.wisdom});
  final DailyWisdom wisdom;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [Color(0xFFFFF3D8), Color(0xFFFFE8E2)]),
            border: Border.all(
                color: const Color(0xFFE8C88B).withValues(alpha: .45))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.auto_awesome_rounded, color: Color(0xFFB47A22)),
            SizedBox(width: 7),
            Text('نور اليوم • آية وحديث',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))
          ]),
          const SizedBox(height: 12),
          Text(wisdom.ayah,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 23,
                  height: 1.8,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF17465B))),
          Align(
              alignment: Alignment.centerLeft,
              child: Text(wisdom.ayahRef,
                  style:
                      const TextStyle(fontSize: 11, color: Colors.blueGrey))),
          const Divider(height: 20),
          const Text('قال رسول الله ﷺ',
              style: TextStyle(
                  fontWeight: FontWeight.w900, color: Color(0xFF0B827A))),
          const SizedBox(height: 5),
          Text(wisdom.hadith,
              style: const TextStyle(
                  fontSize: 15, height: 1.6, fontWeight: FontWeight.w700)),
          Align(
              alignment: Alignment.centerLeft,
              child: Text(wisdom.hadithRef,
                  style:
                      const TextStyle(fontSize: 11, color: Colors.blueGrey))),
          const SizedBox(height: 8),
          Text('💡 ${wisdom.reflection}',
              style: const TextStyle(fontSize: 12, height: 1.5)),
        ]),
      );
}

class _HeroCard extends StatelessWidget {
  const _HeroCard(
      {required this.name,
      required this.ageLabel,
      required this.avatar,
      required this.points,
      required this.level,
      required this.stars,
      required this.progress});
  final String name, ageLabel, avatar;
  final int points, level, stars;
  final double progress;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color(0xFF145B70),
                Color(0xFF0D9B91),
                Color(0xFF54B9A4)
              ]),
          boxShadow: [
            BoxShadow(
                color: AppColors.teal.withValues(alpha: .22),
                blurRadius: 22,
                offset: const Offset(0, 10))
          ],
        ),
        child: Stack(children: [
          Positioned(
              left: -12,
              top: -20,
              child: Icon(Icons.auto_awesome,
                  size: 94, color: Colors.white.withValues(alpha: .08))),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(
                  radius: 29,
                  backgroundColor: Colors.white.withValues(alpha: .2),
                  child: Text(avatar, style: const TextStyle(fontSize: 31))),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text('أهلًا يا $name! 👋',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 21,
                            fontWeight: FontWeight.w900)),
                    Text('$ageLabel • مستكشف نور',
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: .82),
                            fontWeight: FontWeight.w600)),
                  ])),
              const Icon(Icons.waving_hand_rounded,
                  color: AppColors.gold, size: 28),
            ]),
            const SizedBox(height: 20),
            Row(children: [
              _StatPill(icon: Icons.star_rounded, value: '$stars نجمة'),
              const SizedBox(width: 8),
              _StatPill(icon: Icons.bolt_rounded, value: '$points نقطة'),
              const SizedBox(width: 8),
              _StatPill(
                  icon: Icons.military_tech_rounded, value: 'مستوى $level'),
            ]),
            const SizedBox(height: 16),
            Row(children: [
              const Expanded(
                  child: Text('تقدمك في الرحلة',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w700))),
              Text('${(progress * 100).round()}%',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w900))
            ]),
            const SizedBox(height: 8),
            ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 10,
                    backgroundColor: Colors.white.withValues(alpha: .22),
                    color: AppColors.gold)),
          ]),
        ]),
      );
}

class _StatPill extends StatelessWidget {
  const _StatPill({required this.icon, required this.value});
  final IconData icon;
  final String value;
  @override
  Widget build(BuildContext context) => Expanded(
      child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 7),
          decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(14)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: AppColors.gold, size: 16),
            const SizedBox(width: 4),
            Flexible(
                child: Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w800)))
          ])));
}

class _LearningDomainCard extends StatelessWidget {
  const _LearningDomainCard(
      {required this.title,
      required this.subtitle,
      required this.emoji,
      required this.sectionsCount,
      required this.lessonsCount,
      required this.color,
      required this.onTap});
  final String title, subtitle, emoji;
  final int sectionsCount, lessonsCount;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white.withValues(alpha: .96),
        borderRadius: BorderRadius.circular(25),
        child: InkWell(
          borderRadius: BorderRadius.circular(25),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: color.withValues(alpha: .20)),
                boxShadow: [
                  BoxShadow(
                      color: color.withValues(alpha: .07),
                      blurRadius: 16,
                      offset: const Offset(0, 6))
                ]),
            child: Row(children: [
              Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                      color: color.withValues(alpha: .12),
                      borderRadius: BorderRadius.circular(20)),
                  alignment: Alignment.center,
                  child: Text(emoji, style: const TextStyle(fontSize: 34))),
              const SizedBox(width: 15),
              Expanded(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: AppColors.ink)),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 11,
                            color: AppColors.ink.withValues(alpha: .68))),
                    const SizedBox(height: 7),
                    Text('$sectionsCount مجال • $lessonsCount درس',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: color)),
                  ])),
              Icon(Icons.arrow_forward_ios_rounded, size: 18, color: color),
            ]),
          ),
        ),
      );
}

class _MissionCard extends StatelessWidget {
  const _MissionCard({required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
        color: const Color(0xFFFFF1D5),
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: onTap,
            child: Padding(
                padding: const EdgeInsets.all(17),
                child: Row(children: [
                  Container(
                      width: 51,
                      height: 51,
                      decoration: BoxDecoration(
                          color: AppColors.gold.withValues(alpha: .35),
                          borderRadius: BorderRadius.circular(17)),
                      child: const Icon(Icons.flag_rounded,
                          color: Color(0xFFAD7620), size: 29)),
                  const SizedBox(width: 13),
                  const Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        Text('مهام اليوم والأسبوع',
                            style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 17,
                                color: AppColors.ink)),
                        SizedBox(height: 3),
                        Text('تحديات متجددة ومكافآت على تقدمك',
                            style:
                                TextStyle(fontSize: 12, color: AppColors.ink))
                      ])),
                  const Icon(Icons.chevron_left_rounded, color: AppColors.ink),
                ]))),
      );
}

class _QuickAction extends StatelessWidget {
  const _QuickAction(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.color,
      required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: color.withValues(alpha: .38)),
                  boxShadow: [
                    BoxShadow(
                        color: color.withValues(alpha: .12),
                        blurRadius: 14,
                        offset: const Offset(0, 5))
                  ]),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(14)),
                        child: Icon(icon, color: AppColors.ink)),
                    const SizedBox(height: 8),
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, color: AppColors.ink)),
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 11,
                            color: AppColors.ink.withValues(alpha: .62)))
                  ]))));
}
