import 'dart:math';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';
import '../../data/repositories/missions_repository.dart';
import '../../core/services/noor_sound_service.dart';

class NoorLetterBuilderGameScreen extends ConsumerStatefulWidget {
  const NoorLetterBuilderGameScreen({super.key});
  @override
  ConsumerState<NoorLetterBuilderGameScreen> createState() =>
      _NoorLetterBuilderGameScreenState();
}

class _NoorLetterBuilderGameScreenState
    extends ConsumerState<NoorLetterBuilderGameScreen> {
  static const words = [
    ('نور', 'ضوء يبدد الظلام'),
    ('قمر', 'نراه مضيئًا في السماء ليلًا'),
    ('كتاب', 'نقرأ ونتعلم منه'),
    ('مسجد', 'مكان الصلاة'),
    ('سلام', 'تحية طيبة ودعاء بالأمان')
  ];
  int round = 0;
  late List<String> tiles;
  final List<int> selected = [];
  bool checked = false;
  int score = 0;
  @override
  void initState() {
    super.initState();
    _prepare();
  }

  String get target => words[round % words.length].$1;
  String get hint => words[round % words.length].$2;
  void _prepare() {
    tiles = target.split('')..shuffle(Random());
    selected.clear();
    checked = false;
  }

  Future<void> _check() async {
    if (selected.length != target.length) return;
    final answer = selected.map((i) => tiles[i]).join();
    if (answer == target) {
      setState(() {
        checked = true;
        score += 10;
      });
      final child = await ref.read(selectedChildProvider.future);
      if (child != null) {
        await ref
            .read(childRepositoryProvider)
            .addReward(child.id, points: 10, stars: 1);
        await NoorMissionsRepository().recordEvent(child.id, 'game');
        await NoorSoundService.playEffect('correct.wav');
        ref.invalidate(selectedChildProvider);
        ref.invalidate(childrenProvider);
      }
    } else {
      setState(() {
        checked = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('تركيب الحروف')),
      body: NoorPageBackground(
          asset: 'assets/branding/noor-bg-forest.webp',
          motif: '🔤',
          child: ListView(padding: const EdgeInsets.all(18), children: [
            Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: const LinearGradient(
                        colors: [Color(0xFF126D76), Color(0xFF52A98D)])),
                child: Column(children: [
                  const Text('رتّب الحروف لتكوين الكلمة',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text('تحدي ${round + 1} • ⭐ $score نقطة',
                      style: const TextStyle(color: Colors.white70))
                ])),
            const SizedBox(height: 20),
            Card(
                child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(children: [
                      const Text('تلميح',
                          style: TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      Text(hint,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 17)),
                      const SizedBox(height: 18),
                      Wrap(
                          alignment: WrapAlignment.center,
                          spacing: 8,
                          children: [
                            for (var i = 0; i < selected.length; i++)
                              Chip(
                                  label: Text(tiles[selected[i]],
                                      style: const TextStyle(
                                          fontSize: 24,
                                          fontWeight: FontWeight.w900)),
                                  onDeleted: checked
                                      ? null
                                      : () =>
                                          setState(() => selected.removeAt(i)))
                          ]),
                      const SizedBox(height: 14),
                      Wrap(
                          alignment: WrapAlignment.center,
                          spacing: 10,
                          runSpacing: 10,
                          children: [
                            for (var i = 0; i < tiles.length; i++)
                              if (!selected.contains(i))
                                ActionChip(
                                    label: Text(tiles[i],
                                        style: const TextStyle(
                                            fontSize: 26,
                                            fontWeight: FontWeight.w900)),
                                    onPressed: checked
                                        ? null
                                        : () => setState(() => selected.add(i)))
                          ]),
                      if (checked)
                        Padding(
                            padding: const EdgeInsets.only(top: 14),
                            child: Text(
                                selected.map((i) => tiles[i]).join() == target
                                    ? 'أحسنت! الكلمة صحيحة 🎉'
                                    : 'محاولة جميلة. الكلمة الصحيحة: $target',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF0D8A7E))))
                    ]))),
            const SizedBox(height: 12),
            if (!checked)
              FilledButton(
                  onPressed: selected.length == target.length ? _check : null,
                  child: const Text('تحقق من الكلمة'))
            else
              FilledButton.icon(
                  onPressed: () => setState(() {
                        round++;
                        _prepare();
                      }),
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: const Text('الكلمة التالية')),
          ])));
}
