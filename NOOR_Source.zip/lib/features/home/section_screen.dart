import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/content/catalog.dart';
import '../../data/content/legacy_content.dart';
import '../../data/providers.dart';
import '../../data/models/child.dart';
import '../../data/repositories/mastery_rules.dart';
import '../../data/repositories/child_repository.dart';
import '../../core/widgets/noor_brand.dart';
import '../../core/services/noor_voice.dart';
import '../../core/services/noor_sound_service.dart';
import 'quran_library_screen.dart';

class SectionScreen extends ConsumerWidget {
  const SectionScreen({super.key, required this.sectionId});
  final String sectionId;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    if (sectionId == 'achievements') return const _AchievementsScreen();
    final section = sectionById(sectionId);
    if (section == null)
      return const Scaffold(body: Center(child: Text('القسم غير موجود')));
    final art = switch (section.id) {
      'quran' ||
      'prophets' ||
      'figures' =>
        'assets/branding/noor-bg-forest.webp',
      'prayer' => 'assets/branding/noor-bg-1.jpg',
      'adhkar' || 'challenges' => 'assets/branding/noor-bg-space.webp',
      'akhlaq' || 'seerah' => 'assets/branding/noor-bg-2.jpg',
      'learn' => 'assets/branding/noor-bg-3.jpg',
      'space' ||
      'science' ||
      'coding' ||
      'future' ||
      'engineering' =>
        'assets/branding/noor-bg-space.webp',
      'animals' ||
      'nature' ||
      'sports' ||
      'cooking' =>
        'assets/branding/noor-bg-forest.webp',
      _ => 'assets/branding/noor-bg-ocean.webp',
    };
    final motif = switch (section.id) {
      'quran' => '۞',
      'prayer' => '🕌',
      'adhkar' => '🌙',
      'akhlaq' => '💚',
      'seerah' => '🌟',
      'figures' => '⭐',
      'prophets' => '🌿',
      _ => section.emoji
    };
    return Scaffold(
        appBar: AppBar(title: Text(section.title)),
        body: NoorPageBackground(
            asset: art,
            motif: motif,
            child: child.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => const Center(child: Text('تعذر تحميل الملف')),
                data: (c) {
                  if (c == null)
                    return const Center(child: Text('اختر مستخدمًا أولًا'));
                  final lessons = lessonsForAge(section, c);
                  return ListView(padding: const EdgeInsets.all(16), children: [
                    Text(section.description,
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    if (section.id == 'quran') ...[
                      Card(
                        clipBehavior: Clip.antiAlias,
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.menu_book_rounded),
                          ),
                          title: const Text('المصحف الشريف كاملًا'),
                          subtitle: const Text(
                              '114 سورة • 6,236 آية • بحث وفهرس كامل',
                            ),
                          trailing: const Icon(Icons.chevron_left_rounded),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const QuranLibraryScreen(),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                    ],
                    if (lessons.isEmpty)
                      const Card(
                          child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Text(
                                  'لا يوجد محتوى مناسب لهذه المرحلة حاليًا.'))),
                    FutureBuilder<int>(
                      future: ref.read(childRepositoryProvider).masteredLessonsInSection(
                        c.id, lessons.map((lesson) => lesson.id).toList(growable: false)),
                      builder: (context, progressSnapshot) {
                        final mastered = progressSnapshot.data ?? 0;
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                const Icon(Icons.flag_rounded, color: Colors.teal),
                                const SizedBox(width: 8),
                                const Expanded(child: Text('تقدم الإتقان', style: TextStyle(fontWeight: FontWeight.w900))),
                                Text('$mastered / ${lessons.length}')
                              ]),
                              const SizedBox(height: 9),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(20),
                                child: LinearProgressIndicator(
                                  value: lessons.isEmpty ? 0 : mastered / lessons.length,
                                  minHeight: 8,
                                ),
                              ),
                              const SizedBox(height: 6),
                              const Text('أتقن 80٪ على الأقل من اختبار الدرس لفتح الدرس التالي. يمكنك إعادة المحاولة دون خسارة نقاط.',
                                style: TextStyle(fontSize: 12, height: 1.45)),
                            ]),
                          ),
                        );
                      },
                    ),
                    for (var lessonIndex = 0; lessonIndex < lessons.length; lessonIndex++)
                      FutureBuilder<bool>(
                        future: lessonIndex == 0
                            ? Future<bool>.value(true)
                            : ref.read(childRepositoryProvider).isMastered(c.id, lessons[lessonIndex - 1].id),
                        builder: (ctx, unlockSnapshot) {
                          final unlocked = MasteryRules.isUnlocked(lessonIndex, previousMastered: unlockSnapshot.data ?? false);
                          final lesson = lessons[lessonIndex];
                          return FutureBuilder<bool>(
                            future: ref.read(childRepositoryProvider).isCompleted(c.id, lesson.id),
                            builder: (ctx, completionSnapshot) {
                              final done = completionSnapshot.data ?? false;
                              return FutureBuilder<bool>(
                                future: ref.read(childRepositoryProvider).isMastered(c.id, lesson.id),
                                builder: (ctx, masterySnapshot) {
                                  final mastered = masterySnapshot.data ?? false;
                                  return Card(
                                    child: ListTile(
                                      leading: CircleAvatar(
                                        child: Icon(!unlocked
                                            ? Icons.lock_rounded
                                            : mastered ? Icons.verified_rounded
                                            : done ? Icons.refresh_rounded : Icons.menu_book_rounded),
                                      ),
                                      title: Text(lesson.title),
                                      subtitle: Text(!unlocked
                                          ? 'مغلق مؤقتًا • أتقن الدرس السابق أولًا'
                                          : done && !mastered
                                              ? '${lesson.summary} • أعد المحاولة للوصول إلى 80٪'
                                              : done ? '${lesson.summary} • يمكنك إعادة التدريب' : lesson.summary),
                                      trailing: Icon(
                                        !unlocked ? Icons.lock_outline_rounded
                                            : mastered ? Icons.verified
                                            : Icons.chevron_left,
                                        color: mastered ? Colors.green : null,
                                      ),
                                      onTap: () {
                                        if (!unlocked) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(content: Text('أكمل إتقان الدرس السابق بنسبة 80٪ لفتح هذه المرحلة.')),
                                          );
                                          return;
                                        }
                                        showModalBottomSheet<void>(
                                          context: context,
                                          isScrollControlled: true,
                                          builder: (_) => _LessonSheet(lesson: lesson, child: c),
                                        );
                                      },
                                    ),
                                  );
                                },
                              );
                            },
                          );
                        },
                      ),
                    FutureBuilder<List<LegacyContentItem>>(
                      future: LegacyContentRepository.loadForSection(
                          section.id, c.age),
                      builder: (context, snapshot) {
                        final legacy = snapshot.data ?? const <LegacyContentItem>[];
                        final knownTitles = lessons
                            .map((lesson) => _legacyTitleKey(lesson.title))
                            .toSet();
                        final additional = legacy
                            .where((item) =>
                                !knownTitles.contains(_legacyTitleKey(item.title)))
                            .toList(growable: false);
                        if (snapshot.connectionState == ConnectionState.waiting &&
                            additional.isEmpty) {
                          return const Padding(
                            padding: EdgeInsets.all(18),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        if (additional.isEmpty) return const SizedBox.shrink();
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const SizedBox(height: 18),
                            Text(
                              'مكتبة نور الإضافية',
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            const SizedBox(height: 8),
                            for (final item in additional)
                              Card(
                                child: ListTile(
                                  leading: CircleAvatar(
                                    child: Text(item.emoji,
                                        style: const TextStyle(fontSize: 20)),
                                  ),
                                  title: Text(item.title),
                                  subtitle: Text(item.summary,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis),
                                  trailing: const Icon(Icons.chevron_left_rounded),
                                  onTap: () => showModalBottomSheet<void>(
                                    context: context,
                                    isScrollControlled: true,
                                    builder: (_) =>
                                        _LegacyLessonSheet(item: item, childId: c.id),
                                  ),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                  ]);
                })));
  }
}

class _LessonSheet extends ConsumerStatefulWidget {
  const _LessonSheet({required this.lesson, required this.child});
  final NoorLesson lesson;
  final Child child;
  @override
  ConsumerState<_LessonSheet> createState() => _LessonSheetState();
}

class _LessonSheetState extends ConsumerState<_LessonSheet> {
  int question = 0;
  int? selected;
  int correct = 0;
  bool finished = false;
  bool saved = false;
  bool bookmarkLoaded = false;
  @override
  void initState() {
    super.initState();
    _loadBookmark();
  }

  Future<void> _loadBookmark() async {
    final value = await ref
        .read(childRepositoryProvider)
        .isBookmarked(widget.child.id, widget.lesson.id);
    if (mounted)
      setState(() {
        saved = value;
        bookmarkLoaded = true;
      });
  }

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;
    final repo = ref.read(childRepositoryProvider);
    return SafeArea(
        child: Padding(
            padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20),
            child: SingleChildScrollView(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                  Row(children: [
                    Expanded(
                        child: Text(lesson.title,
                            style: Theme.of(context).textTheme.titleLarge)),
                    IconButton(
                        tooltip: 'استمع للدرس',
                        onPressed: () => NoorVoice.speak(
                            '${lesson.title}. ${_lessonBodyFor(widget.child, lesson)}'),
                        icon: const Icon(Icons.volume_up_rounded)),
                    IconButton(
                        onPressed: !bookmarkLoaded
                            ? null
                            : () async {
                                await repo.toggleBookmark(
                                    widget.child.id, lesson.id);
                                if (mounted) setState(() => saved = !saved);
                              },
                        icon: Icon(
                            saved ? Icons.bookmark : Icons.bookmark_border))
                  ]),
                  const SizedBox(height: 10),
                  Text(_lessonBodyFor(widget.child, lesson),
                      style: const TextStyle(fontSize: 17, height: 1.7)),
                  const SizedBox(height: 10),
                  Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(12)),
                      child: Text('المصدر: ${lesson.source}',
                          style: const TextStyle(fontSize: 12))),
                  const SizedBox(height: 20),
                  if (!finished) ...[
                    Text(
                        'اختبر فهمك • السؤال ${question + 1} من ${lesson.questions.length}',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 10),
                    Text(lesson.questions[question].prompt,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    for (var i = 0;
                        i < lesson.questions[question].options.length;
                        i++)
                      Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: OutlinedButton(
                              onPressed: selected == null
                                  ? () {
                                      final isCorrect = i ==
                                          lesson.questions[question].answer;
                                      NoorSoundService.playEffect(
                                          isCorrect ? 'correct.wav' : 'tap.wav');
                                      setState(() => selected = i);
                                    }
                                  : null,
                              style: OutlinedButton.styleFrom(
                                  backgroundColor: selected == i
                                      ? Theme.of(context)
                                          .colorScheme
                                          .primaryContainer
                                      : null),
                              child:
                                  Text(lesson.questions[question].options[i]))),
                    if (selected != null)
                      Text(
                          selected == lesson.questions[question].answer
                              ? 'إجابة صحيحة! ${lesson.questions[question].explanation}'
                              : 'حاول مرة أخرى. ${lesson.questions[question].explanation}',
                          style: TextStyle(
                              color:
                                  selected == lesson.questions[question].answer
                                      ? Colors.green
                                      : Colors.deepOrange)),
                    const SizedBox(height: 12),
                    FilledButton(
                        onPressed: selected == null
                            ? null
                            : () {
                                if (selected ==
                                    lesson.questions[question].answer)
                                  correct++;
                                if (question + 1 < lesson.questions.length) {
                                  setState(() {
                                    question++;
                                    selected = null;
                                  });
                                } else {
                                  NoorSoundService.playEffect('success.wav');
                                  setState(() => finished = true);
                                }
                              },
                        child: Text(question + 1 == lesson.questions.length
                            ? 'إنهاء الاختبار'
                            : 'السؤال التالي'))
                  ] else ...[
                    const Icon(Icons.emoji_events,
                        color: Color(0xFFD6A84F), size: 54),
                    Text('أحسنت يا ${widget.child.name}!',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleLarge),
                    Text('إجابات صحيحة: $correct من ${lesson.questions.length}',
                        textAlign: TextAlign.center),
                    FilledButton(
                        onPressed: () async {
                          final score =
                              (correct * 100 / lesson.questions.length).round();
                          final already = await repo.isCompleted(
                              widget.child.id, lesson.id);
                          final completedBefore =
                              await repo.completedLessons(widget.child.id);
                          await repo.completeLesson(
                              widget.child.id, lesson.id, score);
                          await repo.recordMasteryAttempt(
                              widget.child.id, lesson.id, score);
                          if (!already) {
                            await repo.addReward(widget.child.id,
                                points: score == 100 ? 30 : 15,
                                stars: score == 100 ? 2 : 1);
                            if (completedBefore == 0)
                              await repo.awardBadge(
                                  widget.child.id, 'first_lesson');
                            if (completedBefore == 4)
                              await repo.awardBadge(
                                  widget.child.id, 'five_lessons');
                            if (completedBefore == 9)
                              await repo.awardBadge(
                                  widget.child.id, 'ten_lessons');
                          }
                          ref.invalidate(selectedChildProvider);
                          ref.invalidate(childrenProvider);
                          if (context.mounted) Navigator.pop(context);
                        },
                        child: const Text('حفظ النتيجة والمتابعة'))
                  ]
                ]))));
  }
}

class _AchievementsScreen extends ConsumerWidget {
  const _AchievementsScreen();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = ref.watch(selectedChildProvider);
    return Scaffold(
        appBar: AppBar(title: const Text('إنجازاتي')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-ocean.webp',
            child: c.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => const SizedBox(),
                data: (child) {
                  if (child == null) return const SizedBox();
                  return FutureBuilder<Map<String, int>>(
                      future: ref
                          .read(childRepositoryProvider)
                          .progressSummary(child.id),
                      builder: (ctx, s) {
                        final summary =
                            s.data ?? {'completed': 0, 'average': 0};
                        return ListView(
                            padding: const EdgeInsets.all(20),
                            children: [
                              Card(
                                  child: Padding(
                                      padding: const EdgeInsets.all(22),
                                      child: Column(children: [
                                        Text(child.avatar,
                                            style:
                                                const TextStyle(fontSize: 52)),
                                        Text(child.name,
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleLarge),
                                        Text(
                                            'المستوى ${child.level} • ${child.points} نقطة • ${child.stars} نجمة')
                                      ]))),
                              _stat(context, 'الدروس المكتملة',
                                  '${summary['completed']}', Icons.menu_book),
                              _stat(context, 'متوسط نتائج الاختبارات',
                                  '${summary['average']}%', Icons.insights),
                              FutureBuilder<int>(
                                  future: ref
                                      .read(childRepositoryProvider)
                                      .badgeCount(child.id),
                                  builder: (ctx, b) => _stat(
                                      context,
                                      'الشارات المكتسبة',
                                      '${b.data ?? 0}',
                                      Icons.workspace_premium)),
                              const Card(
                                  child: Padding(
                                      padding: EdgeInsets.all(16),
                                      child: Text(
                                          'استمر في التعلم والمراجعة، فكل خطوة صغيرة تقربك من هدفك.')))
                            ]);
                      });
                })));
  }

  Widget _stat(BuildContext c, String title, String value, IconData icon) =>
      Card(
          child: ListTile(
              leading: Icon(icon),
              title: Text(title),
              trailing: Text(value, style: Theme.of(c).textTheme.titleLarge)));
}

String _lessonBodyFor(Child child, NoorLesson lesson) {
  final opening = lesson.body.split('.').first.trim();
  return switch (child.ageGroup) {
    AgeGroup.discovery => '${lesson.summary}. $opening.',
    AgeGroup.adventure => '${lesson.summary}.\n\n${lesson.body}',
    AgeGroup.challenge =>
      '${lesson.body}\n\nفكّر: كيف يمكن أن تطبّق ما تعلمته في حياتك اليومية؟',
    AgeGroup.independence =>
      '${lesson.body}\n\nسؤال للتأمل: ما الفكرة الأساسية؟ وكيف تشرحها لشخص آخر؟',
    AgeGroup.adult =>
      '${lesson.body}\n\nللتوسع: راجع المصدر المذكور، وتأمل في المعنى والسياق قبل استخلاص النتائج.',
  };
}


String _legacyTitleKey(String value) => value
    .trim()
    .toLowerCase()
    .replaceAll(RegExp(r'[ًٌٍَُِّْـ]'), '')
    .replaceAll(RegExp(r'\s+'), ' ');

int _legacyAnswerIndex(Map<String, dynamic> question,
    {List<String>? options}) {
  final rawOptions = question['options'];
  final normalizedOptions = options ?? (rawOptions is List
      ? rawOptions.map((value) {
          if (value is Map) {
            return (value['label'] ?? value['text'] ?? value['title'] ?? '').toString();
          }
          return value.toString();
        }).toList(growable: false)
      : const <String>[]);
  final rawAnswer = question['answerIndex'] ?? question['answer'];
  final parsed = rawAnswer is num ? rawAnswer.toInt() : int.tryParse('$rawAnswer');
  return parsed ?? (rawAnswer == null
      ? -1
      : normalizedOptions.indexOf(rawAnswer.toString()));
}

class _LegacyLessonSheet extends StatefulWidget {
  const _LegacyLessonSheet({required this.item, required this.childId});
  final LegacyContentItem item;
  final int childId;

  @override
  State<_LegacyLessonSheet> createState() => _LegacyLessonSheetState();
}

class _LegacyLessonSheetState extends State<_LegacyLessonSheet> {
  final Map<int, int> _answers = {};

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          18,
          20,
          MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Text(item.emoji, style: const TextStyle(fontSize: 28)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      item.title,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(item.body,
                  style: const TextStyle(fontSize: 16, height: 1.75)),
              if (item.steps.isNotEmpty) ...[
                const SizedBox(height: 14),
                const Text('خطوات ومعلومات',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                for (final step in item.steps)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.check_circle_outline_rounded),
                    title: Text(step),
                  ),
              ],
              if (item.questions.isNotEmpty) ...[
                const SizedBox(height: 14),
                const Text('اختبر فهمك',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                for (var i = 0; i < item.questions.length; i++)
                  _legacyQuestion(context, item.questions[i], i),
              ],
              if (item.source.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('المصدر: ${item.source}',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () async {
                  final questions = item.questions;
                  var allAnswered = true;
                  for (var i = 0; i < questions.length; i++) {
                    if (!_answers.containsKey(i)) allAnswered = false;
                  }
                  if (!allAnswered) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('أكمل أسئلة التدريب أولًا، ويمكنك المحاولة مرة أخرى.')),
                    );
                    return;
                  }
                  var correctCount = 0;
                  for (var i = 0; i < questions.length; i++) {
                    if (_answers[i] == _legacyAnswerIndex(questions[i])) correctCount++;
                  }
                  final score = questions.isEmpty
                      ? 100
                      : (correctCount * 100 / questions.length).round();
                  final repository = ChildRepository();
                  final already = await repository.isCompleted(widget.childId, item.id);
                  await repository.completeLesson(widget.childId, item.id, score);
                  await repository.recordMasteryAttempt(widget.childId, item.id, score);
                  if (!already) {
                    await repository.addReward(
                      widget.childId,
                      points: score >= 80 ? 20 : 10,
                      stars: score >= 80 ? 1 : 0,
                    );
                  }
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('تم حفظ تقدمك في ${item.title} • نتيجتك $score٪')),
                  );
                  Navigator.of(context).pop();
                },
                child: const Text('إنهاء وحفظ التقدم'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _legacyQuestion(
      BuildContext context, Map<String, dynamic> question, int index) {
    final prompt = question['question'] is String
        ? question['question'] as String
        : question['prompt']?.toString() ?? '';
    final rawOptions = question['options'];
    final options = rawOptions is List
        ? rawOptions.map((value) {
            if (value is Map) {
              return (value['label'] ?? value['text'] ?? value['title'] ?? '')
                  .toString();
            }
            return value.toString();
          }).toList(growable: false)
        : const <String>[];
    final answer = _legacyAnswerIndex(question, options: options);
    final selected = _answers[index];
    final correct = selected != null && selected == answer;

    return Card(
      margin: const EdgeInsets.only(top: 9),
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(prompt, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                for (var optionIndex = 0;
                    optionIndex < options.length;
                    optionIndex++)
                  ChoiceChip(
                    label: Text(options[optionIndex]),
                    selected: selected == optionIndex,
                    onSelected: (_) {
                      final isCorrect = optionIndex == answer;
                      NoorSoundService.playEffect(
                          isCorrect ? 'correct.wav' : 'tap.wav');
                      setState(() => _answers[index] = optionIndex);
                    },
                  ),
              ],
            ),
            if (selected != null)
              Padding(
                padding: const EdgeInsets.only(top: 7),
                child: Text(
                  correct
                      ? 'أحسنت! إجابة صحيحة 🌟'
                      : (question['hint']?.toString().isNotEmpty ?? false)
                          ? question['hint'].toString()
                          : 'حاول مرة أخرى، أنت تتعلم خطوة بخطوة.',
                  style: TextStyle(
                    color: correct ? Colors.green : Colors.blueGrey,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
