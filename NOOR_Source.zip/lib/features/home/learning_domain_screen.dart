import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/content/catalog.dart';
import '../../data/content/learning_domains.dart';
import '../../data/providers.dart';

class LearningDomainScreen extends ConsumerWidget {
  const LearningDomainScreen({super.key, required this.domainId});
  final String domainId;
  static const _palette = [
    AppColors.teal,
    AppColors.coral,
    AppColors.sky,
    Color(0xFF8B7CE8),
    Color(0xFFE8AE43),
    Color(0xFF68B78B)
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final domain = learningDomainById(domainId);
    if (domain == null)
      return const Scaffold(body: Center(child: Text('القسم غير موجود')));
    final childAsync = ref.watch(selectedChildProvider);
    final statesAsync = ref.watch(sectionStatesProvider);
    return Scaffold(
      appBar: AppBar(title: Text(domain.title), centerTitle: true),
      body: NoorPageBackground(
        asset: domainId == 'sharia'
            ? 'assets/branding/noor-bg-forest.webp'
            : 'assets/branding/noor-bg-space.webp',
        child: childAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const Center(child: Text('تعذر تحميل الملف')),
          data: (child) {
            if (child == null)
              return const Center(child: Text('اختَر ملف المتعلم أولًا'));
            final enabled = statesAsync.valueOrNull ?? const <String, bool>{};
            final sections = domain
                .sections(sectionsForChild(child))
                .where((section) => enabled[section.id] ?? true)
                .toList();
            final lessonsCount = sections.fold<int>(0,
                (sum, section) => sum + lessonsForAge(section, child).length);
            return ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
                children: [
                  Card(
                    color: Theme.of(context)
                        .colorScheme
                        .surface
                        .withValues(alpha: .94),
                    child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Row(children: [
                          Text(domain.emoji,
                              style: const TextStyle(fontSize: 42)),
                          const SizedBox(width: 14),
                          Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                Text(domain.title,
                                    style:
                                        Theme.of(context).textTheme.titleLarge),
                                const SizedBox(height: 5),
                                Text(domain.subtitle,
                                    style:
                                        Theme.of(context).textTheme.bodySmall),
                                const SizedBox(height: 8),
                                Text(
                                    '${sections.length} مجالات • $lessonsCount درسًا متاحًا',
                                    style: const TextStyle(
                                        color: AppColors.teal,
                                        fontWeight: FontWeight.w800)),
                              ])),
                        ])),
                  ),
                  const SizedBox(height: 14),
                  if (sections.isEmpty)
                    const Card(
                        child: Padding(
                            padding: EdgeInsets.all(20),
                            child: Text('لا توجد مجالات مفعّلة هنا حاليًا.')))
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: sections.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisSpacing: 12,
                              crossAxisSpacing: 12,
                              childAspectRatio: 1.12),
                      itemBuilder: (context, index) {
                        final section = sections[index];
                        final count = lessonsForAge(section, child).length;
                        final color = _palette[index % _palette.length];
                        return _DomainSectionCard(
                            section: section,
                            count: count,
                            color: color,
                            onTap: () =>
                                context.push('/section/${section.id}'));
                      },
                    ),
                ]);
          },
        ),
      ),
    );
  }
}

class _DomainSectionCard extends StatelessWidget {
  const _DomainSectionCard(
      {required this.section,
      required this.count,
      required this.color,
      required this.onTap});
  final NoorSection section;
  final int count;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        color: Theme.of(context).colorScheme.surface.withValues(alpha: .96),
        child: InkWell(
          onTap: onTap,
          child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      CircleAvatar(
                          radius: 23,
                          backgroundColor: color.withValues(alpha: .14),
                          child: Text(section.emoji,
                              style: const TextStyle(fontSize: 24))),
                      const Spacer(),
                      Icon(Icons.arrow_outward_rounded, color: color),
                    ]),
                    const Spacer(),
                    Text(section.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text('$count درس تعليمي',
                        style: Theme.of(context).textTheme.bodySmall),
                    const SizedBox(height: 8),
                    ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: LinearProgressIndicator(
                            value: 1,
                            minHeight: 5,
                            color: color.withValues(alpha: .55),
                            backgroundColor: color.withValues(alpha: .10))),
                  ])),
        ),
      );
}

class QuranHubScreen extends StatelessWidget {
  const QuranHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رحلتي مع القرآن'), centerTitle: true),
      body: NoorPageBackground(
        asset: 'assets/branding/noor-bg-forest.webp',
        motif: '۞',
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Text('📖', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 8),
                    Text('نور القرآن',
                        style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 6),
                    const Text('اقرأ، واستمع، وتعلّم خطوة بخطوة',
                        textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            _QuranHubTile(
              icon: Icons.menu_book_rounded,
              title: 'المصحف الشريف',
              subtitle: '114 سورة و6,236 آية مع البحث والترتيب',
              onTap: () => context.push('/quran-library'),
            ),
            _QuranHubTile(
              icon: Icons.headphones_rounded,
              title: 'التلاوة والاستماع',
              subtitle: 'استمع للتلاوة المتتابعة وتابع الآيات',
              onTap: () => context.push('/quran-recitation'),
            ),
            _QuranHubTile(
              icon: Icons.school_rounded,
              title: 'دروس قرآنية مبسطة',
              subtitle: 'دروس مناسبة للعمر وأسئلة لمراجعة الفهم',
              onTap: () => context.push('/section/quran'),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuranHubTile extends StatelessWidget {
  const _QuranHubTile(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          leading: CircleAvatar(child: Icon(icon)),
          title:
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_left_rounded),
          onTap: onTap,
        ),
      );
}
