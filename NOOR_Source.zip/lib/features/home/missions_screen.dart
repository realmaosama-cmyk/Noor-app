import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/noor_sound_service.dart';
import '../../data/providers.dart';
import '../../data/repositories/missions_repository.dart';

class NoorMissionsScreen extends ConsumerStatefulWidget {
  const NoorMissionsScreen({super.key});
  @override
  ConsumerState<NoorMissionsScreen> createState() => _NoorMissionsScreenState();
}

class _NoorMissionsScreenState extends ConsumerState<NoorMissionsScreen> {
  Future<List<NoorMission>>? _future;
  int? _childId;
  final _missions = NoorMissionsRepository();

  void _load(int childId) {
    if (_childId == childId && _future != null) return;
    _childId = childId;
    _future = _missions.loadCurrent(childId);
  }

  Future<void> _refresh() async {
    if (_childId == null) return;
    setState(() => _future = _missions.loadCurrent(_childId!));
    await _future;
  }

  Future<void> _claim(NoorMission mission) async {
    final id = _childId;
    if (id == null) return;
    final ok = await _missions.claim(id, mission);
    if (!mounted) return;
    if (ok) {
      await NoorSoundService.playEffect('success.wav');
      ref.invalidate(selectedChildProvider);
      ref.invalidate(childrenProvider);
      await _refresh();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('أحسنت! حصلت على ${mission.rewardPoints} نقطة و${mission.rewardStars} نجمة.'),
        behavior: SnackBarBehavior.floating,
      ));
    } else {
      await _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('مهامي ومكافآتي'), centerTitle: true),
      body: child.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('تعذر تحميل الملف الشخصي')),
        data: (profile) {
          if (profile == null) return const Center(child: Text('اختر ملف المتعلم أولًا'));
          _load(profile.id);
          return FutureBuilder<List<NoorMission>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) return Center(child: Text('تعذر تحميل المهام: ${snapshot.error}'));
              final all = snapshot.data ?? const <NoorMission>[];
              final daily = all.where((m) => m.period == 'daily').toList();
              final weekly = all.where((m) => m.period == 'weekly').toList();
              return RefreshIndicator(
                onRefresh: _refresh,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
                  children: [
                    _WelcomePanel(name: profile.name, avatar: profile.avatar),
                    const SizedBox(height: 18),
                    _MissionGroup(title: 'مهام اليوم', subtitle: 'تتجدد يوميًا — كل خطوة صغيرة تستحق التشجيع', icon: Icons.today_rounded, color: const Color(0xFFE6F5F1), missions: daily, onClaim: _claim),
                    const SizedBox(height: 18),
                    _MissionGroup(title: 'تحديات الأسبوع', subtitle: 'أهداف أكبر موزعة على أيام الأسبوع', icon: Icons.calendar_month_rounded, color: const Color(0xFFECEBFF), missions: weekly, onClaim: _claim),
                    const SizedBox(height: 14),
                    const Text('المكافآت لا تُخصم عند عدم إكمال المهام، ويمكنك المحاولة من جديد في الفترة التالية.', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey, height: 1.5)),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _WelcomePanel extends StatelessWidget {
  const _WelcomePanel({required this.name, required this.avatar});
  final String name, avatar;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(colors: [Color(0xFF126F75), Color(0xFF6D7FD4)]),
      boxShadow: [BoxShadow(color: const Color(0xFF126F75).withValues(alpha: .18), blurRadius: 18, offset: const Offset(0, 7))],
    ),
    child: Row(children: [
      Text(avatar, style: const TextStyle(fontSize: 42)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('أهلًا يا $name!', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 19)),
        const SizedBox(height: 4),
        const Text('أنجز مهامك واجمع النجوم والنقاط', style: TextStyle(color: Colors.white, height: 1.4)),
      ])),
      const Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFD56A), size: 30),
    ]),
  );
}

class _MissionGroup extends StatelessWidget {
  const _MissionGroup({required this.title, required this.subtitle, required this.icon, required this.color, required this.missions, required this.onClaim});
  final String title, subtitle;
  final IconData icon;
  final Color color;
  final List<NoorMission> missions;
  final ValueChanged<NoorMission> onClaim;
  @override
  Widget build(BuildContext context) {
    final done = missions.where((m) => m.completed).length;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        Container(width: 44, height: 44, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: const Color(0xFF315D70))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
          Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
        ])),
        Text('$done/${missions.length}', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF16877E))),
      ]),
      const SizedBox(height: 10),
      if (missions.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('سيتم تجهيز المهام بعد قليل.'))),
      for (final mission in missions) _MissionTile(mission: mission, onClaim: () => onClaim(mission)),
    ]);
  }
}

class _MissionTile extends StatelessWidget {
  const _MissionTile({required this.mission, required this.onClaim});
  final NoorMission mission;
  final VoidCallback onClaim;
  @override
  Widget build(BuildContext context) {
    final done = mission.completed;
    final claimed = mission.claimed;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 260),
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: claimed ? const Color(0xFFF1F8F4) : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: done ? const Color(0xFF8CCDB6) : const Color(0xFFE5EAF0)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .035), blurRadius: 10, offset: const Offset(0, 3))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Icon(claimed ? Icons.verified_rounded : done ? Icons.emoji_events_rounded : Icons.flag_rounded, color: claimed ? const Color(0xFF26956F) : const Color(0xFFB17B27)),
          const SizedBox(width: 9),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(mission.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 2),
            Text(mission.description, style: const TextStyle(fontSize: 12, color: Colors.blueGrey)),
          ])),
          Text('${mission.progress}/${mission.target}', style: const TextStyle(fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(20), child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: mission.fraction), duration: const Duration(milliseconds: 500),
          builder: (context, value, _) => LinearProgressIndicator(value: value, minHeight: 8, backgroundColor: const Color(0xFFE9EEF1), color: done ? const Color(0xFF28A47A) : const Color(0xFF6F91D8)),
        )),
        const SizedBox(height: 9),
        Row(children: [
          const Icon(Icons.stars_rounded, size: 17, color: Color(0xFFE0A52C)),
          Text(' ${mission.rewardPoints} نقطة  •  ⭐ ${mission.rewardStars}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
          const Spacer(),
          if (claimed) const Chip(label: Text('تم الاستلام'), visualDensity: VisualDensity.compact)
          else if (done) FilledButton.icon(onPressed: onClaim, icon: const Icon(Icons.card_giftcard_rounded, size: 17), label: const Text('استلام'))
          else Text('واصل التقدم', style: TextStyle(fontSize: 11, color: Colors.blueGrey.shade600)),
        ]),
      ]),
    );
  }
}
