import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/providers.dart';
import '../../core/widgets/noor_brand.dart';
import '../../core/services/noor_sound_service.dart';

class NoorAvatarStudioScreen extends ConsumerStatefulWidget {
  const NoorAvatarStudioScreen({super.key});
  @override
  ConsumerState<NoorAvatarStudioScreen> createState() => _NoorAvatarStudioScreenState();
}

class _NoorAvatarStudioScreenState extends ConsumerState<NoorAvatarStudioScreen> {
  static const hairs = ['💇', '🦱', '👧', '🧑', '🧢', '👑'];
  static const outfits = ['👕', '👗', '🧥', '🥋', '🦸', '🧙'];
  static const accessories = ['⭐', '🎀', '🕶️', '🌸', '🚀', '💎'];
  static const rooms = ['🌳', '🌊', '🚀', '🏰', '🌈'];
  String hair = '💇', outfit = '👕', accessory = '⭐', room = '🌳';
  int? _loadedChildId;

  @override
  Widget build(BuildContext context) {
    final childAsync = ref.watch(selectedChildProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('استوديو شخصية نور')),
      body: childAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('تعذر تحميل الملف')),
        data: (child) {
          if (child == null) return const Center(child: Text('اختر ملف الطفل أولًا'));
          return FutureBuilder<Map<String, String>>(
            key: ValueKey('avatar-settings-${child.id}'),
            future: ref.read(childRepositoryProvider).avatarSettings(child.id),
            builder: (context, snapshot) {
              if (snapshot.hasData && _loadedChildId != child.id) {
                final values = snapshot.data!;
                hair = values['hair'] ?? '💇';
                outfit = values['outfit'] ?? '👕';
                accessory = values['accessory'] ?? '⭐';
                room = values['room_theme'] ?? '🌳';
                _loadedChildId = child.id;
              }
              return NoorPageBackground(
                asset: 'assets/branding/noor-bg-forest.webp',
                child: ListView(padding: const EdgeInsets.all(18), children: [
                  Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
                    const Text('هذه شخصيتك في عالم نور', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    const SizedBox(height: 12),
                    Container(width: 150, height: 150,
                      decoration: BoxDecoration(color: const Color(0xFFE8F4F0), borderRadius: BorderRadius.circular(32)),
                      child: Stack(alignment: Alignment.center, children: [
                        Text(child.avatar, style: const TextStyle(fontSize: 76)),
                        Positioned(top: 10, child: Text(hair, style: const TextStyle(fontSize: 30))),
                        Positioned(bottom: 12, right: 15, child: Text(accessory, style: const TextStyle(fontSize: 28))),
                      ])),
                    const SizedBox(height: 8),
                    Text('${child.name} • ${outfit}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  ]))),
                  _choiceGroup('تسريحة / غطاء الرأس', hairs, hair, (v) => setState(() => hair = v)),
                  _choiceGroup('الملابس', outfits, outfit, (v) => setState(() => outfit = v)),
                  _choiceGroup('الإكسسوار', accessories, accessory, (v) => setState(() => accessory = v)),
                  _choiceGroup('غرفتك الخاصة', rooms, room, (v) => setState(() => room = v)),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.brush_rounded),
                      title: const Text('ارسم شخصيتك بنفسك'),
                      subtitle: const Text('لوحة رسم تحفظ إبداعك داخل ملفك'),
                      trailing: const Icon(Icons.chevron_left_rounded),
                      onTap: () => context.push('/avatar-drawing'),
                    ),
                  ),
                  Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
                    Container(
                      height: 154,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(22),
                        gradient: LinearGradient(
                          colors: room == '🌊'
                              ? const [Color(0xFFB7E6F4), Color(0xFF4C9DB8)]
                              : room == '🚀'
                                  ? const [Color(0xFF303B72), Color(0xFF8067A8)]
                                  : room == '🏰'
                                      ? const [Color(0xFFFFE0A8), Color(0xFFCE8C78)]
                                      : room == '🌈'
                                          ? const [Color(0xFFFFD5E5), Color(0xFFB9DDF4)]
                                          : const [Color(0xFFC9E8C5), Color(0xFF5D9C79)],
                        ),
                      ),
                      child: Stack(children: [
                        const Positioned(left: 16, bottom: 10, child: Text('🪴', style: TextStyle(fontSize: 38))),
                        const Positioned(right: 18, bottom: 10, child: Text('🧸', style: TextStyle(fontSize: 38))),
                        Center(child: Text(room, style: const TextStyle(fontSize: 76))),
                        Positioned(top: 12, left: 0, right: 0,
                          child: Text('غرفة ${child.name}', textAlign: TextAlign.center,
                            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.white, shadows: [Shadow(blurRadius: 5, color: Colors.black45)]))),
                      ]),
                    ),
                    const SizedBox(height: 10),
                    const Text('مكانك لعرض إنجازاتك ورفاقك الذين فتحتهم'),
                    const SizedBox(height: 8),
                    FutureBuilder<int>(
                      future: ref.read(childRepositoryProvider).badgeCount(child.id),
                      builder: (_, count) => Text('🏅 ${count.data ?? 0} وسامًا • ⭐ ${child.points} نقطة'),
                    ),
                  ]))),
                  FilledButton.icon(
                    onPressed: () async {
                      await ref.read(childRepositoryProvider).saveAvatarSettings(
                        child.id, hair: hair, outfit: outfit,
                        accessory: accessory, roomTheme: room);
                      await NoorSoundService.playEffect('success.wav');
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم حفظ شخصيتك وغرفتك!')));
                    },
                    icon: const Icon(Icons.save_rounded),
                    label: const Text('حفظ الشخصية والغرفة'),
                  ),
                ]),
              );
            },
          );
        },
      ),
    );
  }

  Widget _choiceGroup(String title, List<String> values, String selected,
      ValueChanged<String> onSelected) => Card(
        child: Padding(padding: const EdgeInsets.all(14), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final value in values)
                ChoiceChip(label: Text(value, style: const TextStyle(fontSize: 22)),
                  selected: selected == value, onSelected: (_) {
                    NoorSoundService.playEffect('tap.wav');
                    onSelected(value);
                  }),
            ]),
          ],
        )),
      );
}
