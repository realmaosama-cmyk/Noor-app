import 'package:material_ui/material_ui.dart';
import '../../core/theme/app_theme.dart';
import '../../data/content/learning_domains.dart';

/// A winding, child-friendly route through NOOR's two learning worlds.
class NoorAdventureMap extends StatelessWidget {
  const NoorAdventureMap({
    super.key,
    required this.domains,
    required this.sectionCounts,
    required this.lessonCounts,
    required this.onOpen,
  });

  final List<NoorLearningDomain> domains;
  final Map<String, int> sectionCounts;
  final Map<String, int> lessonCounts;
  final ValueChanged<String> onOpen;

  @override
  Widget build(BuildContext context) {
    if (domains.isEmpty) return const SizedBox.shrink();
    const rowHeight = 126.0;
    return SizedBox(
      height: domains.length * rowHeight,
      child: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _AdventurePathPainter(
                color: AppColors.teal.withValues(alpha: .28),
                rowHeight: rowHeight,
              ),
            ),
          ),
          Column(
            children: [
              for (var i = 0; i < domains.length; i++)
                SizedBox(
                  height: rowHeight,
                  child: _AdventureNode(
                    domain: domains[i],
                    index: i,
                    sections: sectionCounts[domains[i].id] ?? 0,
                    lessons: lessonCounts[domains[i].id] ?? 0,
                    onTap: () {
                      onOpen(domains[i].id);
                    },
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AdventureNode extends StatelessWidget {
  const _AdventureNode({
    required this.domain,
    required this.index,
    required this.sections,
    required this.lessons,
    required this.onTap,
  });

  final NoorLearningDomain domain;
  final int index;
  final int sections;
  final int lessons;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isLeft = index.isEven;
    final isSharia = domain.id == 'sharia';
    final color = isSharia ? AppColors.teal : const Color(0xFF7185D8);
    final node = Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        border: Border.all(color: Colors.white, width: 4),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: .25),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(domain.emoji, style: const TextStyle(fontSize: 27)),
    );
    final card = Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Material(
          color: Colors.white.withValues(alpha: .96),
          borderRadius: BorderRadius.circular(22),
          elevation: 2,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    domain.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    domain.subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppColors.ink,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Row(
                    children: [
                      Icon(Icons.explore_rounded, size: 13, color: color),
                      const SizedBox(width: 4),
                      Text('$sections عوالم فرعية',
                          style: const TextStyle(
                              fontSize: 10, fontWeight: FontWeight.w800)),
                      const SizedBox(width: 9),
                      Icon(Icons.menu_book_rounded, size: 13, color: color),
                      const SizedBox(width: 3),
                      Text('$lessons درسًا',
                          style: const TextStyle(
                              fontSize: 10, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 420 + index * 130),
      curve: Curves.easeOutBack,
      builder: (context, value, child) => Opacity(
        opacity: value.clamp(0.0, 1.0).toDouble(),
        child: Transform.translate(
          offset: Offset(isLeft ? -18 * (1 - value) : 18 * (1 - value), 0),
          child: child,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: Row(
          children: isLeft
              ? [card, const SizedBox(width: 10), node, const Spacer()]
              : [const Spacer(), node, const SizedBox(width: 10), card],
        ),
      ),
    );
  }
}

class _AdventurePathPainter extends CustomPainter {
  const _AdventurePathPainter({required this.color, required this.rowHeight});
  final Color color;
  final double rowHeight;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    const dash = 8.0;
    const gap = 8.0;
    final x = size.width / 2;
    var y = 24.0;
    final end = size.height - 24;
    while (y < end) {
      canvas.drawLine(Offset(x, y), Offset(x, (y + dash).clamp(0.0, end).toDouble()), paint);
      y += dash + gap;
    }
    final marker = Paint()..color = color.withValues(alpha: .45);
    for (var i = 0; i < (size.height / rowHeight).floor(); i++) {
      canvas.drawCircle(Offset(x, rowHeight * i + rowHeight / 2), 4, marker);
    }
  }

  @override
  bool shouldRepaint(covariant _AdventurePathPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.rowHeight != rowHeight;
}
