import '../../data/content/catalog.dart';

typedef AppSection = NoorSection;
const appSections = noorSections;
AppSection sectionById(String id) => noorSections.firstWhere((s) => s.id == id,
    orElse: () => noorSections.first);
