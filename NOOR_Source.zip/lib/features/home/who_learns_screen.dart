import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';


class WhoLearnsScreen extends ConsumerStatefulWidget {
  const WhoLearnsScreen({super.key});
  @override
  ConsumerState<WhoLearnsScreen> createState() => _WhoLearnsScreenState();
}

class _WhoLearnsScreenState extends ConsumerState<WhoLearnsScreen> {
  bool creating = false;
  int step = 0;
  final name = TextEditingController();
  final nameFocus = FocusNode();
  int age = 8;
  String gender = 'unspecified';
  String avatar = '🦊';
  final Set<String> interests = {'علوم', 'ألغاز وذكاء'};
  final Map<int, int> diagnostic = {};
  int get diagnosticScore => diagnostic.entries
      .where((e) => e.value == _diagnosticQuestions[e.key].$3)
      .length;
  static const _diagnosticQuestions = <(String, List<String>, int)>[
    ('إذا كان معك 3 نجوم وحصلت على نجمتين، فكم أصبح لديك؟', ['4', '5', '6'], 1),
    ('أي كلمة تبدأ بحرف الباء؟', ['قمر', 'باب', 'شمس'], 1),
    (
      'وجدت معلومة غريبة على الإنترنت، ماذا تفعل؟',
      ['أتحقق وأسأل شخصًا موثوقًا', 'أنشرها فورًا', 'أصدقها دائمًا'],
      0
    ),
  ];
  static const avatars = [
    '🦊',
    '🦁',
    '🐼',
    '🐯',
    '🐸',
    '🐧',
    '🦄',
    '🚀',
    '🐬',
    '🦉',
    '🧑‍🚀',
    '🧙‍♀️'
  ];
  static const interestOptions = [
    'علوم',
    'رياضيات',
    'قصص',
    'رسم وفنون',
    'رياضة وحركة',
    'برمجة',
    'طبيعة وحيوانات',
    'ألغاز وذكاء',
    'فضاء واكتشاف',
    'مهارات حياتية',
    'حيوانات',
    'مشاعر',
    'مال وادخار',
    'أمان رقمي',
    'موسيقى',
    'رياضة',
    'طبخ',
    'اختراعات'
  ];

  @override
  void dispose() {
    name.dispose();
    nameFocus.dispose();
    super.dispose();
  }

  Future<void> finish() async {
    if (name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('اكتب اسم البطل أولًا')));
      return;
    }
    final id = await ref.read(childRepositoryProvider).create(
          name: name.text.trim(),
          age: age,
          gender: gender,
          avatar: avatar,
          interests: interests.toList(),
        );
    ref.invalidate(childrenProvider);
    ref.read(selectedChildIdProvider.notifier).state = id;
    if (mounted) context.go('/home');
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final children = ref.watch(childrenProvider);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFFE3F7F3), Color(0xFFF3F0FF), Color(0xFFFFF5E8)],
            ),
            image: DecorationImage(
                image: AssetImage('assets/branding/noor-bg-forest.webp'),
                fit: BoxFit.cover,
                colorFilter:
                    ColorFilter.mode(Color(0xDDF7FCFA), BlendMode.srcOver))),
        child: SafeArea(
            child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Column(children: [
            const NoorBrand(),
            const SizedBox(height: 16),
            if (!creating) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .88),
                    borderRadius: BorderRadius.circular(28)),
                child: const Column(children: [
                  Text('🌈 🪄 🚀', style: TextStyle(fontSize: 32)),
                  SizedBox(height: 6),
                  Text('من سيخوض المغامرة اليوم؟',
                      style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                          color: AppColors.ink),
                      textAlign: TextAlign.center),
                  Text('أنشئ ملفًا خاصًا أو أكمل رحلتك',
                      style: TextStyle(color: Colors.blueGrey)),
                ]),
              ),
              const SizedBox(height: 14),
              Expanded(
                  child: children.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) =>
                    const Center(child: Text('تعذر تحميل الملفات الشخصية')),
                data: (list) => list.isEmpty
                    ? const Center(
                        child: Text('هنا تبدأ أول حكاية لك ✨',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w800)))
                    : ListView.separated(
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 9),
                        itemBuilder: (ctx, i) {
                          final c = list[i];
                          return NoorEntrance(
                              delay: i,
                              child: Material(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(22),
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(22),
                                  onTap: () {
                                    ref
                                        .read(selectedChildIdProvider.notifier)
                                        .state = c.id;
                                    context.go('/home');
                                  },
                                  child: Padding(
                                      padding: const EdgeInsets.all(14),
                                      child: Row(children: [
                                        CircleAvatar(
                                            radius: 27,
                                            backgroundColor: AppColors.lavender,
                                            child: Text(c.avatar,
                                                style: const TextStyle(
                                                    fontSize: 28))),
                                        const SizedBox(width: 12),
                                        Expanded(
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                              Text(c.name,
                                                  style: const TextStyle(
                                                      fontSize: 17,
                                                      fontWeight:
                                                          FontWeight.w900)),
                                              Text(
                                                  '${c.age} سنة • ${c.ageLabel}',
                                                  style: const TextStyle(
                                                      color: Colors.blueGrey,
                                                      fontSize: 12)),
                                            ])),
                                        const Icon(
                                            Icons.play_circle_fill_rounded,
                                            color: AppColors.teal,
                                            size: 30),
                                      ])),
                                ),
                              ));
                        },
                      ),
              )),
              SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: FilledButton.icon(
                    onPressed: () => setState(() {
                      creating = true;
                      step = 0;
                    }),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('إنشاء شخصية جديدة'),
                  )),
              TextButton.icon(
                  onPressed: () => context.push('/parent'),
                  icon: const Icon(Icons.family_restroom_rounded),
                  label: const Text('مساحة ولي الأمر')),
            ] else ...[
              Row(children: [
                IconButton(
                    onPressed: () => setState(() {
                          if (step == 0) {
                            creating = false;
                          } else {
                            step--;
                          }
                        }),
                    icon: const Icon(Icons.arrow_back_rounded)),
                const Spacer(),
                Text('الخطوة ${step + 1} من 5',
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, color: AppColors.teal)),
              ]),
              ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                      value: (step + 1) / 5,
                      minHeight: 7,
                      backgroundColor: Colors.white,
                      color: AppColors.teal)),
              const SizedBox(height: 16),
              Expanded(
                  child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 320),
                transitionBuilder: (child, animation) => FadeTransition(
                    opacity: animation,
                    child: SlideTransition(
                        position: Tween<Offset>(
                                begin: const Offset(.08, 0), end: Offset.zero)
                            .animate(animation),
                        child: child)),
                child: SingleChildScrollView(
                    key: ValueKey(step),
                    child: Card(
                      color: Colors.white.withValues(alpha: .94),
                      child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                if (step == 0) ...[
                                  const Text(
                                    '👋',
                                    style: TextStyle(fontSize: 44),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 6),
                                  const Text(
                                    'ما اسم بطلك؟',
                                    style: TextStyle(
                                      fontSize: 23,
                                      fontWeight: FontWeight.w900,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 12),
                                  TextField(
                                    controller: name,
                                    focusNode: nameFocus,
                                    autofocus: true,
                                    keyboardType: TextInputType.name,
                                    textInputAction: TextInputAction.next,
                                    maxLength: 18,
                                    textDirection: TextDirection.rtl,
                                    textAlign: TextAlign.right,
                                    decoration: const InputDecoration(
                                      labelText: 'الاسم الذي تحب أن نناديك به',
                                      prefixIcon: Icon(Icons.face_rounded),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  const Text('اختَر رفيق رحلتك',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900)),
                                  const SizedBox(height: 8),
                                  Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                            'assets/branding/mascot-fox.webp',
                                            width: 58,
                                            height: 58),
                                        Image.asset(
                                            'assets/branding/mascot-owl.webp',
                                            width: 58,
                                            height: 58),
                                        Image.asset(
                                            'assets/branding/mascot-unicorn.webp',
                                            width: 58,
                                            height: 58)
                                      ]),
                                  const SizedBox(height: 8),
                                  Wrap(
                                      spacing: 10,
                                      runSpacing: 10,
                                      alignment: WrapAlignment.center,
                                      children: avatars
                                          .map((a) => ChoiceChip(
                                              label: Text(a,
                                                  style: const TextStyle(
                                                      fontSize: 25)),
                                              selected: avatar == a,
                                              onSelected: (_) =>
                                                  setState(() => avatar = a)))
                                          .toList()),
                                ],
                                if (step == 1) ...[
                                  const Text('🎂',
                                      style: TextStyle(fontSize: 44),
                                      textAlign: TextAlign.center),
                                  const Text('كم عمرك؟',
                                      style: TextStyle(
                                          fontSize: 23,
                                          fontWeight: FontWeight.w900),
                                      textAlign: TextAlign.center),
                                  Text('$age سنوات',
                                      style: const TextStyle(
                                          fontSize: 30,
                                          color: AppColors.teal,
                                          fontWeight: FontWeight.w900),
                                      textAlign: TextAlign.center),
                                  Slider(
                                      min: 3,
                                      max: 16,
                                      divisions: 13,
                                      value: age.toDouble(),
                                      onChanged: (v) =>
                                          setState(() => age = v.round())),
                                  Wrap(
                                      spacing: 8,
                                      runSpacing: 8,
                                      alignment: WrapAlignment.center,
                                      children: [
                                        for (final v in [
                                          3,
                                          5,
                                          7,
                                          9,
                                          12,
                                          14,
                                          16
                                        ])
                                          ChoiceChip(
                                              label: Text('$v'),
                                              selected: age == v,
                                              onSelected: (_) =>
                                                  setState(() => age = v))
                                      ]),
                                  const SizedBox(height: 8),
                                  Text(
                                      age <= 5
                                          ? 'أنشطة قصيرة بالصور والأصوات والاكتشاف.'
                                          : age <= 8
                                              ? 'مغامرات وحكايات وألعاب تأسيسية.'
                                              : age <= 12
                                                  ? 'تحديات وعلوم ومشروعات وألعاب تفكير.'
                                                  : 'مسارات متقدمة ومهارات ومشروعات عملية.',
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(height: 1.6)),
                                ],
                                if (step == 2) ...[
                                  const Text('🌟',
                                      style: TextStyle(fontSize: 44),
                                      textAlign: TextAlign.center),
                                  const Text('كيف تحب أن تظهر شخصيتك؟',
                                      style: TextStyle(
                                          fontSize: 22,
                                          fontWeight: FontWeight.w900),
                                      textAlign: TextAlign.center),
                                  const Text(
                                      'اختيار اختياري لتخصيص الأسماء والشخصيات وطريقة السرد. كل العوالم والأنشطة متاحة للجميع.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(height: 1.5)),
                                  const SizedBox(height: 14),
                                  for (final option in [
                                    ('unspecified', 'أفضل عدم التحديد'),
                                    ('male', 'ولد'),
                                    ('female', 'بنت')
                                  ])
                                    Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 8),
                                        child: ChoiceChip(
                                            label: Text(option.$2),
                                            selected: gender == option.$1,
                                            onSelected: (_) => setState(
                                                () => gender = option.$1),
                                            labelStyle: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w800))),
                                ],
                                if (step == 3) ...[
                                  const Text('🎨',
                                      style: TextStyle(fontSize: 44),
                                      textAlign: TextAlign.center),
                                  const Text('ماذا تحب أن تستكشف؟',
                                      style: TextStyle(
                                          fontSize: 23,
                                          fontWeight: FontWeight.w900),
                                      textAlign: TextAlign.center),
                                  const Text(
                                      'اختر اهتماماتك لتظهر لك العوالم المفضلة أولًا. يمكنك تغييرها لاحقًا.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(height: 1.5)),
                                  const SizedBox(height: 14),
                                  Wrap(
                                      spacing: 8,
                                      runSpacing: 8,
                                      children: interestOptions
                                          .map((item) => FilterChip(
                                              label: Text(item),
                                              selected:
                                                  interests.contains(item),
                                              onSelected: (v) => setState(() {
                                                    if (v) {
                                                      interests.add(item);
                                                    } else {
                                                      interests.remove(item);
                                                    }
                                                  })))
                                          .toList()),
                                ],
                                if (step == 4) ...[
                                  const Text('🧠',
                                      style: TextStyle(fontSize: 44),
                                      textAlign: TextAlign.center),
                                  const Text('تحدي تعارف صغير',
                                      style: TextStyle(
                                          fontSize: 23,
                                          fontWeight: FontWeight.w900),
                                      textAlign: TextAlign.center),
                                  const Text(
                                      'ثلاثة أسئلة خفيفة تساعدنا على اختيار نقطة بداية مناسبة. لا توجد درجات نجاح أو رسوب.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(height: 1.5)),
                                  const SizedBox(height: 12),
                                  for (var q = 0;
                                      q < _diagnosticQuestions.length;
                                      q++) ...[
                                    Text(
                                        '${q + 1}. ${_diagnosticQuestions[q].$1}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w900)),
                                    const SizedBox(height: 6),
                                    Wrap(spacing: 7, runSpacing: 6, children: [
                                      for (var a = 0;
                                          a < _diagnosticQuestions[q].$2.length;
                                          a++)
                                        ChoiceChip(
                                            label: Text(
                                                _diagnosticQuestions[q].$2[a]),
                                            selected: diagnostic[q] == a,
                                            onSelected: (_) => setState(
                                                () => diagnostic[q] = a))
                                    ]),
                                    const SizedBox(height: 12),
                                  ],
                                  Text(
                                      'أجبت عن ${diagnostic.length} من 3 أسئلة • سنبدأ بهدوء ونضبط التحديات مع تقدمك.',
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: AppColors.teal,
                                          fontWeight: FontWeight.w800)),
                                ],
                              ])),
                    )),
              )),
              SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: FilledButton.icon(
                    onPressed: step < 4
                        ? () {
                            if (step == 0 && name.text.trim().isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text('اكتب الاسم للمتابعة')));
                              return;
                            }
                            setState(() => step++);
                          }
                        : finish,
                    icon: Icon(step < 4
                        ? Icons.arrow_forward_rounded
                        : Icons.rocket_launch_rounded),
                    label: Text(step < 4 ? 'التالي' : 'ابدأ مغامرتي',
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                  )),
            ],
            const SizedBox(height: 6),
          ]),
        )),
      ),
    );
  }

}
