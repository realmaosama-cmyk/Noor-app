import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/noor_brand.dart';
import '../../data/providers.dart';

class RewardsScreen extends ConsumerWidget {
  const RewardsScreen({super.key});
  static const rewards = [
    ('🌙', 'حارس الهلال', 'رفيق هادئ لرحلتك', 40),
    ('🦁', 'الأسد الشجاع', 'قلب قوي وروح لطيفة', 80),
    ('🐼', 'الباندا المرح', 'يحب الاكتشاف', 100),
    ('🦊', 'الثعلب الذكي', 'خبير الألغاز', 120),
    ('🐯', 'النمر السريع', 'مستعد للتحديات', 150),
    ('🐧', 'البطريق المغامر', 'يحب العوالم الجديدة', 180),
    ('🦄', 'وحيد القرن اللامع', 'شخصية نادرة', 220),
    ('🚀', 'مستكشف الفضاء', 'رفيق النجوم والكواكب', 260),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final child = ref.watch(selectedChildProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('متجر نجوم نور')),
      body: child.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('تعذر تحميل الرصيد')),
        data: (c) {
          if (c == null) return const Center(child: Text('اختر ملف الطفل أولًا'));
          return NoorPageBackground(
            asset: 'assets/branding/noor-bg-ocean.webp',
            child: FutureBuilder<Set<String>>(
              future: ref.read(childRepositoryProvider).ownedCompanions(c.id),
              builder: (context, inventory) {
                if (inventory.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (inventory.hasError) {
                  return const Center(child: Text('تعذر تحميل الرفاق المفتوحين'));
                }
                final owned = inventory.data ?? <String>{c.avatar};
                return ListView(
                  padding: const EdgeInsets.all(18),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(27),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF165B70), Color(0xFF0D9B91)],
                        ),
                      ),
                      child: Row(children: [
                        const Icon(Icons.stars_rounded, color: AppColors.gold, size: 42),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('رصيدك من النجوم', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
                              Text('${c.points} نقطة', style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
                              Text('رفاقك المفتوحون: ${owned.length}', style: const TextStyle(color: Colors.white70)),
                            ],
                          ),
                        ),
                      ]),
                    ),
                    const SizedBox(height: 18),
                    const Text('اختر رفيقًا جديدًا', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    for (final item in rewards)
                      _CompanionCard(
                        item: item,
                        owned: owned.contains(item.$1),
                        equipped: c.avatar == item.$1,
                        canAfford: c.points >= item.$4,
                        onUnlock: () async {
                          final ok = await ref.read(childRepositoryProvider).purchaseAvatar(c.id, item.$1, item.$4);
                          if (!context.mounted) return;
                          if (ok) {
                            ref.invalidate(selectedChildProvider);
                            ref.invalidate(childrenProvider);
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('مبروك! أصبح ${item.$2} رفيقك الجديد 🎉')));
                          } else {
                            ref.invalidate(selectedChildProvider);
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لم يتم الفتح؛ تأكد من الرصيد أو أن الرفيق غير مفتوح بالفعل.')));
                          }
                        },
                        onEquip: () async {
                          final ok = await ref.read(childRepositoryProvider).equipOwnedAvatar(c.id, item.$1);
                          if (!context.mounted) return;
                          if (ok) {
                            ref.invalidate(selectedChildProvider);
                            ref.invalidate(childrenProvider);
                          }
                        },
                      ),
                  ],
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class _CompanionCard extends StatelessWidget {
  const _CompanionCard({
    required this.item,
    required this.owned,
    required this.equipped,
    required this.canAfford,
    required this.onUnlock,
    required this.onEquip,
  });

  final (String, String, String, int) item;
  final bool owned;
  final bool equipped;
  final bool canAfford;
  final VoidCallback onUnlock;
  final VoidCallback onEquip;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Row(children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(color: AppColors.lavender, borderRadius: BorderRadius.circular(18)),
            alignment: Alignment.center,
            child: Text(item.$1, style: const TextStyle(fontSize: 34)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                Text(item.$3, style: const TextStyle(fontSize: 12, color: Colors.blueGrey)),
                Text(owned ? 'تم فتحه' : '⭐ ${item.$4} نقطة', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.teal)),
              ],
            ),
          ),
          if (equipped)
            const Chip(avatar: Icon(Icons.check_circle, size: 16), label: Text('مفعّل'))
          else if (owned)
            OutlinedButton(onPressed: onEquip, child: const Text('استخدم'))
          else
            FilledButton(onPressed: canAfford ? onUnlock : null, child: const Text('فتح')),
        ]),
      ),
    );
  }
}
