import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/providers.dart';
import '../../data/repositories/avatar_drawing_repository.dart';

class NoorAvatarDrawingScreen extends ConsumerStatefulWidget {
  const NoorAvatarDrawingScreen({super.key});
  @override
  ConsumerState<NoorAvatarDrawingScreen> createState() =>
      _NoorAvatarDrawingScreenState();
}

class _NoorAvatarDrawingScreenState extends ConsumerState<NoorAvatarDrawingScreen> {
  final _repository = AvatarDrawingRepository();
  final List<NoorDrawingStroke> _strokes = [];
  List<List<double>>? _active;
  int _color = 0xFF126F75;
  bool _loaded = false;
  bool _loading = false;
  int? _childId;

  static const _colors = <int>[
    0xFF126F75, 0xFFFF806B, 0xFF8068D8, 0xFFFFC247,
    0xFF3A8DDE, 0xFF69B67B, 0xFF222B45, 0xFFEF7DB5,
  ];

  Future<void> _load(int childId) async {
    if ((_loaded || _loading) && _childId == childId) return;
    _childId = childId;
    _loaded = false;
    _loading = true;
    try {
      final saved = await _repository.load(childId);
      if (!mounted || _childId != childId) return;
      setState(() {
        _strokes
          ..clear()
          ..addAll(saved);
        _loaded = true;
        _loading = false;
      });
    } catch (_) {
      if (!mounted || _childId != childId) return;
      setState(() {
        _strokes.clear();
        _loaded = true;
        _loading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر تحميل الرسم السابق؛ يمكنك بدء رسمة جديدة.')),
      );
    }
  }

  void _start(Offset point, Size size) {
    setState(() => _active = [[
      (point.dx / size.width).clamp(0.0, 1.0).toDouble(),
      (point.dy / size.height).clamp(0.0, 1.0).toDouble(),
    ]]);
  }

  void _move(Offset point, Size size) {
    if (_active == null) return;
    setState(() => _active!.add([
      (point.dx / size.width).clamp(0.0, 1.0).toDouble(),
      (point.dy / size.height).clamp(0.0, 1.0).toDouble(),
    ]));
  }

  void _finish() {
    final points = _active;
    if (points == null || points.isEmpty) return;
    setState(() {
      _strokes.add(NoorDrawingStroke(
        points: points.map((p) => List<double>.unmodifiable(p)).toList(),
        color: _color,
        width: 5,
      ));
      _active = null;
    });
  }

  Future<void> _save(int childId) async {
    await _repository.save(childId, List.unmodifiable(_strokes));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حفظ رسمتك في ملفك الشخصي 🎨')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final child = ref.watch(selectedChildProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('ارسم شخصيتك')),
      body: child.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('تعذر تحميل الملف')),
        data: (profile) {
          if (profile == null) return const Center(child: Text('اختر ملف المتعلم أولًا'));
          _load(profile.id);
          if (!_loaded || _childId != profile.id) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('يا ${profile.name}، ارسم شخصيتك بإصبعك واختر ألوانك المفضلة.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5)),
              const SizedBox(height: 12),
              AspectRatio(
                aspectRatio: 1,
                child: LayoutBuilder(builder: (context, constraints) {
                  final size = Size(constraints.maxWidth, constraints.maxHeight);
                  return Container(
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: const Color(0xFFD9E5E7), width: 2),
                    ),
                    child: GestureDetector(
                      onPanStart: (d) => _start(d.localPosition, size),
                      onPanUpdate: (d) => _move(d.localPosition, size),
                      onPanEnd: (_) => _finish(),
                      child: CustomPaint(
                        painter: NoorAvatarDrawingPainter(_strokes, _active, _color),
                        child: const SizedBox.expand(),
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: _colors.map((value) => GestureDetector(
                  onTap: () => setState(() => _color = value),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Color(value),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _color == value ? Colors.black : Colors.white,
                        width: 3,
                      ),
                    ),
                  ),
                )).toList(),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: OutlinedButton.icon(
                  onPressed: _strokes.isEmpty ? null : () => setState(_strokes.removeLast),
                  icon: const Icon(Icons.undo_rounded), label: const Text('تراجع'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(
                  onPressed: _strokes.isEmpty ? null : () => setState(_strokes.clear),
                  icon: const Icon(Icons.delete_outline), label: const Text('مسح الكل'))),
              ]),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () => _save(profile.id),
                icon: const Icon(Icons.save_rounded),
                label: const Text('حفظ الرسم'),
              ),
            ],
          );
        },
      ),
    );
  }
}

class NoorAvatarDrawingPainter extends CustomPainter {
  const NoorAvatarDrawingPainter(this.strokes, this.active, this.activeColor);
  final List<NoorDrawingStroke> strokes;
  final List<List<double>>? active;
  final int activeColor;

  @override
  void paint(Canvas canvas, Size size) {
    for (final stroke in strokes) {
      _paintStroke(canvas, size, stroke.points, stroke.color, stroke.width);
    }
    if (active != null) _paintStroke(canvas, size, active!, activeColor, 5);
  }

  void _paintStroke(Canvas canvas, Size size, List<List<double>> points,
      int color, double width) {
    if (points.isEmpty) return;
    final paint = Paint()
      ..color = Color(color)
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    if (points.length == 1) {
      canvas.drawCircle(
        Offset(points.first[0] * size.width, points.first[1] * size.height),
        width / 2,
        paint..style = PaintingStyle.fill,
      );
      return;
    }
    final path = Path()
      ..moveTo(points.first[0] * size.width, points.first[1] * size.height);
    for (final point in points.skip(1)) {
      path.lineTo(point[0] * size.width, point[1] * size.height);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant NoorAvatarDrawingPainter oldDelegate) => true;
}
