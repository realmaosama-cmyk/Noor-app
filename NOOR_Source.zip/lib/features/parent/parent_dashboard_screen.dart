import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/providers.dart';
import '../../core/widgets/noor_brand.dart';
import '../home/sections.dart';
import '../../data/models/child.dart';
import '../../data/content/catalog.dart';
import '../../data/repositories/missions_repository.dart';
import '../../data/repositories/child_repository.dart';

class ParentDashboardScreen extends ConsumerWidget {
  const ParentDashboardScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final children = ref.watch(childrenProvider);
    final states =
        ref.watch(sectionStatesProvider).valueOrNull ?? const <String, bool>{};
    final limit = ref.watch(_dailyLimitProvider).valueOrNull ?? 0;
    return Scaffold(
        appBar: AppBar(title: const Text('لوحة ولي الأمر')),
        body: NoorPageBackground(
            asset: 'assets/branding/noor-bg-forest.webp',
            child: ListView(padding: const EdgeInsets.all(18), children: [
              Text('إدارة الملفات الشخصية',
                  style: Theme.of(context).textTheme.titleLarge),
              children.when(
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (_, __) => const Text('تعذر تحميل البيانات'),
                  data: (list) => Column(children: [
                        for (final c in list)
                          _ProfileCard(child: c, dailyLimit: limit),
                        if (list.isEmpty) const Text('لا توجد ملفات شخصية بعد.')
                      ])),
              const SizedBox(height: 18),
              Card(
                  child: SwitchListTile(
                      title: const Text('الوضع الليلي الهادئ'),
                      subtitle: const Text('ألوان أهدأ للشاشات المسائية'),
                      value: ref.watch(darkModeProvider).valueOrNull ?? false,
                      onChanged: (v) async {
                        await ref
                            .read(settingsRepositoryProvider)
                            .setDarkMode(v);
                        ref.invalidate(darkModeProvider);
                      })),
              const SizedBox(height: 18),
              Text('التحكم في المحتوى',
                  style: Theme.of(context).textTheme.titleLarge),
              for (final s in appSections)
                SwitchListTile(
                    title: Text('${s.emoji} ${s.title}'),
                    value: states[s.id] ?? true,
                    onChanged: (v) async {
                      await ref
                          .read(settingsRepositoryProvider)
                          .setSectionEnabled(s.id, v);
                      ref.invalidate(sectionStatesProvider);
                    }),
              const Divider(),
              Text('الوقت اليومي المقترح',
                  style: Theme.of(context).textTheme.titleLarge),
              DropdownButtonFormField<int>(
                  initialValue: limit,
                  decoration: const InputDecoration(
                      labelText: 'الدقائق المقترحة يوميًا (صفر = بدون تحديد)'),
                  items: const [0, 15, 30, 45, 60, 90, 120]
                      .map((v) => DropdownMenuItem<int>(
                          value: v,
                          child: Text(v == 0 ? 'بدون حد' : '$v دقيقة')))
                      .toList(),
                  onChanged: (v) async {
                    if (v != null) {
                      await ref
                          .read(settingsRepositoryProvider)
                          .setDailyLimit(v);
                      ref.invalidate(_dailyLimitProvider);
                    }
                  }),
              const SizedBox(height: 8),
              const Text(
                  'عند بلوغ الحد يتوقف مسار الطفل وتظهر شاشة راحة، ولا يمكن المتابعة إلا عبر مساحة ولي الأمر أو في اليوم التالي.'),
              const SizedBox(height: 18),
              const Card(
                  child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Text(
                          'تُحفظ ملفات المستخدمين والتقدم محليًا على الجهاز. لا تتوفر حاليًا مزامنة سحابية أو نسخ احتياطي؛ وهما خارج نطاق هذا الإصدار.')))
            ])));
  }
}

final _dailyLimitProvider = FutureProvider<int>(
    (ref) => ref.watch(settingsRepositoryProvider).dailyLimit());

class _ProfileCard extends ConsumerWidget {
  const _ProfileCard({required this.child, required this.dailyLimit});
  final Child child;
  final int dailyLimit;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder<Map<String, int>>(
        future: _loadProfileSummary(ref, child.id),
        builder: (ctx, s) {
          final data =
              s.data ?? {'completed': 0, 'average': 0, 'todaySeconds': 0};
          final usedMinutes = (data['todaySeconds'] ?? 0) ~/ 60;
          final timeLabel = dailyLimit > 0
              ? '$usedMinutes / $dailyLimit دقيقة اليوم'
              : '$usedMinutes دقيقة اليوم';
          return Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                ListTile(
                  leading: CircleAvatar(child: Text(child.avatar)),
                  title: Text('${child.name} • ⭐ ${child.stars} • ${child.points} نقطة'),
                  subtitle: Text(
                    '${child.age} سنة • المستوى ${child.level} • ${data['completed']} درس مكتمل • ${data['mastered']} درس متقن • متوسط ${data['average']}% • مهام اليوم ${data['dailyDone'] ?? 0}/${data['dailyTotal'] ?? 0} • الأسبوع ${data['weeklyDone'] ?? 0}/${data['weeklyTotal'] ?? 0} • ${data['prayersCompleted'] ?? 0}/35 صلاة آخر 7 أيام • $timeLabel',
                  ),
                  trailing: IconButton(
                    tooltip: 'حذف الملف',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('حذف الملف؟'),
                          content: Text('سيتم حذف تقدم ${child.name} من هذا الجهاز.'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await ref.read(childRepositoryProvider).delete(child.id);
                        if (ref.read(selectedChildIdProvider) == child.id) {
                          ref.read(selectedChildIdProvider.notifier).state = null;
                        }
                        ref.invalidate(childrenProvider);
                      }
                    },
                  ),
                ),
                ExpansionTile(
                  leading: const Icon(Icons.analytics_outlined),
                  title: const Text('تفاصيل التعلم حسب القسم'),
                  subtitle: const Text('افتح لمراجعة الدروس المتقنة في كل مجال'),
                  children: [
                    FutureBuilder<List<_SectionProgress>>(
                      future: _loadSectionProgress(child.id),
                      builder: (context, sectionSnapshot) {
                        if (sectionSnapshot.connectionState == ConnectionState.waiting) {
                          return const Padding(
                            padding: EdgeInsets.all(16),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        if (sectionSnapshot.hasError) {
                          return const ListTile(title: Text('تعذر تحميل تفاصيل الأقسام.'));
                        }
                        final rows = sectionSnapshot.data ?? const <_SectionProgress>[];
                        return Column(
                          children: [
                            for (final row in rows)
                              ListTile(
                                dense: true,
                                title: Text('${row.emoji} ${row.title}'),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: LinearProgressIndicator(
                                      value: row.total == 0 ? 0 : row.mastered / row.total,
                                      minHeight: 7,
                                    ),
                                  ),
                                ),
                                trailing: Text('${row.mastered}/${row.total}'),
                              ),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }
}

class _SectionProgress {
  const _SectionProgress(this.title, this.emoji, this.mastered, this.total);
  final String title, emoji;
  final int mastered, total;
}

Future<List<_SectionProgress>> _loadSectionProgress(int childId) async {
  final repository = ChildRepository();
  final result = <_SectionProgress>[];
  for (final section in noorSections) {
    final ids = section.lessons.map((lesson) => lesson.id).toList(growable: false);
    if (ids.isEmpty) continue;
    final mastered = await repository.masteredLessonsInSection(childId, ids);
    result.add(_SectionProgress(section.title, section.emoji, mastered, ids.length));
  }
  return result;
}

Future<Map<String, int>> _loadProfileSummary(WidgetRef ref, int childId) async {
  final repo = ref.read(childRepositoryProvider);
  final progress = await repo.progressSummary(childId);
  final seconds = await repo.todaySecondsUsed(childId);
  final prayers = await repo.prayerSummary(childId);
  final missions = await NoorMissionsRepository().loadCurrent(childId);
  final daily = missions.where((mission) => mission.period == 'daily').toList();
  final weekly = missions.where((mission) => mission.period == 'weekly').toList();
  return {
    ...progress,
    'todaySeconds': seconds,
    'prayersCompleted': prayers['completed'] ?? 0,
    'mastered': (await repo.masterySummary(childId))['mastered'] ?? 0,
    'dailyDone': daily.where((mission) => mission.completed).length,
    'dailyTotal': daily.length,
    'weeklyDone': weekly.where((mission) => mission.completed).length,
    'weeklyTotal': weekly.length,
  };
}
