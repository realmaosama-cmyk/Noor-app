class DailyWisdom {
  const DailyWisdom(
      {required this.ayah,
      required this.ayahRef,
      required this.hadith,
      required this.hadithRef,
      required this.reflection});
  final String ayah, ayahRef, hadith, hadithRef, reflection;
}

const dailyWisdom = <DailyWisdom>[
  DailyWisdom(
      ayah: 'وَقُل رَّبِّ زِدْنِي عِلْمًا',
      ayahRef: 'طه: 114',
      hadith:
          'مَن سلك طريقًا يلتمس فيه علمًا سهّل الله له به طريقًا إلى الجنة.',
      hadithRef: 'صحيح مسلم: 2699',
      reflection: 'كل سؤال تتعلم إجابته يفتح لك بابًا جديدًا من المعرفة.'),
  DailyWisdom(
      ayah: 'فَاذْكُرُونِي أَذْكُرْكُمْ',
      ayahRef: 'البقرة: 152',
      hadith: 'لا يَرحمُ اللهُ مَن لا يَرحمُ الناسَ.',
      hadithRef: 'صحيح البخاري: 7376',
      reflection: 'اجعل لسانك رطبًا بذكر الله، وقلبك رحيمًا بالناس.'),
  DailyWisdom(
      ayah: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
      ayahRef: 'الشرح: 6',
      hadith: 'تبسُّمُك في وجه أخيك لك صدقة.',
      hadithRef: 'جامع الترمذي: 1956',
      reflection: 'إذا واجهت أمرًا صعبًا، اصبر واطلب المساعدة وابدأ بخطوة.'),
  DailyWisdom(
      ayah: 'وَقُولُوا لِلنَّاسِ حُسْنًا',
      ayahRef: 'البقرة: 83',
      hadith: 'لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.',
      hadithRef: 'صحيح البخاري: 13',
      reflection: 'اختر كلمات طيبة كما تحب أن تسمع من الآخرين.'),
  DailyWisdom(
      ayah: 'وَبِالْوَالِدَيْنِ إِحْسَانًا',
      ayahRef: 'الإسراء: 23',
      hadith: 'إنما الأعمال بالنيات.',
      hadithRef: 'صحيح البخاري: 1',
      reflection: 'ابدأ عملك بنية طيبة، وأحسن إلى والديك.'),
  DailyWisdom(
      ayah: 'إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ',
      ayahRef: 'البقرة: 195',
      hadith: 'من لا يَرحم لا يُرحم.',
      hadithRef: 'صحيح البخاري: 5997',
      reflection: 'الإحسان يظهر في أفعالك الصغيرة كل يوم.'),
  DailyWisdom(
      ayah: 'وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ',
      ayahRef: 'المائدة: 2',
      hadith: 'والله في عون العبد ما كان العبد في عون أخيه.',
      hadithRef: 'صحيح مسلم: 2699',
      reflection: 'ساعد شخصًا اليوم، ولو بشيء بسيط.'),
];
DailyWisdom wisdomForToday([DateTime? date]) {
  final today = date ?? DateTime.now();
  final day = DateTime(today.year, today.month, today.day)
      .difference(DateTime(2025, 1, 1))
      .inDays;
  return dailyWisdom[day.abs() % dailyWisdom.length];
}
