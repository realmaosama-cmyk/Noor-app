import 'catalog.dart';

/// Presentation-only grouping: persisted section and lesson IDs never change.
class NoorLearningDomain {
  const NoorLearningDomain(
      {required this.id,
      required this.title,
      required this.subtitle,
      required this.emoji,
      required this.sectionIds});
  final String id, title, subtitle, emoji;
  final List<String> sectionIds;

  List<NoorSection> sections(Iterable<NoorSection> available) {
    final byId = {for (final section in available) section.id: section};
    return [
      for (final id in sectionIds)
        if (byId.containsKey(id)) byId[id]!
    ];
  }
}

const noorLearningDomains = <NoorLearningDomain>[
  NoorLearningDomain(
      id: 'sharia',
      title: 'القسم الشرعي',
      subtitle: 'قرآن • صلاة • أذكار • سيرة • أخلاق',
      emoji: '🕌',
      sectionIds: [
        'quran',
        'prayer',
        'adhkar',
        'akhlaq',
        'seerah',
        'figures',
        'prophets',
        'curriculum'
      ]),
  NoorLearningDomain(
      id: 'science',
      title: 'القسم العلمي',
      subtitle: 'علوم • رياضيات • لغات • برمجة • اكتشاف ومهارات',
      emoji: '🔬',
      sectionIds: [
        'learn',
        'challenges',
        'arabic',
        'math',
        'science',
        'nature',
        'life-skills',
        'creative',
        'coding',
        'world',
        'english',
        'wellbeing',
        'future',
        'space',
        'animals',
        'emotions',
        'money',
        'digital',
        'music',
        'sports',
        'cooking',
        'engineering'
      ]),
];

NoorLearningDomain? learningDomainById(String id) {
  for (final domain in noorLearningDomains) {
    if (domain.id == id) return domain;
  }
  return null;
}
