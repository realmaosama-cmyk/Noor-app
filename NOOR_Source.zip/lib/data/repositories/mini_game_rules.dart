/// Small deterministic rules shared by NOOR's offline mini-games.
class NoorMiniGameRules {
  const NoorMiniGameRules._();

  static bool isAdjacentCell(int current, int next, {int columns = 5}) {
    if (columns <= 0 || current < 0 || next < 0) return false;
    final currentRow = current ~/ columns;
    final currentColumn = current % columns;
    final nextRow = next ~/ columns;
    final nextColumn = next % columns;
    return (currentRow == nextRow && (currentColumn - nextColumn).abs() == 1) ||
        (currentColumn == nextColumn && (currentRow - nextRow).abs() == 1);
  }

  static bool isReachableMazePath(List<int> path, Set<int> openCells,
      {int columns = 5}) {
    if (path.isEmpty || path.any((cell) => !openCells.contains(cell))) return false;
    for (var i = 1; i < path.length; i++) {
      if (!isAdjacentCell(path[i - 1], path[i], columns: columns)) return false;
    }
    return path.toSet().length == path.length;
  }

  static bool hasFoundAllDifferences(Set<int> found, Set<int> differences) =>
      differences.isNotEmpty && found.containsAll(differences);

  static bool isCorrectStoryOrder(List<int> selected, List<int> answer) {
    if (selected.length != answer.length) return false;
    for (var i = 0; i < answer.length; i++) {
      if (selected[i] != answer[i]) return false;
    }
    return true;
  }
}
