import 'package:sqflite/sqflite.dart';
import '../db/app_database.dart';

class NoorMission {
  const NoorMission({required this.id, required this.period, required this.title,
    required this.description, required this.eventType, required this.progress,
    required this.target, required this.rewardPoints, required this.rewardStars,
    required this.claimed});
  final String id, period, title, description, eventType;
  final int progress, target, rewardPoints, rewardStars;
  final bool claimed;
  bool get completed => progress >= target;
  double get fraction => target == 0 ? 0.0 : (progress / target).clamp(0.0, 1.0).toDouble();
  factory NoorMission.fromMap(Map<String, Object?> row) => NoorMission(
    id: row['mission_id'] as String, period: row['period_type'] as String,
    title: row['title'] as String, description: row['description'] as String,
    eventType: row['event_type'] as String, progress: row['progress'] as int,
    target: row['target'] as int, rewardPoints: row['reward_points'] as int,
    rewardStars: row['reward_stars'] as int, claimed: (row['claimed'] as int) == 1);
}

class _MissionDefinition {
  const _MissionDefinition(this.id, this.title, this.description, this.event,
      this.target, this.points, this.stars);
  final String id, title, description, event;
  final int target, points, stars;
}

class NoorMissionsRepository {
  static const _dailyPool = <_MissionDefinition>[
    _MissionDefinition('daily_lesson', 'درس جديد', 'أكمل درسًا واحدًا اليوم', 'lesson', 1, 20, 1),
    _MissionDefinition('daily_two_lessons', 'خطوتان من المعرفة', 'أكمل درسين اليوم', 'lesson', 2, 35, 2),
    _MissionDefinition('daily_game', 'وقت التحدي', 'أكمل تحديًا تعليميًا', 'game', 1, 25, 1),
    _MissionDefinition('daily_prayer', 'موعد مع الصلاة', 'سجّل صلاة واحدة اليوم', 'prayer', 1, 15, 1),
    _MissionDefinition('daily_bookmark', 'احفظ ما أعجبك', 'أضف درسًا إلى المفضلة', 'bookmark', 1, 15, 1),
    _MissionDefinition('daily_three_lessons', 'باحث نشيط', 'أكمل ثلاثة دروس اليوم', 'lesson', 3, 45, 3),
  ];
  static const _weeklyPool = <_MissionDefinition>[
    _MissionDefinition('weekly_lessons', 'رحلة المعرفة', 'أكمل خمسة دروس هذا الأسبوع', 'lesson', 5, 80, 5),
    _MissionDefinition('weekly_games', 'بطل الألعاب', 'أكمل ثلاثة تحديات تعليمية', 'game', 3, 60, 4),
    _MissionDefinition('weekly_prayers', 'المحافظة على الصلاة', 'سجّل خمس صلوات خلال الأسبوع', 'prayer', 5, 60, 4),
    _MissionDefinition('weekly_active_days', 'أيام مليئة بالتعلم', 'تعلّم في ثلاثة أيام مختلفة', 'active_day', 3, 70, 5),
    _MissionDefinition('weekly_bookmarks', 'مكتبة المفضلة', 'احفظ درسين للعودة إليهما', 'bookmark', 2, 45, 3),
    _MissionDefinition('weekly_learning', 'خطوات ثابتة', 'أكمل ثمانية دروس هذا الأسبوع', 'lesson', 8, 110, 7),
  ];

  Future<List<NoorMission>> loadCurrent(int childId, {DateTime? now}) async {
    final date = now ?? DateTime.now();
    final db = await AppDatabase.instance.database;
    final dayKey = dayKeyFor(date), weekKey = weekKeyFor(date);
    await db.transaction((txn) async {
      await _ensurePeriod(txn, childId, 'daily', dayKey, _select(_dailyPool, childId, dayKey, 3));
      await _ensurePeriod(txn, childId, 'weekly', weekKey, _select(_weeklyPool, childId, weekKey, 4));
    });
    final rows = await db.query('missions',
      where: 'child_id = ? AND ((period_type = ? AND period_key = ?) OR (period_type = ? AND period_key = ?))',
      whereArgs: [childId, 'daily', dayKey, 'weekly', weekKey],
      orderBy: "CASE period_type WHEN 'daily' THEN 0 ELSE 1 END, mission_id");
    return rows.map(NoorMission.fromMap).toList(growable: false);
  }

  Future<void> recordEvent(int childId, String eventType, {DateTime? now}) async {
    final date = now ?? DateTime.now();
    final db = await AppDatabase.instance.database;
    final dayKey = dayKeyFor(date), weekKey = weekKeyFor(date);
    await db.transaction((txn) async {
      await _ensurePeriod(txn, childId, 'daily', dayKey, _select(_dailyPool, childId, dayKey, 3));
      await _ensurePeriod(txn, childId, 'weekly', weekKey, _select(_weeklyPool, childId, weekKey, 4));
      await _increment(txn, childId, 'daily', dayKey, eventType, dayKey);
      await _increment(txn, childId, 'weekly', weekKey, eventType, dayKey);
      if (eventType != 'active_day') {
        await _increment(txn, childId, 'daily', dayKey, 'active_day', dayKey);
        await _increment(txn, childId, 'weekly', weekKey, 'active_day', dayKey);
      }
    });
  }

  /// Records a completed game and its reward atomically so retries cannot
  /// accidentally grant points twice if mission progress fails to persist.
  Future<void> recordGameCompletion(int childId,
      {int points = 25, int stars = 2, DateTime? now}) async {
    if (points < 0 || stars < 0) {
      throw ArgumentError('Game rewards cannot be negative.');
    }
    final date = now ?? DateTime.now();
    final db = await AppDatabase.instance.database;
    final dayKey = dayKeyFor(date), weekKey = weekKeyFor(date);
    await db.transaction((txn) async {
      await _ensurePeriod(txn, childId, 'daily', dayKey, _select(_dailyPool, childId, dayKey, 3));
      await _ensurePeriod(txn, childId, 'weekly', weekKey, _select(_weeklyPool, childId, weekKey, 4));
      await _increment(txn, childId, 'daily', dayKey, 'game', dayKey);
      await _increment(txn, childId, 'weekly', weekKey, 'game', dayKey);
      await _increment(txn, childId, 'daily', dayKey, 'active_day', dayKey);
      await _increment(txn, childId, 'weekly', weekKey, 'active_day', dayKey);
      final changed = await txn.rawUpdate(
        'UPDATE children SET points = points + ?, stars = stars + ? WHERE id = ?',
        [points, stars, childId],
      );
      if (changed != 1) {
        throw StateError('Learner profile no longer exists.');
      }
    });
  }

  Future<bool> claim(int childId, NoorMission mission) async {
    final db = await AppDatabase.instance.database;
    return db.transaction((txn) async {
      final now = DateTime.now();
      final periodKey = mission.period == 'daily' ? dayKeyFor(now) : weekKeyFor(now);
      final changed = await txn.rawUpdate(
        '''UPDATE missions SET claimed = 1, updated_at = ?
           WHERE child_id = ? AND period_type = ? AND mission_id = ?
             AND period_key = ? AND claimed = 0 AND progress >= target''',
        [now.toIso8601String(), childId, mission.period, mission.id, periodKey]);
      if (changed != 1) return false;
      final rewarded = await txn.rawUpdate(
        'UPDATE children SET points = points + ?, stars = stars + ? WHERE id = ?',
        [mission.rewardPoints, mission.rewardStars, childId],
      );
      if (rewarded != 1) {
        // Roll back the claimed flag as well: never consume a mission reward
        // when its learner profile disappeared before the transaction finished.
        throw StateError('Learner profile no longer exists.');
      }
      return true;
    });
  }

  Future<void> _ensurePeriod(Transaction txn, int childId, String period,
      String key, List<_MissionDefinition> definitions) async {
    for (final item in definitions) {
      await txn.insert('missions', {
        'child_id': childId, 'period_type': period, 'period_key': key,
        'mission_id': item.id, 'title': item.title, 'description': item.description,
        'event_type': item.event, 'progress': 0, 'target': item.target,
        'reward_points': item.points, 'reward_stars': item.stars, 'claimed': 0,
        'last_event_day': '', 'updated_at': DateTime.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<void> _increment(Transaction txn, int childId, String period,
      String key, String event, String day) async {
    final rows = await txn.query('missions',
      columns: ['mission_id', 'progress', 'target', 'last_event_day'],
      where: 'child_id = ? AND period_type = ? AND period_key = ? AND event_type = ?',
      whereArgs: [childId, period, key, event]);
    for (final row in rows) {
      final previousDay = row['last_event_day'] as String? ?? '';
      if (event == 'active_day' && previousDay == day) continue;
      final progress = row['progress'] as int, target = row['target'] as int;
      if (progress >= target) continue;
      await txn.update('missions', {
        'progress': progress + 1 > target ? target : progress + 1,
        'last_event_day': event == 'active_day' ? day : previousDay,
        'updated_at': DateTime.now().toIso8601String(),
      }, where: 'child_id = ? AND period_type = ? AND period_key = ? AND mission_id = ?',
        whereArgs: [childId, period, key, row['mission_id']]);
    }
  }

  List<_MissionDefinition> _select(List<_MissionDefinition> pool,
      int childId, String key, int count) {
    final seed = '$childId:$key'.codeUnits.fold<int>(17,
        (value, unit) => (value * 31 + unit) & 0x7fffffff);
    final start = seed % pool.length;
    return List.generate(count, (i) => pool[(start + i) % pool.length]);
  }
  static List<String> dailyMissionIdsFor(int childId, DateTime date) =>
      _selectStatic(_dailyPool, childId, dayKeyFor(date), 3);

  static List<String> weeklyMissionIdsFor(int childId, DateTime date) =>
      _selectStatic(_weeklyPool, childId, weekKeyFor(date), 4);

  static List<String> _selectStatic(List<_MissionDefinition> pool,
      int childId, String key, int count) {
    final seed = '$childId:$key'.codeUnits.fold<int>(17,
        (value, unit) => (value * 31 + unit) & 0x7fffffff);
    final start = seed % pool.length;
    return List.generate(count, (i) => pool[(start + i) % pool.length].id);
  }

  static String dayKeyFor(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  static String weekKeyFor(DateTime date) {
    final day = DateTime(date.year, date.month, date.day);
    final thursday = day.add(Duration(days: 4 - day.weekday));
    final jan4 = DateTime(thursday.year, 1, 4);
    final firstThursday = jan4.add(Duration(days: 4 - jan4.weekday));
    final week = 1 + thursday.difference(firstThursday).inDays ~/ 7;
    return '${thursday.year}-W${week.toString().padLeft(2, '0')}';
  }
}
