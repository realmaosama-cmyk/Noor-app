/// Deterministic rules for the sequential learning path.
class MasteryRules {
  static const int minimumScore = 80;

  static bool isMastered(int bestScore) => bestScore >= minimumScore;

  /// The first lesson is always available. Every later lesson requires mastery
  /// of its immediate predecessor; locked lessons remain visible for motivation.
  static bool isUnlocked(int lessonIndex, {required bool previousMastered}) =>
      lessonIndex <= 0 || previousMastered;
}
