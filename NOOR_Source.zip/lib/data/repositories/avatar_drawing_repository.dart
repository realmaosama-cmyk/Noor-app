import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../db/app_database.dart';

class NoorDrawingStroke {
  const NoorDrawingStroke({
    required this.points,
    required this.color,
    required this.width,
  });

  /// Each point is normalized to the 0..1 canvas coordinate space.
  final List<List<double>> points;
  final int color;
  final double width;

  Map<String, Object> toJson() => {
    'points': points,
    'color': color,
    'width': width,
  };

  factory NoorDrawingStroke.fromJson(Map<String, dynamic> json) =>
      NoorDrawingStroke(
        points: (json['points'] as List? ?? const [])
            .whereType<List>()
            .map((point) => point.map((v) => (v as num).toDouble()).toList())
            .toList(growable: false),
        color: (json['color'] as num?)?.toInt() ?? 0xFF126F75,
        width: (json['width'] as num?)?.toDouble() ?? 5,
      );
}

class AvatarDrawingRepository {
  Future<List<NoorDrawingStroke>> load(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('avatar_drawings',
        columns: ['strokes_json'],
        where: 'child_id = ?', whereArgs: [childId], limit: 1);
    if (rows.isEmpty) return const [];
    try {
      final raw = jsonDecode(rows.first['strokes_json'] as String) as List;
      return raw.whereType<Map>()
          .map((v) => NoorDrawingStroke.fromJson(Map<String, dynamic>.from(v)))
          .toList(growable: false);
    } catch (_) {
      // Drawing data is optional and isolated from profile/progress records.
      return const [];
    }
  }

  Future<void> save(int childId, List<NoorDrawingStroke> strokes) async {
    final db = await AppDatabase.instance.database;
    await db.insert('avatar_drawings', {
      'child_id': childId,
      'strokes_json': jsonEncode(strokes.map((s) => s.toJson()).toList()),
      'updated_at': DateTime.now().toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
