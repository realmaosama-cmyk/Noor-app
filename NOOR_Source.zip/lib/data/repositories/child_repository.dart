import 'package:sqflite/sqflite.dart';
import '../db/app_database.dart';
import '../models/child.dart';
import 'missions_repository.dart';
import 'mastery_rules.dart';

class ChildRepository {
  Future<List<Child>> all() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('children', orderBy: 'id DESC');
    return rows.map(Child.fromMap).toList();
  }

  Future<Child?> byId(int id) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('children', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : Child.fromMap(rows.first);
  }

  Future<int> create(
      {required String name,
      required int age,
      required String gender,
      required String avatar,
      List<String> interests = const []}) async {
    final db = await AppDatabase.instance.database;
    return db.transaction((txn) async {
      final id = await txn.insert('children', {
        'name': name,
        'age': age,
        'gender': gender,
        'avatar': avatar,
        'interests': interests.join('|')
      });
      await txn.insert('companion_inventory', {
        'child_id': id,
        'companion_id': avatar,
        'unlocked_at': DateTime.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
      return id;
    });
  }

  Future<void> update(Child child) async {
    final db = await AppDatabase.instance.database;
    await db.transaction((txn) async {
      await txn.update(
          'children',
          {
            'name': child.name,
            'age': child.age,
            'gender': child.gender,
            'avatar': child.avatar,
            'stars': child.stars,
            'points': child.points,
            'interests': child.interests.join('|'),
          },
          where: 'id = ?',
          whereArgs: [child.id]);
      await txn.insert('companion_inventory', {
        'child_id': child.id,
        'companion_id': child.avatar,
        'unlocked_at': DateTime.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    });
  }

  Future<Set<String>> ownedCompanions(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('companion_inventory',
        columns: ['companion_id'],
        where: 'child_id = ?',
        whereArgs: [childId]);
    return rows.map((row) => row['companion_id'] as String).toSet();
  }

  Future<bool> purchaseAvatar(int childId, String avatar, int cost) async {
    final db = await AppDatabase.instance.database;
    if (cost < 0 || avatar.trim().isEmpty) return false;
    return db.transaction((txn) async {
      final alreadyOwned = await txn.query('companion_inventory',
          columns: ['companion_id'],
          where: 'child_id = ? AND companion_id = ?',
          whereArgs: [childId, avatar],
          limit: 1);
      if (alreadyOwned.isNotEmpty) return false;
      final changed = await txn.rawUpdate(
        'UPDATE children SET points = points - ?, avatar = ? WHERE id = ? AND points >= ?',
        [cost, avatar, childId, cost],
      );
      if (changed != 1) return false;
      await txn.insert('companion_inventory', {
        'child_id': childId,
        'companion_id': avatar,
        'unlocked_at': DateTime.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
      return true;
    });
  }

  Future<bool> equipOwnedAvatar(int childId, String avatar) async {
    final db = await AppDatabase.instance.database;
    return db.transaction((txn) async {
      final owned = await txn.query('companion_inventory',
          columns: ['companion_id'],
          where: 'child_id = ? AND companion_id = ?',
          whereArgs: [childId, avatar],
          limit: 1);
      if (owned.isEmpty) return false;
      final changed = await txn.update('children', {'avatar': avatar},
          where: 'id = ?', whereArgs: [childId]);
      return changed == 1;
    });
  }

  Future<void> delete(int id) async {
    final db = await AppDatabase.instance.database;
    await db.transaction((txn) async {
      for (final table in [
        'progress',
        'badges',
        'usage_log',
        'bookmarks',
        'prayer_logs',
        'missions',
        'avatar_settings',
        'lesson_mastery',
        'avatar_drawings',
        'companion_inventory',
      ]) {
        await txn.delete(table, where: 'child_id = ?', whereArgs: [id]);
      }
      await txn.delete('children', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<void> addReward(int childId,
      {required int points, required int stars}) async {
    final db = await AppDatabase.instance.database;
    await db.rawUpdate(
        'UPDATE children SET points = points + ?, stars = stars + ? WHERE id = ?',
        [points, stars, childId]);
  }

  Future<int> completedLessons(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
        "SELECT COUNT(*) AS c FROM progress WHERE child_id = ? AND status = 'done'",
        [childId]);
    return (rows.first['c'] as int?) ?? 0;
  }

  Future<int> totalSecondsUsed(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(seconds), 0) AS s FROM usage_log WHERE child_id = ?',
      [childId],
    );
    return (rows.first['s'] as int?) ?? 0;
  }

  Future<int> todaySecondsUsed(int childId) async {
    final db = await AppDatabase.instance.database;
    final day = DateTime.now().toIso8601String().substring(0, 10);
    final rows = await db.query(
      'usage_log',
      columns: ['seconds'],
      where: 'child_id = ? AND day = ?',
      whereArgs: [childId, day],
    );
    return rows.isEmpty ? 0 : ((rows.first['seconds'] as int?) ?? 0);
  }

  Future<Map<String, int>> progressSummary(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('progress',
        columns: ['score'],
        where: "child_id = ? AND status = 'done'",
        whereArgs: [childId]);
    final scores = rows.map((e) => e['score'] as int).toList();
    return {
      'completed': scores.length,
      'average':
          scores.isEmpty ? 0 : scores.reduce((a, b) => a + b) ~/ scores.length
    };
  }

  Future<bool> isCompleted(int childId, String lessonId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('progress',
        columns: ['lesson_id'],
        where: 'child_id = ? AND lesson_id = ?',
        whereArgs: [childId, lessonId]);
    return rows.isNotEmpty;
  }

  Future<int> masteredLessonsInSection(
      int childId, List<String> lessonIds) async {
    if (lessonIds.isEmpty) return 0;
    final db = await AppDatabase.instance.database;
    final placeholders = List.filled(lessonIds.length, '?').join(',');
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM lesson_mastery WHERE child_id = ? AND mastered = 1 AND lesson_id IN ($placeholders)',
      [childId, ...lessonIds],
    );
    return (rows.first['c'] as int?) ?? 0;
  }

  Future<void> recordMasteryAttempt(int childId, String lessonId, int score) async {
    final db = await AppDatabase.instance.database;
    await db.transaction((txn) async {
      final rows = await txn.query('lesson_mastery',
          columns: ['attempts', 'best_score'],
          where: 'child_id = ? AND lesson_id = ?',
          whereArgs: [childId, lessonId],
          limit: 1);
      final previousBest =
          rows.isEmpty ? 0 : (rows.first['best_score'] as int? ?? 0);
      final attempts =
          rows.isEmpty ? 1 : (rows.first['attempts'] as int? ?? 0) + 1;
      final bestScore = score > previousBest ? score : previousBest;
      await txn.insert('lesson_mastery', {
        'child_id': childId,
        'lesson_id': lessonId,
        'attempts': attempts,
        'best_score': bestScore,
        'mastered': MasteryRules.isMastered(bestScore) ? 1 : 0,
        'updated_at': DateTime.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    });
  }

  Future<bool> isMastered(int childId, String lessonId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('lesson_mastery',
        columns: ['mastered'],
        where: 'child_id = ? AND lesson_id = ?',
        whereArgs: [childId, lessonId],
        limit: 1);
    return rows.isNotEmpty && rows.first['mastered'] == 1;
  }

  Future<Map<String, int>> masterySummary(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS attempts, COALESCE(SUM(CASE WHEN mastered = 1 THEN 1 ELSE 0 END), 0) AS mastered FROM lesson_mastery WHERE child_id = ?',
      [childId],
    );
    return {
      'attempts': (rows.first['attempts'] as int?) ?? 0,
      'mastered': (rows.first['mastered'] as int?) ?? 0,
    };
  }

  Future<void> awardBadge(int childId, String badgeId) async {
    final db = await AppDatabase.instance.database;
    await db.insert(
        'badges',
        {
          'child_id': childId,
          'badge_id': badgeId,
          'earned_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<int> badgeCount(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
        'SELECT COUNT(*) AS c FROM badges WHERE child_id = ?', [childId]);
    return (rows.first['c'] as int?) ?? 0;
  }

  Future<void> completeLesson(int childId, String lessonId, int score) async {
    final db = await AppDatabase.instance.database;
    final existing = await db.query('progress', columns: ['status', 'score'],
        where: 'child_id = ? AND lesson_id = ?', whereArgs: [childId, lessonId], limit: 1);
    final wasCompleted = existing.isNotEmpty && existing.first['status'] == 'done';
    final previousBest = existing.isEmpty ? 0 : (existing.first['score'] as int? ?? 0);
    final bestScore = score > previousBest ? score : previousBest;
    await db.insert(
        'progress',
        {
          'child_id': childId,
          'lesson_id': lessonId,
          'status': 'done',
          'score': bestScore,
          'completed_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
    if (!wasCompleted) {
      await NoorMissionsRepository().recordEvent(childId, 'lesson');
    }
  }


  Future<Map<String, String>> avatarSettings(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('avatar_settings',
        where: 'child_id = ?', whereArgs: [childId], limit: 1);
    if (rows.isEmpty) {
      return {'hair': '💇', 'outfit': '👕', 'accessory': '⭐', 'room_theme': '🌳'};
    }
    return rows.first.map((key, value) => MapEntry(key, value.toString()));
  }

  Future<void> saveAvatarSettings(int childId,
      {required String hair, required String outfit,
      required String accessory, required String roomTheme}) async {
    final db = await AppDatabase.instance.database;
    await db.insert('avatar_settings', {
      'child_id': childId, 'hair': hair, 'outfit': outfit,
      'accessory': accessory, 'room_theme': roomTheme,
      'updated_at': DateTime.now().toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> addUsage(int childId, int seconds) async {
    final db = await AppDatabase.instance.database;
    final day = DateTime.now().toIso8601String().substring(0, 10);
    await db.rawInsert(
        'INSERT INTO usage_log(child_id, day, seconds) VALUES(?,?,?) ON CONFLICT(child_id,day) DO UPDATE SET seconds = seconds + excluded.seconds',
        [childId, day, seconds]);
  }

  Future<void> toggleBookmark(int childId, String itemId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('bookmarks',
        where: 'child_id = ? AND item_id = ?', whereArgs: [childId, itemId]);
    if (rows.isEmpty) {
      await db.insert('bookmarks', {
        'child_id': childId,
        'item_id': itemId,
        'created_at': DateTime.now().toIso8601String()
      });
      await NoorMissionsRepository().recordEvent(childId, 'bookmark');
    } else {
      await db.delete('bookmarks',
          where: 'child_id = ? AND item_id = ?', whereArgs: [childId, itemId]);
    }
  }

  Future<Set<String>> prayersForDay(int childId, String day) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('prayer_logs',
        columns: ['prayer'],
        where: 'child_id = ? AND day = ? AND completed = 1',
        whereArgs: [childId, day]);
    return rows.map((row) => row['prayer'] as String).toSet();
  }

  Future<void> setPrayerDone(
      int childId, String day, String prayer, bool done) async {
    final db = await AppDatabase.instance.database;
    final previous = await db.query('prayer_logs',
        columns: ['completed'],
        where: 'child_id = ? AND day = ? AND prayer = ?',
        whereArgs: [childId, day, prayer], limit: 1);
    final wasDone = previous.isNotEmpty && previous.first['completed'] == 1;
    await db.insert(
        'prayer_logs',
        {
          'child_id': childId,
          'day': day,
          'prayer': prayer,
          'completed': done ? 1 : 0,
          'updated_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
    if (done && previous.isEmpty && !wasDone) {
      await NoorMissionsRepository().recordEvent(childId, 'prayer');
    }
  }

  Future<Map<String, int>> prayerSummary(int childId, {int days = 7}) async {
    final db = await AppDatabase.instance.database;
    final since = DateTime.now()
        .subtract(Duration(days: days - 1))
        .toIso8601String()
        .substring(0, 10);
    final rows = await db.rawQuery(
        'SELECT COUNT(*) AS completed FROM prayer_logs WHERE child_id = ? AND day >= ? AND completed = 1',
        [childId, since]);
    return {
      'completed': (rows.first['completed'] as int?) ?? 0,
      'possible': days * 5
    };
  }

  Future<List<String>> bookmarks(int childId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      'bookmarks',
      columns: ['item_id'],
      where: 'child_id = ?',
      whereArgs: [childId],
      orderBy: 'created_at DESC',
    );
    return rows.map((e) => e['item_id'] as String).toList();
  }

  Future<bool> isBookmarked(int childId, String itemId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      'bookmarks',
      columns: ['item_id'],
      where: 'child_id = ? AND item_id = ?',
      whereArgs: [childId, itemId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }
}
