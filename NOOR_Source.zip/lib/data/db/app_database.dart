import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, 'nourfadaa.db'),
      version: 9,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE children(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, age INTEGER NOT NULL,
      gender TEXT NOT NULL DEFAULT 'unspecified',
      avatar TEXT NOT NULL DEFAULT '🌟',
      stars INTEGER NOT NULL DEFAULT 0, points INTEGER NOT NULL DEFAULT 0,
      interests TEXT NOT NULL DEFAULT '')''');
    await _createSupportingTables(db);
    await _createMissionTable(db);
    await _createAvatarSettingsTable(db);
    await _createLessonMasteryTable(db);
    await _createAvatarDrawingTable(db);
    await _createCompanionInventoryTable(db);
    await _seedExistingCompanions(db);
  }

  Future<void> _createSupportingTables(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS progress(
      child_id INTEGER NOT NULL, lesson_id TEXT NOT NULL,
      status TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0,
      completed_at TEXT, PRIMARY KEY(child_id, lesson_id))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS badges(
      child_id INTEGER NOT NULL, badge_id TEXT NOT NULL,
      earned_at TEXT NOT NULL, PRIMARY KEY(child_id, badge_id))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS settings(
      key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
    await db.execute('''CREATE TABLE IF NOT EXISTS usage_log(
      child_id INTEGER NOT NULL, day TEXT NOT NULL,
      seconds INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(child_id, day))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS bookmarks(
      child_id INTEGER NOT NULL, item_id TEXT NOT NULL,
      created_at TEXT NOT NULL, PRIMARY KEY(child_id, item_id))''');
    await db.execute('''CREATE TABLE IF NOT EXISTS prayer_logs(
      child_id INTEGER NOT NULL, day TEXT NOT NULL, prayer TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL,
      PRIMARY KEY(child_id, day, prayer))''');
  }

  Future<void> _createMissionTable(DatabaseExecutor db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS missions(
      child_id INTEGER NOT NULL, period_type TEXT NOT NULL, period_key TEXT NOT NULL,
      mission_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL,
      event_type TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
      target INTEGER NOT NULL, reward_points INTEGER NOT NULL DEFAULT 0,
      reward_stars INTEGER NOT NULL DEFAULT 0, claimed INTEGER NOT NULL DEFAULT 0,
      last_event_day TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL,
      PRIMARY KEY(child_id, period_type, period_key, mission_id))''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_missions_child_period ON missions(child_id, period_type, period_key)');
  }


  Future<void> _createAvatarSettingsTable(DatabaseExecutor db) async {
    await db.execute("""CREATE TABLE IF NOT EXISTS avatar_settings(
      child_id INTEGER PRIMARY KEY, hair TEXT NOT NULL DEFAULT '💇',
      outfit TEXT NOT NULL DEFAULT '👕', accessory TEXT NOT NULL DEFAULT '⭐',
      room_theme TEXT NOT NULL DEFAULT '🌳', updated_at TEXT NOT NULL)""");
  }


  Future<void> _createLessonMasteryTable(DatabaseExecutor db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS lesson_mastery(
      child_id INTEGER NOT NULL,
      lesson_id TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      best_score INTEGER NOT NULL DEFAULT 0,
      mastered INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(child_id, lesson_id))''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_mastery_child ON lesson_mastery(child_id, mastered)');
  }

  Future<void> _createAvatarDrawingTable(DatabaseExecutor db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS avatar_drawings(
      child_id INTEGER PRIMARY KEY,
      strokes_json TEXT NOT NULL DEFAULT '[]',
      updated_at TEXT NOT NULL)''');
  }

  Future<void> _createCompanionInventoryTable(DatabaseExecutor db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS companion_inventory(
      child_id INTEGER NOT NULL,
      companion_id TEXT NOT NULL,
      unlocked_at TEXT NOT NULL,
      PRIMARY KEY(child_id, companion_id))''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_companion_child ON companion_inventory(child_id)');
  }

  Future<void> _seedExistingCompanions(DatabaseExecutor db) async {
    await db.execute('''INSERT OR IGNORE INTO companion_inventory
      (child_id, companion_id, unlocked_at)
      SELECT id, avatar, CURRENT_TIMESTAMP FROM children
      WHERE avatar IS NOT NULL AND avatar != '' ''');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute(
          "ALTER TABLE children ADD COLUMN gender TEXT NOT NULL DEFAULT 'unspecified'");
      await db.execute(
          "ALTER TABLE children ADD COLUMN avatar TEXT NOT NULL DEFAULT '🌟'");
      // Preserve existing profiles and learning history during the upgrade.
      // The new columns receive safe defaults for records created by v1.
      await _createSupportingTables(db);
    }
    if (oldVersion < 3) {
      await db.execute(
          "ALTER TABLE children ADD COLUMN interests TEXT NOT NULL DEFAULT ''");
    }
    if (oldVersion < 4) {
      await db.execute('''CREATE TABLE IF NOT EXISTS prayer_logs(
        child_id INTEGER NOT NULL, day TEXT NOT NULL, prayer TEXT NOT NULL,
        completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL,
        PRIMARY KEY(child_id, day, prayer))''');
    }
    if (oldVersion < 5) {
      // Additive migration only: existing child, lesson, reward and prayer data stay intact.
      await _createMissionTable(db);
    }
    if (oldVersion < 6) {
      // Additive tables only; existing child and learning data remain untouched.
      await _createAvatarSettingsTable(db);
      await _createLessonMasteryTable(db);
    }
    if (oldVersion < 7) {
      // Additive vector-drawing storage; legacy avatar settings are preserved.
      await _createAvatarDrawingTable(db);
    }
    if (oldVersion < 8) {
      // Repair/ensure mastery storage on installations that already ran v6.
      await _createLessonMasteryTable(db);
      // Backfill old completed lesson scores without replacing any existing mastery records.
      await db.execute('''INSERT OR IGNORE INTO lesson_mastery
        (child_id, lesson_id, attempts, best_score, mastered, updated_at)
        SELECT child_id, lesson_id, 1, score,
          CASE WHEN score >= 80 THEN 1 ELSE 0 END,
          COALESCE(completed_at, CURRENT_TIMESTAMP)
        FROM progress WHERE status = 'done' ''');
    }
    if (oldVersion < 9) {
      // Additive inventory migration. Existing equipped companions become owned
      // without charging children again; no learning or profile records are replaced.
      await _createCompanionInventoryTable(db);
      await _seedExistingCompanions(db);
    }
  }
}
