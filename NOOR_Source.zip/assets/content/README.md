المحتوى التعليمي الأساسي مضمّن حاليًا في `lib/data/content/catalog.dart` ليعمل دون اتصال.
يحتوي كل درس على عنوان وشرح ومرجع وأسئلة مراجعة. أضف المحتوى الجديد مع مصدره وتحقق من النصوص الدينية قبل نشر أي تحديث.

NOOR 1.2 catalog scope: 30 worlds and 80 age-ranged lessons, with quiz feedback and source notes. The catalog remains bundled locally for offline use.
