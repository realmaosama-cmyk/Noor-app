from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
app = root / 'android' / 'app'
props_file = root / 'android' / 'key.properties'
if not props_file.exists():
    raise SystemExit('Signing properties are missing')
kts = app / 'build.gradle.kts'
groovy = app / 'build.gradle'
if kts.exists():
    text = kts.read_text()
    if 'noorSigningProperties' not in text:
        text = 'import java.util.Properties\n\n' + text
        plugin_start = text.find('plugins {')
        if plugin_start < 0: raise SystemExit('Could not locate Gradle plugins block')
        plugin_end = text.find('\n}', plugin_start)
        if plugin_end < 0: raise SystemExit('Could not parse Gradle plugins block')
        plugin_end += 2
        loader = '''\n\nval noorSigningProperties = Properties().apply {
    rootProject.file("key.properties").inputStream().use { load(it) }
}
'''
        text = text[:plugin_end] + loader + text[plugin_end:]
    if 'create("noorRelease")' not in text:
        block = '''    signingConfigs {
        create("noorRelease") {
            keyAlias = noorSigningProperties["keyAlias"] as String
            keyPassword = noorSigningProperties["keyPassword"] as String
            storeFile = file(noorSigningProperties["storeFile"] as String)
            storePassword = noorSigningProperties["storePassword"] as String
        }
    }
'''
        marker = '    buildTypes {'
        if marker not in text: raise SystemExit('Could not locate Android buildTypes in Kotlin Gradle file')
        text = text.replace(marker, block + marker, 1)
        text = text.replace('signingConfig = signingConfigs.getByName("debug")', 'signingConfig = signingConfigs.getByName("noorRelease")')
        release_marker = '        getByName("release") {'
        if release_marker in text and 'signingConfig = signingConfigs.getByName("noorRelease")' not in text:
            pos = text.index(release_marker) + len(release_marker)
            text = text[:pos] + '\n            signingConfig = signingConfigs.getByName("noorRelease")' + text[pos:]
        elif release_marker not in text and 'signingConfig = signingConfigs.getByName("noorRelease")' not in text:
            text = text.replace('        release {', '        release {\n            signingConfig = signingConfigs.getByName("noorRelease")', 1)
    kts.write_text(text)
elif groovy.exists():
    text = groovy.read_text()
    if 'noorSigningProperties' not in text:
        text = 'import java.util.Properties\n\n' + text
        plugin_start = text.find('plugins {')
        if plugin_start < 0: raise SystemExit('Could not locate Gradle plugins block')
        plugin_end = text.find('\n}', plugin_start)
        if plugin_end < 0: raise SystemExit('Could not parse Gradle plugins block')
        plugin_end += 2
        loader = '''\n\ndef noorSigningProperties = new Properties()
def noorSigningPropertiesFile = rootProject.file("key.properties")
noorSigningProperties.load(new FileInputStream(noorSigningPropertiesFile))
'''
        text = text[:plugin_end] + loader + text[plugin_end:]
    if 'noorRelease' not in text:
        block = '''    signingConfigs {
        noorRelease {
            keyAlias noorSigningProperties['keyAlias']
            keyPassword noorSigningProperties['keyPassword']
            storeFile file(noorSigningProperties['storeFile'])
            storePassword noorSigningProperties['storePassword']
        }
    }
'''
        text = text.replace('    buildTypes {', block + '    buildTypes {', 1)
        text = text.replace('release {', 'release {\n            signingConfig signingConfigs.noorRelease', 1)
    groovy.write_text(text)
else:
    raise SystemExit('Android app Gradle file was not found')
