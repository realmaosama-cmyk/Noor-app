# نور | NOOR

**نور** مساحة تعلم عربية تفاعلية تجمع المعرفة واللعب والإبداع، وتكيّف مستوى التجربة مع عمر المتعلم وملفه الشخصي.

## التجربة
- هوية بصرية عربية RTL باسم **نور | NOOR**، شعار SVG، ألوان موحدة، بطاقات متحركة وأزرار تفاعلية.
- 30 عالمًا تعليميًا و90 درسًا أساسيًا واختبارات قصيرة، مع مكتبة محتوى تراثية إضافية تُعرض داخل الأقسام المتوافقة.
- العمر يخصص أسلوب الشرح والاقتراحات فقط، ولا يحجب أي عالم أو درس.
- اختيار شخصية ورفيق رحلة دون حصر الألعاب أو الموضوعات حسب النوع؛ التخصيص في أسلوب الخطاب والشخصيات مع بقاء جميع الأنشطة متاحة للجميع.
- ملعب ألعاب بستة أنماط أساسية (مطابقة، رياضيات، منطق، كلمات، علوم، إنجليزية)، إضافة إلى متاهات واكتشاف اختلافات وترتيب قصص ومكافآت محلية.
- قصص بمواقف واختيارات، واستوديو رسم محلي، ومختبر محاكاة دورة الماء.
- مرشد نور يقدم تلميحات معدة مسبقًا حسب العمر ويعمل دون اتصال؛ ليس نموذج ذكاء اصطناعي متصلًا.
- ملفات متعددة، تقدم وشارات ومكافآت، مكتبة بحث وحفظ، ولوحة ولي الأمر مع تقارير إتقان حسب القسم وحدود وقت إرشادية.
- الخصائص الأساسية تعمل دون إنترنت؛ لا توجد محادثات عامة أو مزامنة سحابية في هذا الإصدار.

## التقنية
Flutter / Dart، Riverpod، go_router، SQLite. الأصول والواجهات الأساسية محلية.

## البناء والتحقق
GitHub Actions workflow الفعلي موجود في `.github/workflows/android.yml` (وليس ملفًا منفردًا في جذر المستودع). يشغل Flutter stable و`flutter pub get` و`dart format` و`flutter analyze` و`flutter test`، ثم يبني APK release موقّعًا باستخدام مفتاح الإصدار الموجود في GitHub Secrets. تُزال مواد التوقيع قبل تغليف المصدر. لا يتم إنشاء AAB.

> المحتوى الديني تعليمي أولي ويحتاج مراجعة شرعية متخصصة قبل النشر العام. المحاكاة العلمية تعليمية وليست تجارب فعلية.


## تجربة NOOR الجديدة
- مقدمة ترحيبية متحركة وهوية شعار متحركة داخل التطبيق.
- معالج إنشاء ملف من خمس خطوات: الاسم والشخصية، العمر 3–16، النوع الاختياري، الاهتمامات، وتحدي تعارف قصير غير تقييمي.
- تخصيص ترتيب العوالم حسب اهتمامات المتعلم، مع استمرار إتاحة الأنشطة للجميع.
- تصميم واجهة بخلفيات متدرجة وبطاقات تفاعلية؛ إصلاح بطاقات مناطق الاستكشاف التي كانت تظهر كمساحات رمادية.
- تهيئة أيقونة Android adaptive launcher من ملفات الهوية.
- توقيع APK من GitHub Actions باستخدام Secrets دون تخزين مفاتيح التوقيع في المستودع.


### الإصدار 1.1.0 (سابق)
- مقدمة ترحيبية متحركة وشعار نور نابض بالحركة.
- ثلاث شخصيات كرتونية أصلية ورسوم خلفيات لطيفة مدمجة محليًا.
- معالج إنشاء ملف من خمس خطوات: الاسم والشخصية، العمر 3–16، النوع الاختياري، الاهتمامات، وتحدي تعارف قصير غير تقييمي.
- ترتيب العوالم تلقائيًا وفق اهتمامات المتعلم مع إبقاء المحتوى متاحًا للجميع.
- إضافة عالم مستقبل الأبطال بخمس دروس عن المال والتفكير النقدي والتصميم والذكاء الاصطناعي والمشروعات.
- إصلاح بطاقات مناطق الاستكشاف التي كانت تظهر كمساحات رمادية بسبب عنصر Expanded داخل GridView.
- أيقونات Android adaptive launcher وشعار التطبيق.
- توقيع APK من GitHub Actions باستخدام أسرار المستودع، دون تضمين مفاتيح التوقيع في أرشيف المصدر.


## NOOR 1.2 — Hybrid Adventure Learning

- 30 learning worlds and 90 core lessons with quizzes and source notes; age is descriptive and does not hide content.
- Learner onboarding includes name, age, optional presentation, interests, and a short non-graded starter check.
- New worlds: astronomy, animal science, emotional literacy, money skills, digital citizenship, rhythm, sports, cooking, and engineering.
- New custom visual assets: fox, owl, unicorn, space, forest, and ocean artwork; refreshed NOOR logo and Android launcher icons.
- Games now include memory, math, logic, word, science, English, maze navigation, spot-the-difference, and story-ordering challenges.
- Gender is used only for optional presentation language; it never hides learning worlds or activities.

Release target: signed Android APK only. Release signing secrets are injected by CI and are never stored in the source archive.

- قراءة الدروس بصوت عربي عبر محرك تحويل النص إلى كلام في الجهاز؛ توفر الصوت العربي يعتمد على المحرك وحزمة اللغة المثبتة.


## Islamic learning and family tools (v1.3)

- The nine core Islamic learning areas contain lessons, quizzes, and references.
- Daily Ayah and Hadith cards rotate locally by date.
- Prayer checklist is stored per learner and day; schema v4 adds its table without deleting existing profiles or progress.
- Verse-by-verse Alafasy recitation streams from EveryAyah.com and requires internet. The app does not synthesize Qur'an recitation with text-to-speech.
- Parent settings include night mode and a daily usage limit with a rest screen; the limit is per selected child.
- Themed pages use lightweight animated ambient decorations.


## تحديث خريطة المغامرة وإتاحة المحتوى

- الواجهة الرئيسية تعرض القسم الشرعي والقسم العلمي كمسارين في خريطة مغامرات متحركة.
- العمر معلومة للتخصيص التربوي ولا يستخدم لإخفاء الدروس أو العوالم.
- محتوى المكتبة القديمة يُعرض كدروس إضافية داخل الأقسام التي يدعمها المحمّل، مع إزالة العناوين المكررة مقابل الفهرس الأساسي.
- اسم المتعلم يستخدم لوحة مفاتيح الجهاز الأصلية؛ لوحة الحروف المخصصة لم تعد تُفتح في شاشة الاسم.
- مؤثر صوتي محلي خفيف عند الانتقال بين الصفحات، مع أصوات الإجابة الصحيحة والإنجاز، وانتقالات مرئية موحدة.
- تحديث الملف الشخصي يحافظ على قائمة الاهتمامات الحالية بدل تصفيرها عند حفظ الاسم أو العمر أو الصورة الرمزية.


### تقدم جولة 28 نوفمبر 2026
- متجر الرفاق يحفظ الملكية لكل طفل ويمنع خصم النقاط عند شراء الرفيق نفسه مرة أخرى.
- ألعاب المتاهة والملاحظة وترتيب القصص تضم ثلاثة مستويات بمكافآت متدرجة.
- قاعدة البيانات v9 تضيف مخزون الرفاق بترحيل إضافي يحافظ على البيانات الحالية.
- لا يُعتمد APK للنشر إلا بعد نجاح Workflow واختبارات Flutter والتحقق من التوقيع.


## تفعيل بناء APK من GitHub

1. يجب أن يكون ملف سير العمل موجودًا في المستودع نفسه بالمسار `.github/workflows/android.yml`؛ وجوده داخل ZIP وحده لا يفعّله.
2. يمكنك رفع محتويات المشروع إلى جذر المستودع بحيث يظهر `pubspec.yaml` مباشرة، أو إبقاء المشروع داخل ZIP مرفوع في جذر المستودع. أصبح سير العمل يتعرف على أرشيف NOOR الذي يحتوي `pubspec.yaml`، ويختار أعلى إصدار R مرقّم عند وجود أكثر من نسخة.
3. من تبويب Actions شغّل `NOOR Android validation and APK` عبر Run workflow، أو ادفع تحديثًا إلى main/master.
4. يتطلب إصدار APK الموقّع وجود أسرار المستودع الحالية: `KEYSTORE_BASE64` و`KEYSTORE_PASSWORD` و`KEY_ALIAS` و`KEY_PASSWORD`. لا تضع ملف keystore أو كلمات المرور داخل ZIP أو Git.
5. بعد النجاح نزّل artifact باسم `NOOR-APK-Release`؛ ملف الإصدار الناتج APK فقط. راجع أيضًا `NOOR-Source-Package` لحزمة المصدر التي اجتازت الفحوصات.

إذا كان المستودع يحتوي ZIP فقط ولم يكن ملف Workflow موجودًا خارجه، أضف ملف `.github/workflows/android.yml` أولًا من النسخة المستكملة؛ لن يستطيع GitHub تشغيل Workflow مخفي داخل الأرشيف.
